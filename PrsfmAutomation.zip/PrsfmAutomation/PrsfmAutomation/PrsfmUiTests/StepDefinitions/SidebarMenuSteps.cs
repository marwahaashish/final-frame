﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using System.Threading;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions
{
  [Binding]
  public class SidebarMenuSteps
  {
    private readonly IWebDriver _driver;
    private readonly SidebarMenuSelectors _sidebarMenuSelectors;

    public SidebarMenuSteps(IWebDriver driver)
    {
      _driver = driver;

      _sidebarMenuSelectors = new SidebarMenuSelectors();
      PageFactory.InitElements(_driver, _sidebarMenuSelectors);
    }


    [When(@"Select sidebar menu link '(.*)'")]
    public void WhenSelectSidebarMenuLink(string passedLink)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).MoveToElement(_driver.FindElement(By.XPath(_sidebarMenuSelectors.SidebarMenuLink(passedLink))));
        new WebDriverExtensions(_driver).JavaScriptClick(_driver.FindElement(By.XPath(_sidebarMenuSelectors.SidebarMenuLink(passedLink))));
      });
     

    }
  }
}
