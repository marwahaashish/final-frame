﻿using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class BankDetailsFormSteps
    {
        private readonly IWebDriver _driver;
        private readonly BankDetailsFormSelectors _bankDetailsFormSelectors;

        public BankDetailsFormSteps(IWebDriver driver)
        {
            _driver = driver;

            _bankDetailsFormSelectors = new BankDetailsFormSelectors();
            PageFactory.InitElements(_driver, _bankDetailsFormSelectors);
        }


        [When(@"Complete bank details for united kingdom")]
        public void WhenCompleteBankDetailsForUnitedKingdom(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_bankDetailsFormSelectors.SortCode);
                _bankDetailsFormSelectors.SortCode.SendKeys((string)formData.SortCode.ToString());
            });

            _bankDetailsFormSelectors.ValidateSortCode.Click();
            Thread.Sleep(4000);
            _bankDetailsFormSelectors.AccountNumber.SendKeys((string)formData.AccountNumber.ToString());      
            _bankDetailsFormSelectors.NameInAccout.SendKeys((string)formData.NameInAccount);
            _bankDetailsFormSelectors.NameOfBank.SendKeys((string)formData.NameOfBank);
            _bankDetailsFormSelectors.NameOfBank.SendKeys(Keys.Tab);
            _bankDetailsFormSelectors.AddressOfBank.SendKeys((string)formData.Branch);
        }
    }
}