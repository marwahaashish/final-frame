﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class OnlineAccountSetupFormSteps
    {
        private readonly IWebDriver _driver;
        private readonly OnlineAccountSetupFormSelectors _onlineAccountSetupFormSelectors;

        public OnlineAccountSetupFormSteps(IWebDriver driver)
        {
            _driver = driver;

            _onlineAccountSetupFormSelectors = new OnlineAccountSetupFormSelectors();
            PageFactory.InitElements(_driver, _onlineAccountSetupFormSelectors);
        }


        [When(@"Complete Online Account Setup Sign up question")]
        public void WhenCompleteOnlineAccountSetupSignUpQuestion(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).SelectFromDropDownList(_onlineAccountSetupFormSelectors.SignUpQuestion, (string)formData.Question);
            });

            TaskHelper.ExecuteTask(() =>
            {
                _onlineAccountSetupFormSelectors.SignUpAnswer.SendKeys((string)formData.Answer);
            });
        }

    }
}
