﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions
{
  [Binding]
  public sealed class SiteCoreRequestAccessSteps
  {
    private readonly IWebDriver _driver;    
    private readonly SiteCoreRequestAccessSelectors _siteCoreRequestAccessSelectors;

    public SiteCoreRequestAccessSteps(IWebDriver driver)
    {
      _driver = driver;
      _siteCoreRequestAccessSelectors = new SiteCoreRequestAccessSelectors();
      PageFactory.InitElements(_driver, _siteCoreRequestAccessSelectors);
    }

   

      [Then(@"Click on account page")]
      public void ThenClickOnAccountPage()
      {
        TaskHelper.ExecuteTask(() =>
            {
              new WebDriverExtensions(_driver).WaitForPresence(_siteCoreRequestAccessSelectors.NavigationDropDown);
              new WebDriverExtensions(_driver).JavaScriptClick(_siteCoreRequestAccessSelectors.NavigationDropDown);
              new WebDriverExtensions(_driver).WaitForPresence(_siteCoreRequestAccessSelectors.MyAccount);
              new WebDriverExtensions(_driver).JavaScriptClick(_siteCoreRequestAccessSelectors.MyAccount);

            });
      }

      [Then(@"View requests icon visible")]
      public void ThenViewRequestsIconVisible()
      {
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_siteCoreRequestAccessSelectors.ViewRequestsIcon);
            new WebDriverExtensions(_driver).JavaScriptClick(_siteCoreRequestAccessSelectors.ViewRequestsIcon);

          });
      }

        [Then(@"Click view access requests")]
        public void ThenClickViewAccessRequests()
        {
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_siteCoreRequestAccessSelectors.ViewAccessRequests);
            new WebDriverExtensions(_driver).JavaScriptClick(_siteCoreRequestAccessSelectors.ViewAccessRequests);

          });

          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_siteCoreRequestAccessSelectors.SeeRequest);
            new WebDriverExtensions(_driver).JavaScriptClick(_siteCoreRequestAccessSelectors.SeeRequest);

          });         
         }

        [Then(@"Validate '(.*)' is visible")]
        public void ThenValidateIsVisible(string buttonText)
        {
           bool? trueFalse = null;
           trueFalse = new WebDriverExtensions(_driver).IsElementVisible(_driver,
           By.XPath(_siteCoreRequestAccessSelectors.GiveAccess(buttonText)));

           Assert.AreEqual(true, trueFalse);
    }



  }
}
