﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors.SetlistHub;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using NUnit.Framework;
using System.Threading;

namespace PrsfmUiTests.StepDefinitions.SetListHub
{
  [Binding]
  public sealed class LivePerformancesAssimilateSteps
  {
    private readonly IWebDriver _driver;
    private readonly LivePerformanceSelectors _livePerformanceSelectors;
    private string[] _saveResults;


    public LivePerformancesAssimilateSteps(IWebDriver driver)
    {
      _driver = driver;

      _livePerformanceSelectors = new LivePerformanceSelectors();
      PageFactory.InitElements(_driver, _livePerformanceSelectors);

    }

    [Then(@"Select a assimilate International territory")]
    public void ThenSelectAAssimilateInternationalTerritory(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.CountrySearch);
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.CountrySearch);
        _livePerformanceSelectors.CountrySearch.SendKeys((string)formData.Country);
        _livePerformanceSelectors.AssimilateVenueSearch.SendKeys(Keys.Tab);
        _livePerformanceSelectors.WhiteSpace.Click();
      });
    }


    [Then(@"Validate assimilate message shown")]
    public void ThenValidateAssimilateMessageShown(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();

      switch ((string)formData.Text)
      {
        case "We require additional validation where members report a performance which is more than seven years old. Please":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Greater7YrsMsg);
            Assert.IsTrue(_livePerformanceSelectors.Greater7YrsMsg.Text.Contains((string)formData.Text));
          });
          break;

        case "International performances must have occurred in the past two years in order to be valid":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Greater2YrsMsg);
            Assert.IsTrue(_livePerformanceSelectors.Greater2YrsMsg.Text.Contains((string)formData.Text));
          });
          break;

        case "Your performance at this venue must have occurred in the past year in order to be valid.":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Equal1YrMsg);
            Assert.IsTrue(_livePerformanceSelectors.Equal1YrMsg.Text.Contains((string)formData.Text));
          });
          break;

        case "Please select valid country":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.InvaldCountry);
            Assert.IsTrue(_livePerformanceSelectors.InvaldCountry.Text.Contains((string)formData.Text));
          });
          break;



        default:
          Console.WriteLine("*** UNKnown Page Title passed test");
          break;

      }

    }

    [Then(@"Select a assimilate venue")]
    public void ThenSelectAAssimilateVenue(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.AssimilateVenueSearch);

      });
      _livePerformanceSelectors.AssimilateVenueSearch.SendKeys((string)formData.Venue);

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AssimilateSearch);

      });

      Thread.Sleep(10000);
      TaskHelper.ExecuteTask(() =>
      {
         new WebDriverExtensions(_driver).SafeJavaScriptClick(_driver.FindElement(
              By.XPath(_livePerformanceSelectors.HighlightedAssimilateResult((string)formData.Venue))));
      });

    }

    [Then(@"Select a assimilate venue not in search list")]
    public void ThenSelectAAssimilateVenueNotInSearchList(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.AssimilateVenueSearch);
        _livePerformanceSelectors.AssimilateVenueSearch.SendKeys((string)formData.Venue);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AssimilateSearch);

      });
      
    }

    [Then(@"Validate assimilate details submitted")]
    public void ThenValidateAssimilateDetailsSubmitted()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.FinalSubmitPageText);
        Assert.IsTrue(_livePerformanceSelectors.FinalSubmitPageText.Text.Contains("Thank you for reporting your performance."));
      });
    }


    [Then(@"Click assimilate Find more Venues button")]
    public void ThenClickAssimilateFindMoreVenuesButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.FindGoogleVenues);
        _livePerformanceSelectors.FindGoogleVenues.Click();
      });
    }

    [Then(@"Click the assimilate Save button")]
    public void ThenClickTheAssimilateSaveButton()
    {
      _saveResults = SaveDetails();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SaveForLaterButton);
        _livePerformanceSelectors.SaveForLaterButton.Click();
      });
    }

    private string[] SaveDetails()
    {
      string[] results = new string[3];
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
        var perforrmancedate = _livePerformanceSelectors.PerformanceDatePicker.GetAttribute("value");
        results[0] = perforrmancedate;
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AssimilateVenueSearch);
        var venue = _livePerformanceSelectors.AssimilateVenueSearch.GetAttribute("value");
        results[1] = venue;
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformerName);
        var performer = _livePerformanceSelectors.PerformerName.GetAttribute("value");
        results[2] = performer;
      });

      return results;
    }

    private string SaveDetails(IWebElement element)
    {
      string details = "";
      string[] results = new string[1];
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(element);
        details = element.GetAttribute("value");
      });

      return details;
    }

    [Then(@"Validate assimilate detials saved")]
    public void ThenValidateAssimilateDetialsSaved()
    {
      var date = _saveResults[0].Remove(0, 1);
      Assert.IsTrue(_livePerformanceSelectors.SavedPerformanceDetail(date).Contains(date));

      var place = _saveResults[1];
      Assert.IsTrue(_livePerformanceSelectors.SavedPerformanceDetail(place).Contains(place));

      var who = _saveResults[2];
      Assert.IsTrue(_livePerformanceSelectors.SavedPerformanceDetail(who).Contains(who));
    }


    [Then(@"Select a random venue")]
    public void ThenSelectARandomVenue()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.VenueSearch);
        _livePerformanceSelectors.VenueSearch.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(20));
      });
    }
    
    [Then(@"Check Can't find a work\?")]
    public void ThenCheckCanTFindAWork()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.CantFindItText);
        _livePerformanceSelectors.CantFindItText.Click();

      });
    }
    
    [Then(@"Validate the register work page is displayed")]
    public void ThenValidateTheRegisterWorkPageIsDisplayed()
    {

      TaskHelper.ExecuteTask(() =>
      {
        _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);
      });

      TaskHelper.ExecuteTask(() =>
      {
        WindowsHandling.SelectLastHandle("Register or Amend My Music - Home", _driver);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.RegisterWorksPageHeader);
        var text = _livePerformanceSelectors.RegisterWorksPageHeader.Text;
        Assert.AreEqual(text, "Register or amend my music");
      });


    }

    [Then(@"Validate the Upload Fiches page is displayed")]
    public void ThenValidateTheUploadFichesPageIsDisplayed()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(20);
      });
      WindowsHandling.SelectLastHandle("Raise a query", _driver);
    }

    [Then(@"Click the assimilate Add Venue details Manually button")]
    public void ThenClickTheAssimilateAddVenueDetailsManuallyButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AddAssimilateVenueDetailsManually);
        //_livePerformanceSelectors.AddAssimilateVenueDetailsManually.Click();
      });
    }


    [Then(@"populate assimilate venue details")]
    public void ThenPopulateAssimilateVenueDetails()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _saveResults = new string[1];
        _livePerformanceSelectors.AddVenueDetailsManuallyName.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(15));
        _saveResults[0] = SaveDetails(_livePerformanceSelectors.AddVenueDetailsManuallyName);
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyCity.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(8));
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyPostCode.SendKeys("SW16 1ER");
      });
    }
    
    [Then(@"populate venue details max chars")]
    public void ThenPopulateVenueDetailsMaxChars()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _saveResults = new string[1];
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AddVenueDetailsManuallyName);
        _livePerformanceSelectors.AddVenueDetailsManuallyName.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(256));
        _saveResults[0] = SaveDetails(_livePerformanceSelectors.AddVenueDetailsManuallyName);
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyCity.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(256));
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyPostCode.SendKeys("SW16 1ER");
      });
    }

    [Then(@"Validate assimilate venue details")]
    public void ThenValidateAssimilateVenueDetails()
    {
      var x = _livePerformanceSelectors.AssimilateVenueSearch.GetAttribute("value");
      Assert.IsTrue(_livePerformanceSelectors.AssimilateVenueSearch.GetAttribute("value").Contains(_saveResults[0]));
      Assert.AreEqual(x, _saveResults[0]);
    }

    [Then(@"Populate the assimilate Add Festival details form")]
    public void ThenPopulateTheAssimilateAddFestivalDetailsForm()
    {
      _saveResults = new string[3];
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.FestivalName.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(15));
      });

      _saveResults[0] = SaveDetails(_livePerformanceSelectors.FestivalName);

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.FestivalStage.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(8));
      });
      _saveResults[1] = SaveDetails(_livePerformanceSelectors.FestivalName);

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.Festivalvenue.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(8));
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.FestivalPostcode);
        _livePerformanceSelectors.FestivalPostcode.SendKeys("SW16 1ER");
      });
    }

    [Then(@"validate Festival Details are displayed")]
    public void ThenValidateFestivalDetailsAreDisplayed()
    {
      bool x = _livePerformanceSelectors.reviewFestivalName.Text.Contains(_saveResults[0]);

      var y = _livePerformanceSelectors.reviewFestivalName.GetAttribute("value");
      var z = _livePerformanceSelectors.reviewFestivalName.Text;


      Assert.AreEqual(x, y);
    }

    [Then(@"Validate assimilate screen '(.*)' is displayed")]
    public void ThenValidateAssimilateScreenIsDisplayed(string screen)
    {
      switch (screen)
      {
        case
                "SavedPerformace"
                :
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.LivePerformances);
          });
          TaskHelper.ExecuteTask(() =>
          {
            Assert.IsNotNull(WindowsHandling.ReturnWindonwTitle(_driver));
            var tabUrl = WindowsHandling.ReturnWindonwURL(_driver);

            StringAssert.Contains("performances/saved", tabUrl);

          });
          break;

        //case
        //    "Contact Us"
        //    :
        //    TaskHelper.ExecuteTask(() =>
        //    {
        //        var newTab = WindowsHandling.SelectLastHandle("Set List Feedback - Formstack",_driver);
        //        var tabUrl = WindowsHandling.ReturnWindonwURL(newTab);
        //        Assert.IsNotNull(WindowsHandling.ReturnWindonwTitle(newTab));
        //        StringAssert.Contains( "forms/setlist",tabUrl);

        //    });
        //    break;

        case
                "Submitted"
                :
          TaskHelper.ExecuteTask(() =>
          {
            Assert.IsNotNull(WindowsHandling.ReturnWindonwTitle(_driver));
            var tabUrl = WindowsHandling.ReturnWindonwURL(_driver);
            StringAssert.Contains("performances/submitted", tabUrl);

          });
          break;

        default:
          Console.WriteLine("*** UNKnown Screen");
          break;
      }

    }


    [Then(@"Select the assimilate '(.*)' link")]
    public void ThenSelectTheAssimilateLink(string link)
    {
      switch (link)

      {
        case
              "PRS Logo"
              :
          TaskHelper.ExecuteTask(() =>
          {
            _livePerformanceSelectors.AssimilatePRSLogo.Click();

          });
          break;

        case
              "Contact Us"
              :
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.LivePerformances);
            // _livePerformanceSelectors.ContactUs.Click();
          });
          break;


        default:
          Console.WriteLine("*** UNKnown Page Title passed test");
          break;
      }
    }

    [When(@"The assimilate performance datepicker is opened")]
    public void WhenTheAssimilatePerformanceDatepickerIsOpened()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
        _livePerformanceSelectors.PerformanceDatePicker.Click();
      });
    }



    [Then(@"Click Assimilate Report a Live Performance button")]
    public void ThenClickAssimilateReportALivePerformanceButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ReportLivePerformanceButton2);
        _livePerformanceSelectors.ReportLivePerformanceButton2.Click();
      });
    }

  }
}


