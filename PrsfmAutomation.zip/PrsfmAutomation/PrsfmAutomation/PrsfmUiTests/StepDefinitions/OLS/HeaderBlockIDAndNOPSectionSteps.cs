﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace OlsUiTests.Steps
{
  [Binding]
  public sealed class HeaderBlockIDAndNOPSectionSteps
  {
    private readonly IWebDriver _driver;
    private readonly HomePagePage _homePage;

    public HeaderBlockIDAndNOPSectionSteps(IWebDriver driver)
    {
      _driver = driver;
      _homePage = new HomePagePage(_driver);
    }


    [Then(@"I should have my full name on header block ""(.*)""")]
    public void ThenIShouldHaveMyFullNameOnHeaderBlock(string FullName)
    {
      StringAssert.AreEqualIgnoringCase(FullName, _homePage.GetMemIpiName());
    }

    [Then(@"I should have my CAE/IPI number ""(.*)""")]
    public void ThenIShouldHaveMyCAEIPINumber(string IPINum)
    {
      StringAssert.AreEqualIgnoringCase(IPINum, _homePage.GetMemIPINumber());
    }

    [Then(@"I should have society for which statement is meant for ""(.*)""")]
    public void ThenIShouldHaveSocietyForWhichStatementIsMeantFor(string SocietyName)
    {
      StringAssert.AreEqualIgnoringCase(SocietyName, _homePage.GetSocietyName());
    }

    [Then(@"I should have statement identifier and desriptive ""(.*)""")]
    public void ThenIShouldHaveStatementIdentifierAndDesriptive(string StatementID)
    {
      StringAssert.AreEqualIgnoringCase(StatementID, _homePage.GetStatementID());
    }

    [Then(@"I should distribution ID ""(.*)""")]
    public void ThenIShouldDistributionID(string DistID)
    {
      StringAssert.AreEqualIgnoringCase(DistID, _homePage.GetDistCode());
    }

    [Then(@"I should have total royalty payment ""(.*)""")]
    public void ThenIShouldHaveTotalRoyaltyPayment(string RoyaltyPayment)
    {
      StringAssert.AreEqualIgnoringCase(RoyaltyPayment, _homePage.GetRoyaltyAmount());
    }

  }
}
