﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace OlsUiTests.Steps
{
  [Binding]
  public sealed class HomePageSteps
  {
    private readonly IWebDriver _driver;
    private readonly HomePagePage _homePage;
    private readonly LogInAndLogOutSteps _logInSteps;


    public HomePageSteps(IWebDriver driver)
    {
      _driver = driver;
      _homePage = new HomePagePage(_driver);
      _logInSteps = new LogInAndLogOutSteps(_driver);
    }

    [Then(@"I should have '(.*)'")]
    public void ThenIShouldHave(string CaeIpi)
    {
      StringAssert.AreEqualIgnoringCase(CaeIpi, _homePage.GetHomePageTitle());
    }
    [Then(@"I should see header ""(.*)""")]
    public void ThenIShouldSeeHeader(string HeaderText)
    {
      StringAssert.AreEqualIgnoringCase(HeaderText, _homePage.GetHomePageTitle());
    }

    [Then(@"I should be presented with '(.*)'")]
    public void ThenIShouldBePresentedWith(string NOP)
    {
      StringAssert.AreEqualIgnoringCase(NOP, _homePage.GetNOP());
    }

    [When(@"I click on All Statement link")]
    public void WhenIClickOnAllStatementLink()
    {
      _homePage.ClickAllStatementsLink();
    }

    [When(@"I click on Analytics link")]
    public void WhenIClickOnAnalyticsLink()
    {
      _homePage.ClickAnalyticsLink();
    }

    [When(@"I click on Royal Statement link")]
    public void WhenIClickOnRoyalStatementLink()
    {
      _homePage.ClickRoyalStatementsLink();
    }

    //[Then(@"I should be directed to '(.*)' page")]
    //public void ThenIShouldBeDirectedToPage(string PageHeader)
    //{
    //    StringAssert.AreEqualIgnoringCase(PageHeader, _homePage.GetPageHeaderTitleText());
    //}
    [Then(@"I should navigate to '(.*)' page")]
    public void ThenIShouldNavigateToPage(string PageHeader)
    {
      StringAssert.AreEqualIgnoringCase(PageHeader, _homePage.GetHomePageTitle());
    }

    //[AfterScenario]
    //public void logout()
    //{
    //  if (_homePage.IsLoggedIn())
    //  {
    //   _logInSteps.ThenWhenISignOut();
    //  }

    //}
    
  }
}
