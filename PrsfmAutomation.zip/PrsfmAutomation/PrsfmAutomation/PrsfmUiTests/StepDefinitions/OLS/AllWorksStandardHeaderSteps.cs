﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace OlsUiTests.Steps
{
  [Binding]
  internal class AllWorksStandardHeaderSteps
  {
    private readonly IWebDriver _driver;
    private readonly AllWorksAndAdjustmentsPage _allworks;

    public AllWorksStandardHeaderSteps(IWebDriver driver)
    {
      _driver = driver;
      _allworks = new AllWorksAndAdjustmentsPage(_driver);
    }

    [Then(@"Royalty amount should be ""(.*)""")]
    public void ThenRoyaltyAmountShouldBe(string RoyaltyAmount)
    {
      Assert.AreEqual(RoyaltyAmount, _allworks.GetRoyaltyAmount());
    }

    [Then(@"Society should be ""(.*)""")]
    public void ThenSocietyShouldBe(string Society)
    {
      StringAssert.AreEqualIgnoringCase(Society, _allworks.GetSociety());
    }

    [Then(@"Distribution code should be ""(.*)""")]
    public void ThenDistributionCodeShouldBe(string Distribution)
    {
      Assert.AreEqual(Distribution, _allworks.GetDistribution());
    }

    [Then(@"Royalty Name should be ""(.*)""")]
    public void ThenRoyaltyNameShouldBe(string RoyaltyName)
    {
      StringAssert.AreEqualIgnoringCase(RoyaltyName, _allworks.GetRoyaltyName());
    }

    [Then(@"IPI number should be ""(.*)""")]
    public void ThenIPINumberShouldBe(string IpiNum)
    {
      Assert.AreEqual(IpiNum, _allworks.GetIpiNum());
    }


    [Then(@"I should see these:")]
    public void ThenIShouldSeeThese(Table table)
    {
      var standardHeader = table.CreateInstance<StandardHeaderDetails>();

      StringAssert.AreEqualIgnoringCase(standardHeader.RoyaltyAmount, _allworks.GetRoyaltyAmount());
      StringAssert.AreEqualIgnoringCase(standardHeader.Society, _allworks.GetSociety());
      StringAssert.AreEqualIgnoringCase(standardHeader.Distribution, _allworks.GetDistribution());
      StringAssert.AreEqualIgnoringCase(standardHeader.RoyaltyName, _allworks.GetRoyaltyName());
      StringAssert.AreEqualIgnoringCase(standardHeader.IpiNum, _allworks.GetIpiNum());
    }



    public class StandardHeaderDetails
    {
      public string RoyaltyAmount { get; set; }
      public string Society { get; set; }
      public string Distribution { get; set; }
      public string RoyaltyName { get; set; }
      public string IpiNum { get; set; }
    }

  }
}
