﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace OlsUiTests.Steps
{
  [Binding]
  public sealed class HeaderBlockStatementHeadlinesSteps
  {
    private readonly IWebDriver _driver;
    private readonly HeadlinesSectionPage _headlinePage;

    public HeaderBlockStatementHeadlinesSteps(IWebDriver driver)
    {
      _driver = driver;
      _headlinePage = new HeadlinesSectionPage(_driver);
    }

    [Then(@"I should be presented with number of earning works ""(.*)""")]
    public void ThenIShouldBePresentedWithNumberOfEarningWorks(string EarningWorksNum)
    {
      StringAssert.AreEqualIgnoringCase(EarningWorksNum, _headlinePage.GetEarningWorksNum());
    }

    [Then(@"I should have number of usage type""(.*)""")]
    public void ThenIShouldHaveNumberOfUsageType(string UsageTypeNum)
    {
      StringAssert.AreEqualIgnoringCase(UsageTypeNum, _headlinePage.GetUsageTypeNum());
    }

    [Then(@"I should have number of territories ""(.*)""")]
    public void ThenIShouldHaveNumberOfTerritories(string TerritoriesNum)
    {
      StringAssert.AreEqualIgnoringCase(TerritoriesNum, _headlinePage.GetTerritoriesNum());
    }

    [Then(@"I should have top work's title ""(.*)""")]
    public void ThenIShouldHaveTopWorkSTitle(string TopWorksTitle)
    {
      StringAssert.AreEqualIgnoringCase(TopWorksTitle, _headlinePage.GetTopWorkTitle());
    }

    [Then(@"I should have top work amount ""(.*)""")]
    public void ThenIShouldHaveTopWorkAmount(string TopWorkAmount)
    {
      StringAssert.AreEqualIgnoringCase(TopWorkAmount, _headlinePage.GetTopWorkAmount());
    }

  }

}
