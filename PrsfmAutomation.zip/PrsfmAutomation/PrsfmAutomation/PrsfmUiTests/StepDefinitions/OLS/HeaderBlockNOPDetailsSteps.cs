﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace OlsUiTests.Steps
{
  [Binding]
  public sealed class HeaderBlockNOPDetailsSteps
  {
    private readonly IWebDriver _driver;
    private readonly HeaderBlockNOPPage _nopPage;

    public HeaderBlockNOPDetailsSteps(IWebDriver driver)
    {
      _driver = driver;
      _nopPage = new HeaderBlockNOPPage(_driver);
    }

    [Then(@"I should have my Royalty amount as ""(.*)""")]
    public void ThenIShouldHaveMyRoyaltyAmountAs(string RoyaltyAmount)
    {
      StringAssert.AreEqualIgnoringCase(RoyaltyAmount, _nopPage.GetPrsRoyaltyAmount());
    }
    [Then(@"I should have plus VAT as ""(.*)""")]
    public void ThenIShouldHavePlusVATAs(string PlusVAT)
    {
      StringAssert.AreEqualIgnoringCase(PlusVAT, _nopPage.GetPlusVAT());
    }

    [Then(@"I should have the toatl as ""(.*)""")]
    public void ThenIShouldHaveTheToatlAs(string Total)
    {
      StringAssert.AreEqualIgnoringCase(Total, _nopPage.GetRoyaltyPlusVAT());
    }

    [Then(@"I should have the payee as  ""(.*)""")]
    public void ThenIShouldHaveThePayeeAs(string Payee)
    {
      StringAssert.Contains(Payee, _nopPage.GetPayee());
    }

    [Then(@"I should have bank details as ""(.*)""")]
    public void ThenIShouldHaveBankDetailsAs(string BacsDetails)
    {
      StringAssert.AreEqualIgnoringCase(BacsDetails, _nopPage.GetBacsDetails());
    }

    [Then(@"I should have the amount paid as directed as ""(.*)""")]
    public void ThenIShouldHaveTheAmountPaidAsDirectedAs(string AmountPaid)
    {
      StringAssert.AreEqualIgnoringCase(AmountPaid, _nopPage.GetAmountPaid());
    }

    [When(@"I click on notice of payments button")]
    public void WhenIClickOnNoticeOfPaymentsButton()
    {
      _nopPage.ClickNOPButton();
    }
    [Then(@"I should have Licensing bodies ""(.*)""")]
    public void ThenIShouldHaveLicensingBodies(string LicensingBodies)
    {
      StringAssert.AreEqualIgnoringCase(LicensingBodies, _nopPage.GetLicenseBodies());
    }
    [Then(@"I should see Mechanical Royalty as ""(.*)""")]
    [Then(@"I should have Royalty Total ""(.*)""")]
    public void ThenIShouldHaveRoyaltyTotal(string RoyaltyTotal)
    {
      StringAssert.AreEqualIgnoringCase(RoyaltyTotal, _nopPage.GetRoyaltyTotal());
    }
    [Then(@"I should have BMI Q Account VAT ""(.*)""")]
    public void ThenIShouldHaveBMIQAccountVAT(string BMIAccountVAT)
    {
      StringAssert.AreEqualIgnoringCase(BMIAccountVAT, _nopPage.GetBMIAccountVAT());
    }
    [Then(@"I should have Earnings as ""(.*)""")]
    public void ThenIShouldHaveEarningsAs(string Earnings)
    {
      StringAssert.AreEqualIgnoringCase(Earnings, _nopPage.GetEarnings());
    }
    [Then(@"I should have mcps plus VAT as ""(.*)""")]
    public void ThenIShouldHaveMcpsPlusVATAs(string McpsPlusVAT)
    {
      StringAssert.AreEqualIgnoringCase(McpsPlusVAT, _nopPage.GetBMIAccountVAT());
    }
    [Then(@"I should have mechanical commission ""(.*)""")]
    public void ThenIShouldHaveMechanicalCommission(string Commission)
    {
      StringAssert.AreEqualIgnoringCase(Commission, _nopPage.GetPlusVAT());
    }
    [Then(@"I should have mechanical commission")]
    public void ThenIShouldHaveMechanicalCommission()
    {
       StringAssert.AreEqualIgnoringCase("-£13,013.11", _nopPage.GetPlusVAT());
    }
  }

  
}
