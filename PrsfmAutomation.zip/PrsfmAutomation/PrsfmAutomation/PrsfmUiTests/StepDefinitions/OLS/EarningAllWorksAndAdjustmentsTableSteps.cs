﻿using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace OlsUiTests.Steps
{
  [Binding]
  internal class EarningAllWorksAndAdjustmentsTableSteps
  {
    private readonly IWebDriver _driver;
    private readonly ExplorationBlockPage _explorationBlock;
    private readonly AllWorksAndAdjustmentsPage _allworks;

    public EarningAllWorksAndAdjustmentsTableSteps(IWebDriver driver)
    {
      _driver = driver;
      _explorationBlock = new ExplorationBlockPage(_driver);
      _allworks = new AllWorksAndAdjustmentsPage(_driver);
    }

    [When(@"I click on All Works button")]
    public void WhenIClickOnAllWorksButton()
    {
      _explorationBlock.ClickAllWorksBtn();
    }

    [Then(@"I should see the all works table")]
    public void ThenIShouldSeeTheAllWorksTable()
    {
      _allworks.isAllWorksTableDisplayed();
    }

    [Then(@"I should see the Adjustments table")]
    public void ThenIShouldSeeTheAdjustmentsTable()
    {
      _allworks.isAdjustmentsTableDisplayed();
    }


  }
}
