﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace OlsUiTests.Steps
{
  [Binding]
  internal class ExplorationBlockNavigationSteps
  {
    private readonly IWebDriver _driver;
    private readonly ExplorationBlockPage _explorationBlock;


    public ExplorationBlockNavigationSteps(IWebDriver driver)
    {
      _driver = driver;
      _explorationBlock = new ExplorationBlockPage(_driver);
    }

    [When(@"I click on Usage Type tab")]
    public void WhenIClickOnUsageTypeTab()
    {
      _explorationBlock.ClickUsageTypeTab();
    }

    [Then(@"I should be taken to usage section")]
    public void ThenIShouldBeTakenToUsageSection()
    {
      StringAssert.AreEqualIgnoringCase("Top usage summary", _explorationBlock.GetUsageTypePage());
    }

    [Then(@"I click on Territory tab")]
    public void ThenIClickOnTerritoryTab()
    {
      _explorationBlock.ClickTerritoryTab();
    }

    [Then(@"I should be taken to Territory section")]
    public void ThenIShouldBeTakenToTerritorySection()
    {
      StringAssert.AreEqualIgnoringCase("Territories", _explorationBlock.GetTerritoryPage());
    }

    [Then(@"I click on Works tab")]
    public void ThenIClickOnWorksTab()
    {
      _explorationBlock.ClickWorksTab();
    }

    [Then(@"I should be taken to Earning Works section")]
    public void ThenIShouldBeTakenToEarningWorksSection()
    {
      StringAssert.AreEqualIgnoringCase("Earning Works", _explorationBlock.GetEarningWorksPage());
    }

  }
}
