﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class NavigationBarSteps
    {
        private readonly IWebDriver _driver;
        private readonly NavigationBarSelectors _navigationBarSelectors;

        public NavigationBarSteps(IWebDriver driver)
        {
            _driver = driver;

            _navigationBarSelectors = new NavigationBarSelectors();
            PageFactory.InitElements(_driver, _navigationBarSelectors);
        }

        [When(@"Select navigation bar item '(.*)'")]
        public void WhenSelectNavigationBarItem(string linkText)
        {
            switch (linkText)
            {
                case "What We Do":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_navigationBarSelectors.WhatWeDo);
                        _navigationBarSelectors.WhatWeDo.Click();
                    });                    
                    break;

                case "Royalties":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_navigationBarSelectors.Royalties);
                        _navigationBarSelectors.Royalties.Click();
                    });
                    break;

                case "Works":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_navigationBarSelectors.Works);
                        _navigationBarSelectors.Works.Click();
                    });
                    break;

                case "Licences":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_navigationBarSelectors.Licences);
                        _navigationBarSelectors.Licences.Click();
                    });
                    break;

                case "Help":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_navigationBarSelectors.Help);
                        _navigationBarSelectors.Help.Click();
                    });
                    break;

                case "Login":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_navigationBarSelectors.Login);
                        ((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].click();", _navigationBarSelectors.Login);
                    });
                    break;
            }
        }
    }
}
