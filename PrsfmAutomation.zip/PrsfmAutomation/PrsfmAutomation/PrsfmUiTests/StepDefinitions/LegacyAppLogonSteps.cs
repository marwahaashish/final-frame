﻿using IamUiTests.Selectors;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using PrsfmUiTests.Helpers;
using TechTalk.SpecFlow;

namespace IamUiTests.StepDefinitions
{
  [Binding]
  class LegacyAppLogonSteps
  {
    private readonly IWebDriver _driver;
    private readonly LegacyAppLogonSelectors _legacyAppLogonSelectors;

    public LegacyAppLogonSteps(IWebDriver driver)
    {
      _driver = driver;

      _legacyAppLogonSelectors = new LegacyAppLogonSelectors();
      PageFactory.InitElements(_driver, _legacyAppLogonSelectors);
    }



    [Then(@"Logon in sitecore account")]
    public void ThenLogonInsitecoreAccount()
    {
      //TaskHelper.ExecuteTask(() =>
      //{
      //  new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.LogonText);
      //});

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.FDEmailAddress);
      });


      _legacyAppLogonSelectors.FDEmailAddress.SendKeys("Legacy.member@mailinator.com");
      _legacyAppLogonSelectors.FDNext.Click();

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.Password);
      });
      _legacyAppLogonSelectors.Password.SendKeys("Automation123");
      _legacyAppLogonSelectors.Submit.Click();

    }

    [Then(@"Logon in Assimlate account")]
    public void ThenLogonInAssimlateAccount()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.LogonTextAssimilate);
      });

      _legacyAppLogonSelectors.AssimilateEmailAddress.SendKeys("eBusinessTest2@prsformusic.com");
      _legacyAppLogonSelectors.AssimilatePassword.SendKeys("e*BizReg");
      _legacyAppLogonSelectors.AssimilatSubmit.Click();

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.AssimilatCAE);
      });

      _legacyAppLogonSelectors.AssimilatCAE.SendKeys("451804371");
      _legacyAppLogonSelectors.AssimilatePassword.SendKeys("e*BizReg");      
      _legacyAppLogonSelectors.AssimilatSubmit.Click();
    }


    [Then(@"Logon in legacy Overseas account")]
    public void ThenLogonInLegacyOverseasAccount()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.LogonText);
      });

      _legacyAppLogonSelectors.EmailAddress.SendKeys("Legacy.overseas@mailinator.com");
      _legacyAppLogonSelectors.Password.SendKeys("Automation123");
      _legacyAppLogonSelectors.Submit.Click();
    }


    [Then(@"Logon in legacy licensee account")]
    public void ThenLogonInLegacyLicenseeAccount()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.LogonText);
      });

      _legacyAppLogonSelectors.EmailAddress.SendKeys("Legacy.licensee@mailinator.com");
      _legacyAppLogonSelectors.Password.SendKeys("Automation123");
      _legacyAppLogonSelectors.Submit.Click();
    }
    
  }
}
