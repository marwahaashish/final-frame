﻿using IamUiTests.Selectors;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;

namespace IamUiTests.StepDefinitions
{
  [Binding]
  public sealed class LegacyAppsViaSiteCoreSteps
  {
    private readonly IWebDriver _driver;
    private IWebDriver _newTabDriver;
    private readonly LegacyAppLogonSelectors _legacyAppLogonSelectors;

    public LegacyAppsViaSiteCoreSteps(IWebDriver driver)
    {
      _driver = driver;
      _legacyAppLogonSelectors = new LegacyAppLogonSelectors();
      PageFactory.InitElements(_driver, _legacyAppLogonSelectors);
    }

    [Then(@"Click on '(.*)' tile")]
    public void ThenClickOnTile(string appName)
    {
      switch (appName)
      {
        case "WACD":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickWACDTile);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickWACDTile);
          });
          break;

        case "WACS":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickShowMore);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickShowMore);
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickWACSTile);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickWACSTile);
            //new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickSeachCueSheets);
            //new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickSeachCueSheets);
          });
          break;

        case "CopCon":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickShowMore);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickShowMore);
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickUnpaidRoyaltiesTile);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickUnpaidRoyaltiesTile);
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickClaimUnpaidMCPSRoyalties);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickClaimUnpaidMCPSRoyalties);
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickClaimUnpaidMCPSRoyalties);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickClaimUnpaidMCPSRoyalties);
          });
          break;

        case "WACU":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickShowMore);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickShowMore);
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickUnpaidRoyaltiesTile);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickUnpaidRoyaltiesTile);
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickClaimUnpaidPRSRoyalties);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickClaimUnpaidPRSRoyalties);
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickClaimUnpaidPRSRoyalties);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickClaimUnpaidPRSRoyalties);
          });
          break;

        case "majorliveconcertservice":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickMLCSTile);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickMLCSTile);
          });
          break;

        case "VICO":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickVICOTile);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickVICOTile);
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickVICO);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickVICO);
          });
          break;

        case "NWR":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickShowMore);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickShowMore);
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickNWRTile);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickNWRTile);
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickNWR);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickNWR);
          });
          break;

        case "OLR":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickOLRTile);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickOLRTile);
          });
          break;

        case "OverseasAgencies":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickOASTile);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickOASTile);
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.ClickOAS);
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.ClickOAS);
          });
          break;

      }
    }


    [Then(@"Validate legacy app '(.*)' has loaded in Sitecore")]
    public void ThenValidateLegacyAppHasLoadedInSitecore(string urlString)
    {
      switch (urlString)
      {
        case "WUR":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.LoadWUR);
          });
          Assert.IsTrue(_driver.Title.Equals("Home Page"));
          Assert.IsTrue(new WebDriverExtensions(_driver).CaseInsensitiveContains(_driver.Url, urlString));
          break;

        case "WACS":
          _newTabDriver = WindowsHandling.OpenBrowserTab(_driver);
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_newTabDriver).WaitForPresence(_legacyAppLogonSelectors.LoadWACS);
          });
          Assert.IsTrue(_newTabDriver.Title.Equals("PRS for Music - Search Cue Sheets"));
          Assert.IsTrue(new WebDriverExtensions(_newTabDriver).CaseInsensitiveContains(_newTabDriver.Url, urlString));
          break;

        case "WACD":
          Thread.Sleep(2000);
          bool? trueFalse = null;
          _newTabDriver = WindowsHandling.OpenBrowserTab(_driver);
          trueFalse = new WebDriverExtensions(_newTabDriver).IsElementVisible(_newTabDriver,
              By.Id("Button1"));

          Assert.IsTrue(trueFalse == true
              ? _newTabDriver.FindElement(By.Id("Button1")).Displayed
              : _newTabDriver.FindElement(By.Id("ctl00_WACDMainContent_works_control_btnSearch")).Displayed);

          Assert.IsTrue(_newTabDriver.Title.Equals("PRS for Music - Search our Database"));
          Assert.IsTrue(new WebDriverExtensions(_newTabDriver).CaseInsensitiveContains(_newTabDriver.Url, urlString));
          break;

        case "CopCon":
          _newTabDriver = WindowsHandling.OpenBrowserTab(_driver);
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_newTabDriver).WaitForPresence(_legacyAppLogonSelectors.LoadCopCon);
          });
          Assert.IsTrue(_newTabDriver.Title.Equals("Copyright Control - Home"));
          Assert.IsTrue(new WebDriverExtensions(_newTabDriver).CaseInsensitiveContains(_newTabDriver.Url, urlString));
          break;

        case "WACU":
          _newTabDriver = WindowsHandling.OpenBrowserTab(_driver);
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_newTabDriver).WaitForPresence(_legacyAppLogonSelectors.LoadWACU);
          });
          Assert.IsTrue(_newTabDriver.Title.Equals("Claim Unpaid PRS Royalties"));
          Assert.IsTrue(new WebDriverExtensions(_newTabDriver).CaseInsensitiveContains(_newTabDriver.Url, urlString));
          break;

        case "majorliveconcertservice":
          _newTabDriver = WindowsHandling.OpenBrowserTab(_driver);
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_newTabDriver).WaitForPresence(_legacyAppLogonSelectors.LoadMLCS);
          });
          Assert.IsTrue(_newTabDriver.Title.Equals("Home Page"));
          Assert.IsTrue(new WebDriverExtensions(_newTabDriver).CaseInsensitiveContains(_newTabDriver.Url, urlString));
          break;

        case "VICO":
          _newTabDriver = WindowsHandling.OpenBrowserTab(_driver);
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_newTabDriver).WaitForPresence(_legacyAppLogonSelectors.LoadVICO);
          });
          Assert.IsTrue(_newTabDriver.Title.Equals("MCPS Invoices/Clearances - Download"));
          Assert.IsTrue(new WebDriverExtensions(_newTabDriver).CaseInsensitiveContains(_newTabDriver.Url, urlString));
          break;

        case "NWR":
          _newTabDriver = WindowsHandling.OpenBrowserTab(_driver);
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_newTabDriver).WaitForPresence(_legacyAppLogonSelectors.LoadNWR);
          });
          Assert.IsTrue(_newTabDriver.Title.Equals("PRS for Music - Search New Works Research"));
          Assert.IsTrue(new WebDriverExtensions(_newTabDriver).CaseInsensitiveContains(_newTabDriver.Url, urlString));
          break;

        case "DuplicateClaims":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.LoadDuplicateClaims);
          });
          Assert.IsTrue(_driver.Title.Equals("Duplicate Claims - Home"));
          Assert.IsTrue(new WebDriverExtensions(_driver).CaseInsensitiveContains(_driver.Url, urlString));
          break;

        case "OverseasAgencies":
          _newTabDriver = WindowsHandling.OpenBrowserTab(_driver);
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_newTabDriver).WaitForPresence(_legacyAppLogonSelectors.LoadOAS);
          });
          Assert.IsTrue(_newTabDriver.Title.Equals("Overseas Agencies Admin System"));
          Assert.IsTrue(new WebDriverExtensions(_newTabDriver).CaseInsensitiveContains(_newTabDriver.Url, urlString));
          break;

        case "OLR":
          _newTabDriver = WindowsHandling.OpenBrowserTab(_driver);
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_newTabDriver).WaitForPresence(_legacyAppLogonSelectors.LoadOLR);
          });
          Assert.IsTrue(_newTabDriver.Title.Equals("Register or Amend My Music - Home"));
          Assert.IsTrue(new WebDriverExtensions(_newTabDriver).CaseInsensitiveContains(_newTabDriver.Url, urlString));
          break;

        case "Admissions":
          TaskHelper.ExecuteTask(() =>
          {
            new IframeHelper(_driver).Iframe_PrsWriterMembershipApplication();
            new WebDriverExtensions(_driver).JavaScriptClick(_legacyAppLogonSelectors.LoadAdmissions);
          });
          Assert.IsTrue(_driver.Title.Equals("PRS Writer Membership Application"));
          Assert.IsTrue(new WebDriverExtensions(_driver).CaseInsensitiveContains(_driver.Url, urlString));
          break;

        default:
          throw new Exception("App Name Not Recognised");
      }
    }
  }
}
