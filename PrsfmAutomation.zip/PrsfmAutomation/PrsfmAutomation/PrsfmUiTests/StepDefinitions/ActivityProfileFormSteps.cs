﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class ActivityProfileFormSteps
    {
        private readonly IWebDriver _driver;
        private readonly ActivityProfileFormSelectors _activityProfileFormSelectors;

        public ActivityProfileFormSteps(IWebDriver driver)
        {
            _driver = driver;

            _activityProfileFormSelectors = new ActivityProfileFormSelectors();
            PageFactory.InitElements(_driver, _activityProfileFormSelectors);
        }


        [When(@"Complete activity profile Has your music been performed in public")]
        public void WhenCompleteActivityProfileHasYourMusicBeenPerformedInPublic(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_activityProfileFormSelectors.RadioButtonInPublicYes);
                
                switch ((string)formData.YesNo)
                {
                    case "Yes":
                        _activityProfileFormSelectors.RadioButtonInPublicYes.Click();
                        break;
                    case "No":
                        _activityProfileFormSelectors.RadioButtonInPublicNo.Click();
                        break;
                }
                _activityProfileFormSelectors.TextInPublic.SendKeys((string)formData.Example);
            });
        }

        [When(@"Complete activity profile Do you perform as part of a group")]
        public void WhenCompleteActivityProfileDoYouPerformAsPartOfAGroup(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_activityProfileFormSelectors.RadioButtonAsGroupYes);

                switch ((string)formData.YesNo)
                {
                    case "Yes":
                        _activityProfileFormSelectors.RadioButtonAsGroupYes.Click();
                        break;
                    case "No":
                        _activityProfileFormSelectors.RadioButtonAsGroupNo.Click();
                        break;
                }
                _activityProfileFormSelectors.TextAsGroup.SendKeys((string)formData.Example);
            });
        }

        [When(@"Complete activity profile Do you perform as a solo artist")]
        public void WhenCompleteActivityProfileDoYouPerformAsASoloArtist(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_activityProfileFormSelectors.RadioButtonSoloArtistYes);

                switch ((string)formData.YesNo)
                {
                    case "Yes":
                        _activityProfileFormSelectors.RadioButtonSoloArtistYes.Click();
                        break;
                    case "No":
                        _activityProfileFormSelectors.RadioButtonSoloArtistNo.Click();
                        break;
                }
                _activityProfileFormSelectors.TextSoloArtist.SendKeys((string)formData.Example);
            });
        }

        [When(@"Complete activity profile Where did you first hear about PRS for Music '(.*)'")]
        public void WhenCompleteActivityProfileWhereDidYouFirstHearAboutPrsForMusic(string item)
        {
            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).SelectFromDropDownList(_activityProfileFormSelectors.FirstHeardWhere, item);
            });
        }
    }
}
