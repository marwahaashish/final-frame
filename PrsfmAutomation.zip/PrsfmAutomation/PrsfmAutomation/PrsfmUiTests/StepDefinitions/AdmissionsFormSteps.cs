﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class AdmissionsFormSteps
    {
        private readonly IWebDriver _driver;
        private readonly AdmissionsFormSelectors _admissionsFormSelectors;

        public AdmissionsFormSteps(IWebDriver driver)
        {
            _driver = driver;

            _admissionsFormSelectors = new AdmissionsFormSelectors();
            PageFactory.InitElements(_driver, _admissionsFormSelectors);
        }


        [When(@"Enter details for admissions form name")]
        public void WhenEnterDetailsForAdmissionsFormName(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_admissionsFormSelectors.Title);
                new WebDriverExtensions(_driver).SelectFromDropDownList(_admissionsFormSelectors.Title, (string)formData.Title);
            });

            TaskHelper.ExecuteTask(() => 
            {_admissionsFormSelectors.Forename.SendKeys((string)formData.Forename);});

            TaskHelper.ExecuteTask(() => 
            {_admissionsFormSelectors.Surname.SendKeys((string)formData.Surname);});
        }

        [When(@"Enter details for admissions form personal details")]
        public void WhenEnterDetailsForAdmissionsFormPersonalDetails(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_admissionsFormSelectors.DobDay);
              
                  //_admissionsFormSelectors.DobDay.SendKeys(formData.Dd.ToString());
                  //_admissionsFormSelectors.DobMonth.SendKeys(formData.Mm.ToString());
                  //_admissionsFormSelectors.DobYear.SendKeys(formData.Yyyy.ToString());

              _admissionsFormSelectors.DobDay.SendKeys((string)formData.Dd.ToString());
              _admissionsFormSelectors.DobMonth.SendKeys((string)formData.Mm.ToString());
              _admissionsFormSelectors.DobYear.SendKeys((string)formData.Yyyy.ToString());
            });

            TaskHelper.ExecuteTask(() =>
            {new WebDriverExtensions(_driver).SelectFromDropDownList(_admissionsFormSelectors.Sex, (string)formData.Sex);});

            TaskHelper.ExecuteTask(() =>
            {new WebDriverExtensions(_driver).SelectFromDropDownList(_admissionsFormSelectors.Nationality, (string)formData.Nationality);});
        }

        [When(@"Enter details for admissions form contact details")]
        public void WhenEnterDetailsForAdmissionsFormContactDetails(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_admissionsFormSelectors.DaytimePhoneNumber);
                _admissionsFormSelectors.DaytimePhoneNumber.SendKeys((string)formData.DaytimeNumber.ToString());
                _admissionsFormSelectors.MobileTelephoneNumber.SendKeys((string)formData.MobileNumber.ToString());
            });

            switch ((string)formData.Email)
            {
                case "UniqueTimeStamp":
                    _admissionsFormSelectors.EmailAddress.SendKeys(new MemberSignUpSteps(_driver, null).uniqueEmailAddress);
                    break;
                case "None":
                    Console.WriteLine("Note... no details required");
                    break;
            }

            switch ((string)formData.EmailConfirm)
            {
                case "UniqueTimeStamp":
                    _admissionsFormSelectors.ConfirmEmailAddress.SendKeys(new MemberSignUpSteps(_driver, null).uniqueEmailAddress);
                    break;
                case "None":
                    Console.WriteLine("Note... no details required");
                    break;
            }
        }

        [When(@"Enter details for admissions form address")]
        public void WhenEnterDetailsForAdmissionsFormAddress(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
              new WebDriverExtensions(_driver).JavaScriptClick(_admissionsFormSelectors.AddressCountry);             
                _admissionsFormSelectors.AddressCountry.SendKeys(Keys.ArrowDown);
                _admissionsFormSelectors.AddressCountry.SendKeys(Keys.Return);
            });

            TaskHelper.ExecuteTask(() =>
            {
                _admissionsFormSelectors.Postcode.SendKeys((string)formData.Postcode.ToString());
                _admissionsFormSelectors.AddressLine1.SendKeys((string)formData.Line1);
                _admissionsFormSelectors.AddressLine2.SendKeys((string)formData.Line2.ToString());
                _admissionsFormSelectors.AddressLine3.SendKeys((string)formData.Line3);
                _admissionsFormSelectors.City.SendKeys((string)formData.City);
                _admissionsFormSelectors.County.SendKeys((string)formData.County);
            });
        }

        [Then(@"Submit membership application form")]
        public void ThenSubmitMembershipApplicationForm()
        {
            TaskHelper.ExecuteTask(() =>
            {             
              new WebDriverExtensions(_driver).JavaScriptClick(_admissionsFormSelectors.Next);
            });
        }
    }
}
