﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class MakeaClaimForMusicUsageSteps
    {
        private readonly IWebDriver _driver;
        private readonly MakeaClaimForMusicUsageSelectors _makeaClaimForMusicUsageSelectors;
        private readonly NewClaimOverseasMusicUsageSelectors _claimOverseasMusicUsageSelectors;

        public MakeaClaimForMusicUsageSteps(IWebDriver driver)
        {
            _driver = driver;

            _makeaClaimForMusicUsageSelectors = new MakeaClaimForMusicUsageSelectors();
            PageFactory.InitElements(_driver, _makeaClaimForMusicUsageSelectors);

            _claimOverseasMusicUsageSelectors = new NewClaimOverseasMusicUsageSelectors();
            PageFactory.InitElements(_driver, _claimOverseasMusicUsageSelectors);
        }


        [When(@"Select the new claim location")]
        public void WhenSelectTheNewClaimLocation(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            switch ((string)formData.Location)
            {
                case "Overseas":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath(_makeaClaimForMusicUsageSelectors.OverseasButton)));
                        new WebDriverExtensions(_driver).JavaScriptClick(_driver.FindElement(By.XPath(_makeaClaimForMusicUsageSelectors.OverseasButton)));
                    });
                    break;

                case "Uk":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath(_makeaClaimForMusicUsageSelectors.UkButton)));
                        new WebDriverExtensions(_driver).JavaScriptClick(_driver.FindElement(By.XPath(_makeaClaimForMusicUsageSelectors.UkButton)));
                    });
                    break;
            }
        }

        [Then(@"Discard new claim if option given")]
        public void ThenDiscardNewClaimIfOptionGiven()
        {
            bool? trueFalse = null;
            trueFalse = new WebDriverExtensions(_driver).IsElementVisible(_driver, By.XPath(_claimOverseasMusicUsageSelectors.Discard));

            if (trueFalse == true)
            {
                Console.WriteLine("*** Discard button visible");
                TaskHelper.ExecuteTask(() =>
                {
                    _driver.FindElement(By.XPath(_claimOverseasMusicUsageSelectors.Discard)).Click();
                });

            }
            else
            {
                Console.WriteLine("*** Discard button NOT visible");
            }
        }
    }
}
