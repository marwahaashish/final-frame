﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using System;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions
{
  [Binding]
  public class HomepageSteps
  {
    private readonly IWebDriver _driver;

    private readonly NavigationBarSelectors _navigationBarSelectors;
    private readonly HomepageSelectors _homepageSelectors;

    public HomepageSteps(IWebDriver driver)
    {
      _driver = driver;

      _navigationBarSelectors = new NavigationBarSelectors();
      PageFactory.InitElements(_driver, _navigationBarSelectors);

      _homepageSelectors = new HomepageSelectors();
      PageFactory.InitElements(_driver, _homepageSelectors);
    }


    [When(@"Select service tile '(.*)'")]
    public void WhenSelectServiceTile(string tileType)
    {
      TaskHelper.ExecuteTask(() =>
      {
        if (tileType == "Claim music usage overseas")
        {
          new WebDriverExtensions(_driver).WaitForPresence(_homepageSelectors.ClickShowMore);
          new WebDriverExtensions(_driver).JavaScriptClick(_homepageSelectors.ClickShowMore);
          new WebDriverExtensions(_driver).WaitForPresence(_homepageSelectors.ServiceClaimMusicUsageOverseas);
          new WebDriverExtensions(_driver).JavaScriptClick(_homepageSelectors.ServiceClaimMusicUsageOverseas);
          new WebDriverExtensions(_driver).WaitForPresence(_homepageSelectors.ClickMakeAClaim);
          new WebDriverExtensions(_driver).JavaScriptClick(_homepageSelectors.ClickMakeAClaim);
        }
        else
        {
          new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath(_homepageSelectors.ServiceTile(tileType))));
          new WebDriverExtensions(_driver).JavaScriptClick(_driver.FindElement(By.XPath(_homepageSelectors.ServiceTile(tileType))));
        }
      });
    }

    [Then(@"Click home page Report button")]
    public void ThenClickHomePageReportButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_homepageSelectors.ReportPerformanceButton);
        new WebDriverExtensions(_driver).JavaScriptClick(_homepageSelectors.ReportPerformanceButton)    ;

      });
    }

    [Then(@"Click Report Page Report live button")]
    public void ThenClickReportPageReportLiveButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_homepageSelectors.ReportLivePerformanceButton);
        new WebDriverExtensions(_driver).JavaScriptClick(_homepageSelectors.ReportLivePerformanceButton);

      });
    }
  }
}
