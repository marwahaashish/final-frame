﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using System.Threading;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class SummaryFormSteps
    {
        private readonly IWebDriver _driver;
        private readonly SummaryFormSelectors _subSummaryFormSelectors;

        public SummaryFormSteps(IWebDriver driver)
        {
            _driver = driver;

            _subSummaryFormSelectors = new SummaryFormSelectors();
            PageFactory.InitElements(_driver, _subSummaryFormSelectors);
        }


        [Then(@"Submit membership application form once completed")]
        public void ThenSubmitMembershipApplicationFormOnceCompleted()
        {
            TaskHelper.ExecuteTask(() =>
            {              
              new WebDriverExtensions(_driver).JavaScriptClick(_subSummaryFormSelectors.SubmitCompletedForm);
            });
        }
    }
}
