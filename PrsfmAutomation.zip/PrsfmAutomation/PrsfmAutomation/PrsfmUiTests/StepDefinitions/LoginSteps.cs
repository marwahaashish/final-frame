﻿using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class LoginSteps
    {
        private readonly IWebDriver _driver;
        private readonly LoginSelectors _loginSelectors;

        public LoginSteps(IWebDriver driver)
        {
            _driver = driver;

            _loginSelectors = new LoginSelectors();
            PageFactory.InitElements(_driver, _loginSelectors);
        }


        [When(@"Select login more options '(.*)'")]
        public void WhenSelectLoginMoreOptions(string p0)
        {
            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_loginSelectors.SignUpForAnOnlineAccount);
                _loginSelectors.SignUpForAnOnlineAccount.Click();
            });
        }

        [When(@"Select membership online account")]
        public void WhenSelectMembershipOnlineAccount(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).JavaScriptSelectFromDropDownList((string)formData.Type);
            });
        }


        [Then(@"Click login page register")]
        public void ThenClickLoginPageRegister()
        {
            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).MoveToElement(_loginSelectors.Register);
                _loginSelectors.Register.Click();
            });
        }

        [When(@"Complete member login form")]
        public void WhenCompleteMemberLoginForm(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_loginSelectors.Email);
                _loginSelectors.Email.SendKeys((string)formData.Email);
                _loginSelectors.Email.SendKeys(Keys.Tab);
                _loginSelectors.Password.SendKeys((string)formData.Password);
            });

            if ((string) formData.CaeAmount == "Multiple")
            {
                TaskHelper.ExecuteTask(() =>
                {
                    new WebDriverExtensions(_driver).WaitForPresence(_loginSelectors.CaeNumber);
                    _loginSelectors.CaeNumber.SendKeys((string)formData.CaeIpiNumber.ToString());
                });
            }
        }

    [When(@"Complete login form")]
    public void WhenCompleteLoginForm(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_loginSelectors.Email);
        _loginSelectors.Email.SendKeys((string)formData.Email);
        _loginSelectors.Email.SendKeys(Keys.Tab);
        _loginSelectors.Password.SendKeys((string)formData.Password);
      });
    }

    [Then(@"Click login page log in button")]
        public void ThenClickLoginPageLogInButton()
        {
            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_loginSelectors.SignIn);
                _loginSelectors.SignIn.Click();
            });
        }
    }
}
