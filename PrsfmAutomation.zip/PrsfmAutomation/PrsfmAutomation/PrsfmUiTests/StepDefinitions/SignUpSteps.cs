﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class SignUpSteps
    {
        private readonly IWebDriver _driver;
        private readonly SignUpSelectors _signUpSelectors;

    public SignUpSteps(IWebDriver driver)
    {
      _driver = driver;

      _signUpSelectors = new SignUpSelectors();
      PageFactory.InitElements(_driver, _signUpSelectors);
    }


      [When(@"Select writer or publisher membership online account")]
      public void WhenSelectWriterOrPublisherMembershipOnlineAccount()
      {

        TaskHelper.ExecuteTask(() =>
        {
          new WebDriverExtensions(_driver).WaitForPresence(_signUpSelectors.RegsiterForWriterOrPublisherAccount);
          ((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].click();", _signUpSelectors.RegsiterForWriterOrPublisherAccount);
        });
      }

    
      [When(@"Select Music licence customer")]
      public void WhenSelectMusicLicenceCustomer()
      {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_signUpSelectors.RegsiterForLicenceAccount);
        new WebDriverExtensions(_driver).JavaScriptClick(_signUpSelectors.RegsiterForLicenceAccount);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_signUpSelectors.SignUpLicence);
        new WebDriverExtensions(_driver).JavaScriptClick(_signUpSelectors.SignUpLicence);
      });
    }


  }
}
