﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.WebUserAdmin
{
  class WebUserAdminSelectors
  {
    [FindsBy(How = How.Name, Using = "loginfmt")]
    public IWebElement WebUserLogin { get; set; }

    [FindsBy(How = How.Id, Using = "idSIButton9")]
    public IWebElement WebUserNext { get; set; }   

    [FindsBy(How = How.Id, Using = "organisationsBtn")]
    public IWebElement SelectAdministration { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Members')]")]
    public IWebElement SelectMembers { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'All Members')]")]
    public IWebElement SelectAllMembers { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Licensee')]")]
    public IWebElement SelectLicensees { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'All Licensees')]")]
    public IWebElement SelectAllLicensees { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Third Parties')]")]
    public IWebElement SelectThirdParties { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'All Third Parties')]")]
    public IWebElement SelectAllThirdParties { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Overseas')]")]
    public IWebElement SelectOverseas { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'All Overseas')]")]
    public IWebElement SelectAllOverseas { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Affiliate')]")]
    public IWebElement SelectAffiliate { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'All Affiliates')]")]
    public IWebElement SelectAllAffiliate { get; set; }

    [FindsBy(How = How.Name, Using = "searchTerm")]
    public IWebElement EnterSearchTerm { get; set; }

    [FindsBy(How = How.Name, Using = "searchButton")]
    public IWebElement ClickSearchButton { get; set; }

    [FindsBy(How = How.Name, Using = "lgSearchButton")]
    public IWebElement ClickMemberSearchButton { get; set; }
    

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Add')]")]
    public IWebElement ClickAddButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'A D Music')]")]
    public IWebElement SearchSuccessMessageMemeber { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Abbott Mead Vickers')]")]
    public IWebElement SearchSuccessMessageLicensee { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'The PRS Foundation')]")]
    public IWebElement SearchSuccessMessageThirdParties { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'PRS Overseas Agents')]")]
    public IWebElement SearchSuccessMessageOverseas { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'AGADU')]")]
    public IWebElement SearchSuccessMessageAffiliate { get; set; }

    [FindsBy(How = How.XPath, Using = "//legend[contains(text(),'User Details')]")]
    public IWebElement SearchSuccessMessageAddMember { get; set; }

    [FindsBy(How = How.Id, Using = "inputON")]
    public IWebElement MemberName { get; set; }

    [FindsBy(How = How.Id, Using = "inputIPINumber")]
    public IWebElement MemberIPINumber { get; set; }

    [FindsBy(How = How.Id, Using = "inputMembershipId")]
    public IWebElement MembershipId { get; set; }

    [FindsBy(How = How.Id, Using = "rdMemberType1")]
    public IWebElement RadioButtonWriter { get; set; }

    [FindsBy(How = How.XPath, Using = "//div/select/option[2]")]
    public IWebElement SocietyAffiliation { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[@id='first']/div[3]/div/button")]
    public IWebElement SaveMember { get; set; }

    [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Member Type')]")]
    public IWebElement CheckSaveMember { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[@id='UserProfilesSearch']//a[contains(text(),'View')]")]
    public IWebElement ClickView { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Add Member')]")]
    public IWebElement ClickAddMember{ get; set; }

    [FindsBy(How = How.Id, Using = "txtOrgSearch")]
    public IWebElement AddMemberSeachTerm { get; set; }

    [FindsBy(How = How.XPath, Using = "//li[contains(text(),'1472629 - Ashfield R J')]")]
    public IWebElement AddMemberAutoSeachTerm { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Next')]")]
    public IWebElement ClickNext { get; set; }

    [FindsBy(How = How.XPath, Using = "//div/button[@class='btn btn-primary btn-save-parent btndisableonclick']")]
    public IWebElement ClickAddPopupButton { get; set; }


    [FindsBy(How = How.Id, Using = "inputON")]
    public IWebElement LicenseeCompanyName { get; set; }

    [FindsBy(How = How.Id, Using = "inlineRadio1")]
    public IWebElement RadioButtonSignUpApprovalType { get; set; }

    [FindsBy(How = How.Id, Using = "inlineRadio2")]
    public IWebElement RadioButtonWhiteLsitedApprovalType { get; set; }

    [FindsBy(How = How.Name, Using = "DomainNames")]
    public IWebElement AddDomainNames { get; set; }    

    [FindsBy(How = How.XPath, Using = "//div/select/option[2]")]
    public IWebElement LicenseeCompanyType { get; set; }

    [FindsBy(How = How.XPath, Using = "//div/button[@class='btn btn-primary btnOrgAdditionalSave btndisableonclick']")]
    public IWebElement SaveLicensee { get; set; }

    [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Company Name')]")]
    public IWebElement CheckLicensee { get; set; }

    [FindsBy(How = How.Id, Using = "inputON")]
    public IWebElement ThirdPartyOrganisationName { get; set; }

    [FindsBy(How = How.Id, Using = "inputBusinessOwner")]
    public IWebElement ThirdPartyBusinessOwner { get; set; }

    [FindsBy(How = How.XPath, Using = "//div/button[@class='btn btn-primary btnOrgAdditionalSave btndisableonclick']")]
    public IWebElement SaveThirdParty { get; set; }

  }
}
