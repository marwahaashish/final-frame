﻿using Microsoft.SqlServer.Server;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class SharedSelectors
    {
        public string PageTitleH2(string title)
        {
            return $"//h2[contains(text(),'{title}')]";
        }

        public string PageTitleH2WithSpan(string title)
        {
            return $"//h2/span[contains(text(),'{title}')]";
        }

        public string WarningMessageText(string text)
        {
            return $"//ul/li[contains(text(),'{text}')]";
        }

        
        [FindsBy(How = How.XPath, Using = "//input[@value='Next']")]
        public IWebElement NextButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@value='Submit']")]
        public IWebElement SubmitButton { get; set; }

        // Page 'Please Wait' message
        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Please wait')]")]
        public IWebElement PleaseWaitMessage { get; set; }

        
    }
}
