﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class SignUpSelectors
    {  
        [FindsBy(How = How.XPath, Using = "//h4[contains(text(),'Writer or publisher membership')]")]
        public IWebElement RegsiterForWriterOrPublisherAccount{ get; set; }
   
        [FindsBy(How = How.XPath, Using = "//h4[contains(text(),'Music licence customer')]")]
        public IWebElement RegsiterForLicenceAccount { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'use-music')]")]
        public IWebElement SignUpLicence{ get; set; }
  
  }
}
