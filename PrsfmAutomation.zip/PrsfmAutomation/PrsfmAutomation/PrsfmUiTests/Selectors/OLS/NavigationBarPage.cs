﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace OlsUiTests.Pages
{
  internal class NavigationBarPage : WebDriverExtensions
  {
    public NavigationBarPage(IWebDriver driver)
        : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//div[@id='navbar']/ul/li[1]/a")]
    public IWebElement PRSFMSite { get; set; }


    public bool PRSFMSiteIsLaunched()
    {
      return DoesElementExist(PRSFMSite);
    }
  }
}
