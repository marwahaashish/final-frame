﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OlsUiTests.Pages
{
  internal class StatementSelectorPage : WebDriverExtensions
  {
    public StatementSelectorPage(IWebDriver driver)
        : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//h1[contains(text(), 'Statements')]")]
    public IWebElement OLSTitle { get; set; }


    public string AssertOLSHomePage()
    {
      return GetElementText(OLSTitle);
    }
  }
}
