﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OlsUiTests.Pages
{
  internal class AllWorksAndAdjustmentsPage : WebDriverExtensions
  {
    public AllWorksAndAdjustmentsPage(IWebDriver driver)
        : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//section//table[@data-attr='table-works']]")]
    public IWebElement AllWorksTable { get; set; }

    [FindsBy(How = How.XPath, Using = "//section//table[@data-attr='table-adjustments']")]
    public IWebElement AllAdjustmentsTable { get; set; }

    [FindsBy(How = How.XPath, Using = "//dl[1]/dd[@class='statement-header__desc statement-header__amount']")]
    public IWebElement RoyaltyAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//h1")]
    public IWebElement Society { get; set; }

    [FindsBy(How = How.XPath, Using = "//dl/dd[2]")]
    public IWebElement Distribution { get; set; }

    [FindsBy(How = How.XPath, Using = "//dl/dd[@data-attr='statement-royalty-earner']")]
    public IWebElement RoyaltyName { get; set; }

    [FindsBy(How = How.XPath, Using = "//dl[2]/dd")]
    public IWebElement IpiNum { get; set; }

    [FindsBy(How = How.XPath, Using = "//table[@data-attr='table-works']//span[@role='button'][contains(text(), 'Work title')]")]
    public IWebElement AllWorksSortArrow { get; set; }

    [FindsBy(How = How.XPath, Using = "//table[@data-attr='table-adjustments']//span[@role='button'][contains(text(), 'Work title')]")]
    public IWebElement AdjustmentsSortArrow { get; set; }

    [FindsBy(How = How.XPath, Using = "//table[@data-attr='table-works']//tbody/tr[1]/td[1]")]
    public IWebElement FirstTitleAllWorks { get; set; }

    [FindsBy(How = How.XPath, Using = "//table[@data-attr='table-adjustments']//tbody/tr[1]/td[1]")]
    public IWebElement FirstTitleAdjustments { get; set; }


    public bool isAllWorksTableDisplayed()
    {
      return DoesElementExist(AllWorksTable);
    }

    public bool isAdjustmentsTableDisplayed()
    {
      return DoesElementExist(AllAdjustmentsTable);
    }

    public string GetRoyaltyAmount()
    {
      return GetElementText(RoyaltyAmount);
    }

    public string GetSociety()
    {
      return GetElementText(Society);
    }

    public string GetDistribution()
    {
      return GetElementText(Distribution);
    }

    public string GetRoyaltyName()
    {
      return GetElementText(RoyaltyName);
    }

    public string GetIpiNum()
    {
      return GetElementText(IpiNum);
    }

    public void ClickAllWorkTablesSortingArrow()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(AllWorksSortArrow);
        SafeJavaScriptClick(AllWorksSortArrow);
      });
    }

    public void ClickAdjustmentsTableSortingArrow()
    {
      SafeClick(AdjustmentsSortArrow);
    }

    public string GetAllWorksFirstWorkTitle()
    {
      Thread.Sleep(9000);
      return GetElementText(FirstTitleAllWorks);
    }

    public string GetAdjustmentsFirstWorkTitle()
    {
      Thread.Sleep(9000);
      return GetElementText(FirstTitleAdjustments);
    }

  }
}
