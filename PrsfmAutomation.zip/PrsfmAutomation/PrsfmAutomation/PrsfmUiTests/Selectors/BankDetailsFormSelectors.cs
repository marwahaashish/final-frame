﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class BankDetailsFormSelectors
    {
        [FindsBy(How = How.Id, Using = "app_sort_code")]
        public IWebElement SortCode { get; set; }

        [FindsBy(How = How.Id, Using = "btnValidateSortCode")]
        public IWebElement ValidateSortCode { get; set; }

        [FindsBy(How = How.Id, Using = "app_account_number")]
        public IWebElement AccountNumber { get; set; }

        [FindsBy(How = How.Id, Using = "app_account_name")]
        public IWebElement NameInAccout { get; set; }

        [FindsBy(How = How.Id, Using = "app_bank_name")]
        public IWebElement NameOfBank { get; set; }

        [FindsBy(How = How.Id, Using = "app_bank_branch")]
        public IWebElement AddressOfBank { get; set; }
    }
}
