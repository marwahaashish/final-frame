﻿namespace PrsfmUiTests.Selectors
{
    public class SidebarMenuSelectors
    {
        public string SidebarMenuLink(string item)
        {
            return $"//div[@class='sidebar__container']//a[contains(text(),'{item}')]";
        }

    }
}
