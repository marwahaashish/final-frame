﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class NewClaimRadioSelectors
    {
        [FindsBy(How = How.XPath, Using = "//div[div/span[contains(text(),'Please enter the name of the Artist')]]//input[@type='text']")]
        public IWebElement NameOfTheArtist { get; set; }

        // Select Works Form
        [FindsBy(How = How.XPath, Using = "//input[@value='Title']")]
        public IWebElement SelectWorksTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@value='Writer last name']")]
        public IWebElement SelectWorksLastName { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@value='First name']")]
        public IWebElement SelectWorksFirstName { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@value='Tunecode']")]
        public IWebElement SelectWorksTunecode { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='uc_2_ctl02_OOMUWebPart_step2SearchTunecodes']")]
        public IWebElement SelectWorksTunecodeGo { get; set; }

        public string TunecodeTableResults(string itemCode)
        {
            return $"//div[@class='step2TablePanel']//td[contains(text(),'{0}')]";
        }

        // My Usage Details Form
        [FindsBy(How = How.XPath, Using = "//div[@class='ddlShort']")]
        public IWebElement CountryOfUsageDropdown { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[div[contains(@class, 'ui-label') and normalize-space(text()) = 'Station']]/div/div/div/input[not(@disabled)]")]
        public IWebElement Station { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[contains(@name,'StartDateBroadCastStartDate')]")]
        public IWebElement BroadcastStartDate { get; set; }

        [FindsBy(How = How.Name, Using = "uc_2$ctl02$OOMUWebPart$step3AddVenue")]
        public IWebElement Add { get; set; }

        public string UsageSummaryTableResults(string stationName)
        {
            return $"//div[@class='Step3TablePanel']//td[contains(text(),'{0}')]";
        }

        // Claim Summary
        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Claim Summary')]")]
        public IWebElement ClaimSummaryTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[contains(@class,'tableprs')]")]
        public IWebElement ClaimSummaryTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[5]/table[contains(@class,'tableprs')]")]
        public IWebElement ClaimSummaryTableOne { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[7]/table[contains(@class,'tableprs')]")]
        public IWebElement ClaimSummaryTableTwo { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Claim submitted')]")]
        public IWebElement ClaimSubmittedTitle { get; set; }
    }
}
