﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class LoginSelectors
    {
        [FindsBy(How = How.LinkText, Using = "Sign up for an online account")]
        public IWebElement SignUpForAnOnlineAccount { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@title='Register']")]
        public IWebElement Register { get; set; }

        [FindsBy(How = How.Id, Using = "logonIdentifier")]
        public IWebElement Email { get; set; }

        [FindsBy(How = How.Id, Using = "password")]
        public IWebElement Password { get; set; }

        [FindsBy(How = How.Id, Using = "next")]
        public IWebElement SignIn { get; set; }

        [FindsBy(How = How.Id, Using = "cae")]
        public IWebElement CaeNumber { get; set; }
    }
}
