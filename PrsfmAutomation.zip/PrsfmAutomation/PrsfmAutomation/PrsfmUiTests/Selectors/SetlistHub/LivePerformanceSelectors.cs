﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors.SetlistHub
{
   public class LivePerformanceSelectors
    {
        [FindsBy(How = How.XPath, Using = "//div[@class='create-a-setlist btn btn--square btn--block btn-size-lg btn-primary vertical-align-middle']")]
        public IWebElement ReportLivePerformanceButton2 { get; set; }

        
        [FindsBy(How = How.Id, Using = "datepicker")]
        public IWebElement PerformanceDatePicker { get; set; }

        [FindsBy(How = How.Id, Using = "territorySearch")]
        public IWebElement CountrySearch { get; set; }

        [FindsBy(How = How.Id, Using = "eventSearch")]
        public IWebElement VenueSearch { get; set; }

        [FindsBy(How = How.Id, Using = "name")]
        public IWebElement AssimilateVenueSearch { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary btn-set-list']")]
        public IWebElement AssimilateSearch { get; set; }

       [FindsBy(How = How.Id, Using = "googleVenueSearch")]
        public IWebElement GooglevenueSearch { get; set; }

        [FindsBy(How = How.Id, Using = "newgoogleVenueSearch")]
        public IWebElement NewgoogleVenueSearch { get; set; }

        [FindsBy(How = How.Id, Using = "performerName")]
        public IWebElement PerformerName { get; set; }

        [FindsBy(How = How.Id, Using = "workSearch")]
        public IWebElement WorkSearch { get; set; }

        [FindsBy(How = How.Id, Using = "setListName")]
        public IWebElement SetListName { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'We require additional validation where members report a performance which is more than seven years old. Please')]")]
        public IWebElement Greater7YrsMsg { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'International performances must have occurred in the past two years in order to be valid')]")]
        public IWebElement Greater2YrsMsg { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Your performance at this venue must have occurred in the past year in order to be valid.')]")]
        public IWebElement Equal1YrMsg { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Please select valid country')]")]
        public IWebElement InvaldCountry { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='event-details ng-scope']")]
        public IWebElement WhiteSpace { get; set; }

        
        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Amend Festival details')]")]
        public IWebElement AmendFestivalButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[input[@id='festivalName']]/span[contains(text(),'You have exceeded the maximum character limit for this field.')]")]
        public IWebElement InvalidFestivalVenueMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[input[@id='venueName']]/span[contains(text(),'You have exceeded the maximum character limit for this field.')]")]
        public IWebElement InvalidVenueNameMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'Headliner')]")]
        public IWebElement HeadlinerRadioButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'Yes')]")]
        public IWebElement YesRadioButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'No')]")]
        public IWebElement NoRadioButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'Support act')]")]
        public IWebElement SupportActRadioButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'Yes')]")]
        public IWebElement YesFestivalRadioButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'No')]")]
        public IWebElement NoFestivalRadioButton { get; set; }

        public string SavedPerformanceDetail(string item)
        {
           
            return $"//span[contains(text(),'{item}')]";
        }

        public string WorksList(string item)
        {

            return $"//li[1][//span[contains(text(),'{item}')]]//button[@class='btn item-list__button add']";
        }

        public string WorklistDetail(string item)
        {
            return $"//div[@class='work-info']/div[contains(text(),'{item}')]";
        }

        public string Tunecode(string item)
        {
            
            return $"//span[contains(@class,'setlist-item-sub-content ng-binding') and contains(text(),'{item}')]";
        }

    

        public string HighlightedAssimilateResult(string item)
        {

          return $"(//span[contains(text(),'{item}')])";
        }
       public string HighlightedResult(string item)
        {
          
            return $"//span[contains(@class,'item-list__item-title')]/span[contains(text(),'{item}')]";
        }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Find more venues')]")]
        public IWebElement FindMoreVenues { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Google')]")]
        public IWebElement FindGoogleVenues { get; set; }

        [FindsBy(How = How.XPath, Using = "//button/span[contains(text(),'Add venue details manually')]")]
        public IWebElement AddVenueDetailsManually { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='event-form__row text-center']/a")]
        public IWebElement AddAssimilateVenueDetailsManually { get; set; }

       [FindsBy(How = How.Id, Using = "venueName")]
        public IWebElement AddVenueDetailsManuallyName { get; set; }

        [FindsBy(How = How.Id, Using = "venueCityState")]
        public IWebElement AddVenueDetailsManuallyCity { get; set; }

        [FindsBy(How = How.Id, Using = "venuePostcode")]
        public IWebElement AddVenueDetailsManuallyPostCode { get; set; }


        [FindsBy(How = How.Id, Using = "festivalName")]
        public IWebElement FestivalName { get; set; }

        [FindsBy(How = How.Id, Using = "stageName")]
        public IWebElement FestivalStage { get; set; }

        [FindsBy(How = How.Id, Using = "festivalCity")]
        public IWebElement Festivalvenue { get; set; }

        [FindsBy(How = How.Id, Using = "festivalPostcode")]
        public IWebElement FestivalPostcode { get; set; }

        [FindsBy(How = How.Id, Using = "festivalPostcode")]
        public IWebElement reviewFestivalName { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary']")]
        public IWebElement SubmitButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Save for later')]")]
        public IWebElement SaveForLaterButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Add Festival details')]")]
        public IWebElement AddFestivalsButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Add works')]")]
        public IWebElement AddWorksButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Done')]")]
        public IWebElement AddWorksDoneButton { get; set; }

        
        [FindsBy(How = How.XPath, Using = "//div[@class='headerDiv'][contains(text(),'Register or amend my music')]")]
        public IWebElement RegisterWorksPageHeader { get; set; }


        [FindsBy(How = How.XPath, Using = "//h2[contains(text(), 'Add works')]")]
        public IWebElement AddWorksLabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='work-info']/div[@ng-class]")]
        public IWebElement WorklistDetails { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='close-icon__setlist-item-remove']")]
        public IWebElement DeleteWorklistIcon { get; set; }

        
        [FindsBy(How = How.XPath, Using = "//a[@href='#/modal/add-existing-setlist']")]
        public IWebElement AddExistingSetList { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//li[1]//a[contains(@class,'checkbox')]")]
        public IWebElement SelectExistingSetList { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@ng-click='vm.addToPerformance()']")]
        public IWebElement AddSetListbutton { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//a[@ng-click='vm.toggleAdvancedSearch()']")]
        public IWebElement AdvancedWorksearchLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@ng-click='vm.registerWork()']")]
        public IWebElement CantFindItLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'find a work?')]")]
        public IWebElement CantFindItText { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(@class,'register-works-content')]//a[contains(@href,'Welcome')]")]
        public IWebElement RegisterYourWorkHere { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href,'prsformusic.com/societies/services/Pages/querytool.aspx')]")]
        public IWebElement Uploadfiches { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//div[@class='headerDiv'][contains(text(),'Register or amend my music')]")]
        public IWebElement RegisterYourWorkHereTitle { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//div[h1[contains(text(), 'Sure you')]]//button[./text()='Submit']")]
        public IWebElement FinalSubmit { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Create a new set list')]")]
        public IWebElement CreateAnewSetList { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[h1[contains(text(),'Thank you for reporting your performance.')]]")]
        public IWebElement FinalSubmitPageText { get; set; }

        
        [FindsBy(How = How.XPath, Using = "//img[@src='../assets/images/prs-logo.svg']")]
        public IWebElement PRSLogo { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[@src='/assets/images/prs-logo.svg']")]
        public IWebElement AssimilatePRSLogo { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Contact us')]")]
        public IWebElement ContactUs { get; set; }

        public string WorkInfo = "//div[@class='work-info']/div[@ng-class]";

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Live Performances')]")]
        public IWebElement LivePerformances { get; set; }
  }
}
