﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class HomepageSelectors
    {
        public string ServiceTile(string tileType)
        {
            return $"//ul[contains(@class,'row list')]/li/a/h3[contains(text(),'{tileType})]";
        }

        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Claim')]")]
        public IWebElement ServiceClaimMusicUsageOverseas { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href,'make-a-claim-music-usage-uk-overseas')]")]
        public IWebElement ClickMakeAClaim { get; set; }

       [FindsBy(How = How.XPath, Using = "//a[@href='/royalties/report-live-performances']")]
        public IWebElement ReportPerformanceButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/a[contains(text(),'Report a live performance')]")]
        public IWebElement ReportLivePerformanceButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Show More')]")]
        public IWebElement ClickShowMore { get; set; }

  }
}
