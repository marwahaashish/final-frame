﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
  public class MemberSignUpSelectors
  {
    [FindsBy(How = How.Name, Using = "MembershipNumber")]
    public IWebElement MembershipNumber { get; set; }

    [FindsBy(How = How.Name, Using = "Firstname")]
    public IWebElement FirstName { get; set; }

    [FindsBy(How = How.Name, Using = "Secondname")]
    public IWebElement LastName { get; set; }

    [FindsBy(How = How.Name, Using = "MemberName")]
    public IWebElement MemberName { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='member-type-selection']/div[2]/label/span")]
    public IWebElement MemberRoleWriter { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='member-type-selection']/div[1]/label/span")]
    public IWebElement MemberRolePublisher { get; set; }

    [FindsBy(How = How.Name, Using = "JobDescription")]
    public IWebElement JobDescription { get; set; }

    [FindsBy(How = How.Name, Using = "EMail")]
    public IWebElement EmailAddress { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='are-you-the-member-selection']/div[2]/label/span")]
    public IWebElement RadioButtonAreYouMemberYes { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='are-you-the-member-selection']/div[1]/label/span")]
    public IWebElement RadioButtonAreYouMemberNo { get; set; }

    [FindsBy(How = How.Name, Using = "IdentityCheck")]
    public IWebElement IdentityCheck { get; set; } 

    [FindsBy(How = How.XPath, Using = "//input[@value='Submit']")]
    public IWebElement Submit { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='col-xxs-10 col-sm-8 col-xxs-push-0']")]
    public IWebElement SignUpComplete { get; set; }

  }
}
