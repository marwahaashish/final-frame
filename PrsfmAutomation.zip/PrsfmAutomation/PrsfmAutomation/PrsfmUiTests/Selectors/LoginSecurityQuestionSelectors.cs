﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class LoginSecurityQuestionSelectors
    {
        [FindsBy(How = How.Id, Using = "security_question")]
        public IWebElement SecurityQuestionTextbox { get; set; }

        [FindsBy(How = How.Id, Using = "security_answer")]
        public IWebElement SecurityAnswerTextbox { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='submit']")]
        public IWebElement SubmitButton { get; set; }

    }
}
