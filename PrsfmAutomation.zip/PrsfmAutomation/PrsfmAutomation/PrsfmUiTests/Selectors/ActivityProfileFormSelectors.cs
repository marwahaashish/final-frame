﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class ActivityProfileFormSelectors
    {
        // Public
        [FindsBy(How = How.Id, Using = "rblPublicPerformance_0")]
        public IWebElement RadioButtonInPublicYes { get; set; }

        [FindsBy(How = How.Id, Using = "rblPublicPerformance_1")]
        public IWebElement RadioButtonInPublicNo { get; set; }

        [FindsBy(How = How.Id, Using = "app_public_performance")]
        public IWebElement TextInPublic { get; set; }

        // Group
        [FindsBy(How = How.Id, Using = "rblPerformGroup_0")]
        public IWebElement RadioButtonAsGroupYes { get; set; }

        [FindsBy(How = How.Id, Using = "rblPerformGroup_1")]
        public IWebElement RadioButtonAsGroupNo { get; set; }

        [FindsBy(How = How.Id, Using = "app_group_name")]
        public IWebElement TextAsGroup { get; set; }

        // Solo artist
        [FindsBy(How = How.Id, Using = "rblSoloSinger_0")]
        public IWebElement RadioButtonSoloArtistYes { get; set; }

        [FindsBy(How = How.Id, Using = "rblSoloSinger_1")]
        public IWebElement RadioButtonSoloArtistNo { get; set; }

        [FindsBy(How = How.Id, Using = "app_solo")]
        public IWebElement TextSoloArtist { get; set; }

        // Hear
        [FindsBy(How = How.Id, Using = "app_profile_prs")]
        public IWebElement FirstHeardWhere { get; set; }
    }
}
