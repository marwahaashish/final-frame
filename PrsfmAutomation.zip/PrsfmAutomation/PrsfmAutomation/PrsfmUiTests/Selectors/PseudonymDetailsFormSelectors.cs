﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class PseudonymDetailsFormSelectors
    {
        [FindsBy(How = How.Id, Using = "app_pseudonym_forenames1")]
        public IWebElement ForenameTextOne { get; set; }

        [FindsBy(How = How.Id, Using = "app_pseudonym_surname1")]
        public IWebElement SurnameTextOne { get; set; }
    }
}
