﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class SummaryFormSelectors
    {
        [FindsBy(How = How.Id, Using = "submit_page")]
        public IWebElement SubmitCompletedForm { get; set; }
    }
}
