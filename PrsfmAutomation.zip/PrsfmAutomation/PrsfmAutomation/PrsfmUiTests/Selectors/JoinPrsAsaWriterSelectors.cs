﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class JoinPrsAsaWriterSelectors
    {
        [FindsBy(How = How.XPath, Using = "//form[@name='form1']")]
        public IWebElement Form { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='submit']")]
        public IWebElement Accept { get; set; }
    }
}
