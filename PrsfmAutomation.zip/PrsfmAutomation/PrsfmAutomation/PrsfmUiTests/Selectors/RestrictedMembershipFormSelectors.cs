﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class RestrictedMembershipFormSelectors
    {
        [FindsBy(How = How.Id, Using = "app_assoc_rights2")]
        public IWebElement RadioButtonAnotherPrsMemberYes { get; set; }

        [FindsBy(How = How.Id, Using = "app_assoc_rights1")]
        public IWebElement RadioButtonAnotherPrsMemberNo { get; set; }

        [FindsBy(How = How.Id, Using = "app_restrict_Territory2")]
        public IWebElement RadioButtonExcludeCountiesYes { get; set; }

        [FindsBy(How = How.Id, Using = "app_restrict_Territory1")]
        public IWebElement RadioButtonExcludeCountiesNo { get; set; }
    }
}
