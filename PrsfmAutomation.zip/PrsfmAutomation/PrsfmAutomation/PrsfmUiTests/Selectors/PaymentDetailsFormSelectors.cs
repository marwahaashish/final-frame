﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class PaymentDetailsFormSelectors
    {
        [FindsBy(How = How.Id, Using = "rblInternationalBank_0")]
        public IWebElement RadioButtonNonUkBankYes { get; set; }

        [FindsBy(How = How.Id, Using = "rblInternationalBank_1")]
        public IWebElement RadioButtonNonUkBankNo { get; set; }

        [FindsBy(How = How.Id, Using = "rblVAT_0")]
        public IWebElement RadioButtonVatRegisteredYes { get; set; }

        [FindsBy(How = How.Id, Using = "rblVAT_1")]
        public IWebElement RadioButtonVatRegisteredNo { get; set; }
    }
}
