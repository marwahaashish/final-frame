﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors
{
 public class SiteCoreRequestAccessSelectors
  {
    public string GiveAccess(string text)
    {
      return $"//button[@id='approve']";
    }

    [FindsBy(How = How.XPath, Using = ".//*[@class='dropdown-toggle--name']")]
    public IWebElement NavigationDropDown { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'My Account')]")]
    public IWebElement MyAccount { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'View requests')]")]
    public IWebElement ViewRequestsIcon { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'View requests')]")]
    public IWebElement ViewAccessRequests { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'See request')]")]
    public IWebElement SeeRequest { get; set; }

    //[FindsBy(How = How.XPath, Using = "//button[@id='approve']")]
    //public IWebElement GiveAccess { get; set; }

  }
}
