﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class MakeaClaimForMusicUsageSelectors
    {
        public string OverseasButton = "//a[@title='Overseas']";

        public string UkButton = "//a[@title='UK']";

    }
}
