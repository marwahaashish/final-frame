﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PrsfmUiTests.Helpers
{
  public class LoopHelper
  {
    public readonly bool IsQaEnv = Convert.ToBoolean(ConfigurationManager.AppSettings.Get("IsQaEnv"));
    public void LoopLoginLogOut()
    {
     
      for (int i = 0; i < 100; i++)
      {
        IWebDriver driver; 
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.AddArguments("--start-maximized");
        driver = new ChromeDriver(chromeOptions);
        
        driver.Navigate().GoToUrl(IsQaEnv
                      ? ConfigurationManager.AppSettings.Get("BaseUrlQa") 
                      : ConfigurationManager.AppSettings.Get("BaseUrlStg") );
        TaskHelper.ExecuteTask(() =>
        {
          new WebDriverExtensions(driver).WaitForPresence(driver.FindElement(By.LinkText("LOG IN")));
          new WebDriverExtensions(driver).JavaScriptClick(driver.FindElement(By.LinkText("LOG IN")));
          Thread.Sleep(2000);
          new WebDriverExtensions(driver).WaitForPresence(driver.FindElement(By.Id("logonIdentifier")));
          driver.FindElement(By.Id("logonIdentifier")).SendKeys("brendan.meade@prsformusic.com");
          driver.FindElement(By.Id("password")).SendKeys("London99");
          driver.FindElement(By.Id("next")).Click();
          Thread.Sleep(2000);
          new WebDriverExtensions(driver).WaitForPresence(driver.FindElement(By.XPath("//*[@id='navbar']/div/ul[2]/li/button/span[1]/span[2]")));
          Thread.Sleep(2000);
          driver.FindElement(By.XPath("//*[@id='navbar']/div/ul[2]/li/button/span[1]/span[2]")).Click();
          driver.FindElement(By.LinkText("Sign Out")).Click();      
        
        });      
        driver.Quit();
      }
    }
  }
}
