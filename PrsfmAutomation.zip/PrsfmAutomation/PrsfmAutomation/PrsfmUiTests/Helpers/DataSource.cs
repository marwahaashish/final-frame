﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrsfmUiTests.Helpers
{
  class DataSource
  {
    public class GenericLoginCredentials
    {
      //added new login details 26032019
      public static string email = "OLS_autotest@mailinator.com";
      public static string password = "Automation1234";
    }
  }
}
