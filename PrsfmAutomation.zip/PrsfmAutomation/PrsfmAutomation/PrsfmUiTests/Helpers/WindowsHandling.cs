﻿using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;

namespace PrsfmUiTests.Helpers
{
    public class WindowsHandling
    {
        public static IWebDriver SelectLastHandle(string tabTitle, IWebDriver _driver)
        {
            string newTabHandle = _driver.WindowHandles.Last();
            var newTab = _driver.SwitchTo().Window(newTabHandle);
            var expectedTabTitle = tabTitle;
            Assert.AreEqual(expectedTabTitle, newTab.Title);
            return newTab;
        }

        public static string ReturnWindonwTitle(IWebDriver driver)
        {

            var title = driver.Title;
            return title;
        }

        public static string ReturnWindonwURL(IWebDriver driver)
        {
            var Url = driver.Url;
            return Url;
        }

        public static IWebDriver OpenBrowserTab(IWebDriver driver)
        {
          string newTabHandle = driver.WindowHandles.Last();
          return driver.SwitchTo().Window(newTabHandle);

        }
  }
}
