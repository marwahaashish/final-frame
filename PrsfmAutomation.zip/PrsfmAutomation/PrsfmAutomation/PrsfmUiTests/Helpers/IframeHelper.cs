﻿using System;
using System.Collections.Generic;
using System.Threading;
using OpenQA.Selenium;

namespace PrsfmUiTests.Helpers
{
    public class IframeHelper
    {
        private readonly IWebDriver _driver;

        public IframeHelper(IWebDriver driver)
        {
            _driver = driver;
        }
        

        public void Iframe_PrsWriterMembershipApplication()
        {
            _driver.Navigate().Refresh();
            IframeExit();
            ListPageIframes();
            SwitchToContainer("iWin");
        }

        private void IframeExit()
        {
            _driver.SwitchTo().DefaultContent();
        }

        private void ListPageIframes()
        {
            List<IWebElement> frames = new List<IWebElement>(_driver.FindElements(By.TagName("iframe")));
            Console.WriteLine("Number of Frames: " + frames.Count);
            for (int i = 0; i < frames.Count; i++)
            {
                Console.WriteLine("frame[" + i + "]: " + frames[i].GetAttribute("id"));
            }
        }

        private void SwitchToContainer(string iframeId)
        {
            Thread.Sleep(1000);
            bool? isIframeVisible = null;
            isIframeVisible = new WebDriverExtensions(_driver).IsElementVisible(_driver, By.Id(iframeId));

            int i = 0;
            while (isIframeVisible == false && i != 10)
            {
                Thread.Sleep(2000);
                i++;
            }

            try
            {
                IWebElement containerFrame = _driver.FindElement(By.Id(iframeId));
                _driver.SwitchTo().Frame(containerFrame);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
    }
}
