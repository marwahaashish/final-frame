﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using PrsfmUiTests.Config;
using System;
using OpenQA.Selenium.Support.Extensions;
using System.Linq;
using System.Threading;

namespace PrsfmUiTests.Helpers
{
    public class WebDriverExtensions
    {
        protected IWebDriver _driver;
        private static Random _random;

        public WebDriverExtensions(IWebDriver driver)
        {
            _driver = driver;
        }

        public void NavigateTo(string url)
        {
            _driver.Navigate().GoToUrl(url);
        }

        public bool CaseInsensitiveContains(string text, string value,
        StringComparison stringComparison = StringComparison.CurrentCultureIgnoreCase)
        {
            return text.IndexOf(value, stringComparison) >= 0;
        }

        public void RefreshPage()
        {
            _driver.Navigate().Refresh();
        }

        public void WaitForPresence(IWebElement element, int timeoutSeconds = 20)
        {
            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(timeoutSeconds))
            {
                PollingInterval = TimeSpan.FromMilliseconds(Hooks.PollingIntervalMilliseconds)
            };
            wait.IgnoreExceptionTypes(typeof(Exception));
            wait.Until(webDriver => element.Displayed);
        }

        public void WaitForDisappear(By element)
        {
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(20));
            wait.Timeout = TimeSpan.FromSeconds(Hooks.ExplicitWaitSeconds);
            wait.PollingInterval = TimeSpan.FromMilliseconds(Hooks.PollingIntervalMilliseconds);
            wait.IgnoreExceptionTypes(typeof(Exception));

            if (_driver.FindElement(element).Displayed)
            {
                wait.Until(ExpectedConditions.ElementIsVisible(element));
            }
        }

        public void JavaScriptClick(IWebElement element)
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)_driver;
            executor.ExecuteScript("arguments[0].click();", element);
        }

        public void JavaScriptSelectFromDropDownList(string option)
        {
            _driver.ExecuteJavaScript(
                $"jQuery(jQuery('.chosen-container')[0]).trigger('mousedown.chosen');jQuery(jQuery('li:contains(\"{option}\")')[0]).trigger('mouseup.chosen');");
        }

        public void SelectFromDropDownList(IWebElement element, String dropdowntext)
        {
            string listItemXpath = String.Empty;
            try
            {
                WaitForPresence(element);
                element.Click();
                listItemXpath = $"//option[contains(text(),'{dropdowntext}')]";
                var listItem = element.FindElement(By.XPath(listItemXpath));
                WaitForPresence(listItem);
                listItem.Click();
            }
            catch (Exception e)
            {
                throw new ApplicationException(String.Format("{0}. Selector: {1}", e.Message, listItemXpath));
            }
        }

        public void SendKeys(string keys)
        {
            Actions action = new Actions(_driver);
            action.SendKeys(keys).Perform();
        }

        public void MoveToElement(IWebElement element)
        {
            WaitForPresence(element);
            try
            {
                Actions actions = new Actions(_driver);
                actions.MoveToElement(element);
                actions.Perform();
            }
            catch (Exception e)
            {
                throw new ApplicationException(String.Format("{0}. Selector: {1}", e.Message, element));
            }
        }

        public void ControlA(IWebElement element)
        {
            WaitForPresence(element);
            try
            {
                element.Click();
                element.SendKeys(Keys.Control + "a");
            }
            catch (Exception e)
            {
                throw new ApplicationException(String.Format("{0}. Selector: {1}", e.Message, element));
            }
        }

        public bool IsElementVisible(IWebDriver driver, By element)
        {
            return driver.FindElements(element).Count > 0
                && driver.FindElement(element).Displayed;
        }

        public bool IsElementNotVisible(IWebDriver driver, By element)
        {
            return !IsElementVisible(driver, element);
        }

        public string GenerateRandomstring(int length)
        {
            _random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[_random.Next(s.Length)]).ToArray());
        }

        public string GenerateRandomsInteger(int length)
        {
          _random = new Random();
          const string chars = "0123456789";
          return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[_random.Next(s.Length)]).ToArray());
        }
    ////////////////////////////////////////////////////////////////////////////////////////////

    public void SafeClick(IWebElement element)
    {
      ExecuteTask(() =>
      {
        WaitForPresence(element);
        element.Click();
      });
    }

    public void SafeJavaScriptClick(IWebElement element)
    {
      ExecuteTask(() =>
      {
        JavaScriptClick(element);

      });
    }

    public void SafeJavaScrollToElement(IWebElement element)
    {

      ExecuteTask(() =>
      {
        JavaScrollToElement(element);

      });
    }

    public void SafeSendKeys(IWebElement element, string text)
    {
      ExecuteTask(() =>
      {
        WaitForPresence(element);
        element.Clear();
        element.SendKeys(text);
      });
    }

    public string GetElementText(IWebElement element)
    {
      ExecuteTask(() =>
      {
        WaitForPresence(element);
      });
      return element.Text;
    }

    protected IWebElement GetElement(IWebElement element)
    {
      ExecuteTask(() =>
      {
        WaitForPresence(element);
      });
      return element;
    }

    public bool DoesElementExist(IWebElement element)
    {
      try
      {
        GetElement(element);
      }
      catch (AggregateException e)
      {
        if (e.InnerException is NoSuchElementException)
        {
          return false;
        }
      }
      catch (NoSuchElementException)
      {
        return false;
      }
      catch (WebDriverTimeoutException)
      {
        return false;
      }
      return true;
    }

    public void ElementIsDisplayed(IWebElement element)
    {
      ExecuteTask(() =>
      {
        WaitForPresence(element);
        element.Displayed.ToString();
      });
    }
      

    public void WaitForDisappear(IWebElement element)
    {
      WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10))
      {
        Timeout = TimeSpan.FromSeconds(Hooks.ExplicitWaitSeconds),
        PollingInterval = TimeSpan.FromMilliseconds(Hooks.PollingIntervalMilliseconds)
      };
      wait.IgnoreExceptionTypes(typeof(Exception));
      wait.Until(webDriver => !element.Displayed);
    }

    public void JavaScrollToElement(IWebElement element)
    {
      IJavaScriptExecutor executor = (IJavaScriptExecutor)_driver;
      executor.ExecuteScript("arguments[0].scrollIntoView();", element);
    }  

    public static void ExecuteTask(Action action, int retry = 3, Action onFail = null)
    {
      bool success = false;
      do
      {
        try
        {
          retry--;
          action();
          success = true;
        }
        catch (Exception e)
        {
          Console.WriteLine("Attempt failed. Retries left: {0}. Error message: '{1}'", retry, e.Message);

          if (retry == 0 && onFail != null)
          {
            try
            {
              onFail();
              return;
            }
            catch (Exception ex)
            {
              Console.WriteLine(ex.Message);
              throw;
            }
          }

          if (retry == 0)
          {
            Console.WriteLine(e.ToString());
            throw;
          }
          Thread.Sleep(1000);
        }

      }
      while (!success && retry >= 0);
    }   
  }
}
