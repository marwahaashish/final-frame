﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SeleniumExtras.PageObjects;
using TechTalk.SpecFlow;
using PrsfmUiTests.Helpers;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Configuration;
using System.Threading;
using IamUiTests.Selectors;

namespace AzureWarmup
{
  [Binding]
  public sealed class AggressionTestSteps : LoopHelper
  {
    private readonly IWebDriver _driver;
    private readonly LegacyAppLogonSelectors _legacyAppLogonSelectors;

    public AggressionTestSteps(IWebDriver driver)
    {
      _driver = driver;
      _legacyAppLogonSelectors = new LegacyAppLogonSelectors();
      PageFactory.InitElements(_driver, _legacyAppLogonSelectors);
    }
    [Given(@"Homepage has launched")]
    public void GivenHomepageHasLaunched()
    {
      EnvironmentSelect(null);
      // TaskHelper.ExecuteTask(() => new WebDriverExtensions(_driver).WaitForPresence(_navigationBarSelectors.SiteLogo));

    }

    private void EnvironmentSelect(string page)
    {
      _driver.Navigate().GoToUrl(IsQaEnv
              ? ConfigurationManager.AppSettings.Get("BaseUrlQa") + page
              : ConfigurationManager.AppSettings.Get("BaseUrlStg") + page);
    }

    [Then(@"Logon in sitecore account")]
    public void ThenLogonInsitecoreAccount()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.Login);
      });

      new WebDriverExtensions(_driver).SafeJavaScriptClick(_legacyAppLogonSelectors.Login);
      //_legacyAppLogonSelectors.Login.Click();

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.EmailAddress);
      });

      _legacyAppLogonSelectors.EmailAddress.SendKeys("Legacy.member@mailinator.com");

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.Password);
      });
      _legacyAppLogonSelectors.Password.SendKeys("Automation123");
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_legacyAppLogonSelectors.Submit);
      Thread.Sleep(10000);

    }


    //[Repeat(5)]
    //[Given(@"Login and Logout from Sitecore")]
    //public void GivenLoginAndLogoutFromSitecore()
    //{
    //  _driver.Navigate().GoToUrl(IsQaEnv
    //                ? ConfigurationManager.AppSettings.Get("BaseUrlQa")
    //                : ConfigurationManager.AppSettings.Get("BaseUrlStg"));
    //  TaskHelper.ExecuteTask(() =>
    //  {
    //    new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.LinkText("LOG IN")));
    //    new WebDriverExtensions(_driver).JavaScriptClick(_driver.FindElement(By.LinkText("LOG IN")));
    //    Thread.Sleep(2000);
    //    new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.Id("logonIdentifier")));
    //    _driver.FindElement(By.Id("logonIdentifier")).SendKeys("brendan.meade@prsformusic.com");
    //    _driver.FindElement(By.Id("password")).SendKeys("London99");
    //    _driver.FindElement(By.Id("next")).Click();
    //    Thread.Sleep(2000);
    //    new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath("//*[@id='navbar']/div/ul[2]/li/button/span[1]/span[2]")));
    //    Thread.Sleep(2000);
    //    _driver.FindElement(By.XPath("//*[@id='navbar']/div/ul[2]/li/button/span[1]/span[2]")).Click();
    //    _driver.FindElement(By.LinkText("Sign Out")).Click();
    //  });
    //}


    [Given(@"Login and Logout from Sitecore Repeat")]
    public void GivenLoginAndLogoutFromSitecoreRepeat()
    {
      _driver.Navigate().GoToUrl(IsQaEnv
                    ? ConfigurationManager.AppSettings.Get("BaseUrlQa")
                    : ConfigurationManager.AppSettings.Get("BaseUrlStg"));
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.LinkText("LOG IN")));
        new WebDriverExtensions(_driver).JavaScriptClick(_driver.FindElement(By.LinkText("LOG IN")));
        Thread.Sleep(2000);
        new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.Id("logonIdentifier")));
        _driver.FindElement(By.Id("logonIdentifier")).SendKeys("Legacy.member@mailinator.com");
        _driver.FindElement(By.Id("password")).SendKeys("Automation123");
        _driver.FindElement(By.Id("next")).Click();
        Thread.Sleep(2000);
        new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath("//*[@id='navbar']/div/ul[2]/li/button/span[1]/span[2]")));
        Thread.Sleep(2000);
        _driver.FindElement(By.XPath("//*[@id='navbar']//span[contains(@class,'sprite chevron pigeon-post')]")).Click();
        _driver.FindElement(By.LinkText("Sign Out")).Click();
      });
    }

    //[Given(@"Switch Profile Repeat")]
    //public void GivenSwitchProfileRepeat()
    //{
    //  _driver.Navigate().GoToUrl(IsQaEnv
    //                ? ConfigurationManager.AppSettings.Get("BaseUrlQa")
    //                : ConfigurationManager.AppSettings.Get("BaseUrlStg"));
    //  TaskHelper.ExecuteTask(() =>
    //  {
    //    new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath("//div[@class='navbar-right']//a[contains(@href,'/login')]")));
    //    ((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].click();", _driver.FindElement(By.XPath("//div[@class='navbar-right']//a[contains(@href,'/login')]")));
    //  });

    //  TaskHelper.ExecuteTask(() =>
    //  {

    //    new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.Id("logonIdentifier")));
    //    _driver.FindElement(By.Id("logonIdentifier")).SendKeys("Legacy.member@mailinator.com");
    //    _driver.FindElement(By.Id("password")).SendKeys("Automation123");
    //    _driver.FindElement(By.Id("next")).Click();
    //  });

    //  for (int i = 0; i <= 100; i++)
    //  {


    //    TaskHelper.ExecuteTask(() =>
    //    {
    //      new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath(".//*[@class='dropdown-toggle--name']")));
    //      new WebDriverExtensions(_driver).JavaScriptClick(_driver.FindElement(By.XPath(".//*[@class='dropdown-toggle--name']")));
    //      new WebDriverExtensions(_driver).JavaScriptClick(_driver.FindElement(By.XPath("(//ul[@class='dropdown-menu']/li/a/span/p/span)[4]")));

    //    });

    //    TaskHelper.ExecuteTask(() =>
    //    {
    //      new WebDriverExtensions(_driver).JavaScriptClick(_driver.FindElement(By.XPath("//button[contains(text(),'YES, I AM SURE')]")));
    //    });

    //    bool flag = false;
    //    bool staleElement = true;

    //    while (staleElement)
    //    {
    //      try
    //      {
    //        while (true)
    //        {

    //          flag = new WebDriverExtensions(_driver).IsElementNotVisible(_driver, (By.XPath("//img[contains(@src,'White.png')]")));
    //          if (flag == true)
    //          {
    //            flag = false;
    //            break;
    //          }

    //        }
    //        staleElement = false;
    //      }
    //      catch (StaleElementReferenceException e)
    //      {
    //        var stack = e.StackTrace;
    //          staleElement = true;
    //      }
    //    }
    //  }
  }

  }
