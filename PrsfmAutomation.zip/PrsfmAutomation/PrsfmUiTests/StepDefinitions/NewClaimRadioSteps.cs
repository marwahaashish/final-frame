﻿using System;
using System.Collections.ObjectModel;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class NewClaimRadioSteps
    {
        private readonly IWebDriver _driver;
        private readonly NewClaimRadioSelectors _newClaimRadioSelectors;
        private readonly SharedSelectors _sharedSelectors;

        public NewClaimRadioSteps(IWebDriver driver)
        {
            _driver = driver;

            _newClaimRadioSelectors = new NewClaimRadioSelectors();
            PageFactory.InitElements(_driver, _newClaimRadioSelectors);

            _sharedSelectors = new SharedSelectors();
            PageFactory.InitElements(_driver, _sharedSelectors);
        }



        [When(@"Enter the name of the artist '(.*)'")]
        public void WhenEnterTheNameOfTheArtist(string artistName)
        {
            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_newClaimRadioSelectors.NameOfTheArtist);
                _newClaimRadioSelectors.NameOfTheArtist.SendKeys(artistName);
            });
        }

        [When(@"Complete new claim select works form")]
        public void WhenCompleteNewClaimSelectWorksForm(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {

                new WebDriverExtensions(_driver).ControlA(_newClaimRadioSelectors.SelectWorksTitle);
                _newClaimRadioSelectors.SelectWorksTitle.SendKeys((string)formData.Title);
            });

            new WebDriverExtensions(_driver).ControlA(_newClaimRadioSelectors.SelectWorksLastName);
            _newClaimRadioSelectors.SelectWorksLastName.SendKeys((string)formData.LastName);

            new WebDriverExtensions(_driver).ControlA(_newClaimRadioSelectors.SelectWorksFirstName);
            _newClaimRadioSelectors.SelectWorksFirstName.SendKeys((string)formData.FirstName);
      
            new WebDriverExtensions(_driver).MoveToElement(_newClaimRadioSelectors.SelectWorksTunecode);
            _newClaimRadioSelectors.SelectWorksTunecode.Clear();
            _newClaimRadioSelectors.SelectWorksTunecode.SendKeys((string)formData.Tunecode);
          
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_newClaimRadioSelectors.SelectWorksTunecodeGo);
            new WebDriverExtensions(_driver).JavaScriptClick(_newClaimRadioSelectors.SelectWorksTunecodeGo);
          });

          TaskHelper.ExecuteTask(() =>
          {
             new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath(_newClaimRadioSelectors.TunecodeTableResults((string)formData.Tunecode))));
          }, 5);
        }

        [When(@"Complete new claim my usage details form")]
        public void WhenCompleteNewClaimMyUsageDetailsForm(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_newClaimRadioSelectors.CountryOfUsageDropdown);
                new WebDriverExtensions(_driver).JavaScriptSelectFromDropDownList((string)formData.Country);
            });

            // Wait for page to update with Country selected
            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_newClaimRadioSelectors.Station);
                _newClaimRadioSelectors.Station.SendKeys((string)formData.Station);
            }, 5);
            _newClaimRadioSelectors.Station.SendKeys(Keys.Tab);

            // Enter new claim broadcast start date - unique date
            Thread.Sleep(1000);
            new WebDriverExtensions(_driver).ControlA(_newClaimRadioSelectors.BroadcastStartDate);
            Console.WriteLine("*** New claim start date: " + DatesHelper.ParseDate("DayMonthYesterdayYear"));
            _newClaimRadioSelectors.BroadcastStartDate.SendKeys(DatesHelper.ParseDate("DayMonthYesterdayYear"));
            _newClaimRadioSelectors.BroadcastStartDate.SendKeys(Keys.Tab);

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_newClaimRadioSelectors.Add);
                _newClaimRadioSelectors.Add.Click();
            });

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath(_newClaimRadioSelectors.UsageSummaryTableResults((string)formData.Station))));
            }, 5);
        }

        [Then(@"Validate claim summary section title")]
        public void ThenValidateClaimSummarySectionTitle()
        {
            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_newClaimRadioSelectors.ClaimSummaryTitle);
            });
        }


        [Then(@"Valiate claim summary details")]
        public void ThenValiateClaimSummaryDetails(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_newClaimRadioSelectors.ClaimSummaryTable);
            });

            // Table 1
            IWebElement crmTable1 = _newClaimRadioSelectors.ClaimSummaryTableOne;
            ReadOnlyCollection<IWebElement> columnsElements1 = crmTable1.FindElements(By.TagName("td"));

            foreach (IWebElement item1 in columnsElements1)
            {
                Console.WriteLine("*** Table 1 contents: " + item1.Text);
            }

            TaskHelper.ExecuteTask(() =>
            {
                if ((string)formData.Tunecode.ToString() != string.Empty)
                    Assert.IsTrue(crmTable1.Text.Contains((string)formData.Tunecode.ToString()));
            });

            // Table 2
            IWebElement crmTable2 = _newClaimRadioSelectors.ClaimSummaryTableTwo;
            ReadOnlyCollection<IWebElement> columnsElements2 = crmTable2.FindElements(By.TagName("td"));

            foreach (IWebElement item2 in columnsElements2)
            {
                Console.WriteLine("*** Table 2 contents: " + item2.Text);
            }

            TaskHelper.ExecuteTask(() =>
            {
                if ((string)formData.Country != string.Empty)
                    Assert.IsTrue(crmTable2.Text.Contains((string)formData.Country));
            });
        }

        [Then(@"Validate claim submitted section title")]
        public void ThenValidateClaimSubmittedSectionTitle()
        {
            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_newClaimRadioSelectors.ClaimSubmittedTitle);
            }, 5);
        }
    }
}
