﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions
{
  [Binding]
  public class ForgotPasswordSteps
  {
    private readonly IWebDriver _driver;
    private readonly ForgotPasswordSelectors _forgotPasswordSelectors;

    public ForgotPasswordSteps(IWebDriver driver)
    {
      _driver = driver;

      _forgotPasswordSelectors = new ForgotPasswordSelectors();
      PageFactory.InitElements(_driver, _forgotPasswordSelectors);
    }

    [Then(@"click on forgot password link")]
    public void ThenClickOnForgotPasswordLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_forgotPasswordSelectors.ForgotPasswordLink);
        new WebDriverExtensions(_driver).JavaScriptClick(_forgotPasswordSelectors.ForgotPasswordLink);

      });
    }

  }
}
