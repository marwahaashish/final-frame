﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class MusicProfileFormSteps
    {
        private readonly IWebDriver _driver;
        private readonly MusicProfileFormSelectors _musicProfileFormSelectors;

        public MusicProfileFormSteps(IWebDriver driver)
        {
            _driver = driver;

            _musicProfileFormSelectors = new MusicProfileFormSelectors();
            PageFactory.InitElements(_driver, _musicProfileFormSelectors);
        }

        [When(@"Complete music profile select any primary genre")]
        public void WhenCompleteMusicProfileSelectAnyPrimaryGenre(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_musicProfileFormSelectors.RadioButtonClassical);

                switch ((string)formData.Genre)
                {
                    case "Classical":
                        _musicProfileFormSelectors.RadioButtonClassical.Click();
                        break;
                }
            });
        }

    }
}
