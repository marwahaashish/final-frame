﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class PaymentDetailsFormSteps
    {
        private readonly IWebDriver _driver;
        private readonly PaymentDetailsFormSelectors _paymentDetailsFormSelectors;

        public PaymentDetailsFormSteps(IWebDriver driver)
        {
            _driver = driver;

            _paymentDetailsFormSelectors = new PaymentDetailsFormSelectors();
            PageFactory.InitElements(_driver, _paymentDetailsFormSelectors);
        }


        [When(@"Complete Payment Details Do you have a non UK bank account")]
        public void WhenCompletePaymentDetailsDoYouHaveANonUkBankAccount(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_paymentDetailsFormSelectors.RadioButtonNonUkBankYes);

                switch ((string)formData.YesNo)
                {
                    case "Yes":
                        _paymentDetailsFormSelectors.RadioButtonNonUkBankYes.Click();
                        break;
                    case "No":
                        _paymentDetailsFormSelectors.RadioButtonNonUkBankNo.Click();
                        break;
                }
            });
        }

        [When(@"Complete Payment Details Are you VAT registered")]
        public void WhenCompletePaymentDetailsAreYouVatRegistered(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_paymentDetailsFormSelectors.RadioButtonVatRegisteredYes);

                switch ((string)formData.YesNo)
                {
                    case "Yes":
                        _paymentDetailsFormSelectors.RadioButtonVatRegisteredYes.Click();
                        break;
                    case "No":
                        _paymentDetailsFormSelectors.RadioButtonVatRegisteredNo.Click();
                        break;
                }
            });
        }
    }
}
