﻿using System;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class LoginSecurityQuestionSteps
    {
        private readonly IWebDriver _driver;
        private readonly LoginSecurityQuestionSelectors _loginSecurityQuestionSelectors;

        public LoginSecurityQuestionSteps(IWebDriver driver)
        {
            _driver = driver;

            _loginSecurityQuestionSelectors = new LoginSecurityQuestionSelectors();
            PageFactory.InitElements(_driver, _loginSecurityQuestionSelectors);
        }

        [When(@"Enter login page security question and answer")]
        public void WhenEnterLoginPageSecurityQuestionAndAnswer(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();
            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_loginSecurityQuestionSelectors.SecurityQuestionTextbox);
                _loginSecurityQuestionSelectors.SecurityQuestionTextbox.SendKeys((string)formData.SecurityQuestion);
                _loginSecurityQuestionSelectors.SecurityAnswerTextbox.SendKeys((string)formData.SecurityAnswer);
            });
        }

        [Then(@"Click login security page submit button")]
        public void ThenClickLoginSecurityPageSubmitButton()
        {
            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_loginSecurityQuestionSelectors.SubmitButton);
                _loginSecurityQuestionSelectors.SubmitButton.Click();
            });
        }
    }
}
