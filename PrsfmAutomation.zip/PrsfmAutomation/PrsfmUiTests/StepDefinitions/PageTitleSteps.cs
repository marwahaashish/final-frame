﻿using System;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public sealed class PageTitleSteps
    {
        private readonly IWebDriver _driver;
        private readonly PageTitleSelectors _pageTitleSelectors;

        public PageTitleSteps(IWebDriver driver)
        {
            _driver = driver;

            _pageTitleSelectors = new PageTitleSelectors();
            PageFactory.InitElements(_driver, _pageTitleSelectors);
        }


        [Then(@"Validate page title displayed")]
        public void ThenValidatePageTitleDisplayed(Table table)
           {
            dynamic formData = table.CreateDynamicInstance();

            switch ((string)formData.PageTitle)
            {
                case "Welcome back":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_pageTitleSelectors.WelcomeBack);
                    });
                    Assert.IsTrue(_pageTitleSelectors.WelcomeBack.Text.Contains((string)formData.PageTitle));
                    break;

                case "Here for music":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_pageTitleSelectors.HereForMusic);
                    });
                    Assert.IsTrue(_pageTitleSelectors.HereForMusic.Text.Contains((string)formData.PageTitle));
                    break;

                case "Join":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_pageTitleSelectors.Join);
                    });
                    Assert.IsTrue(_pageTitleSelectors.Join.Text.Contains((string)formData.PageTitle));
                    break;

                case "Join as a writer":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_pageTitleSelectors.JoinAsaWriter);
                    });
                    Assert.IsTrue(_pageTitleSelectors.JoinAsaWriter.Text.Contains((string)formData.PageTitle));
                    break;

                case "Join PRS as a writer":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_pageTitleSelectors.JoinPrsAsaWriter);
                    });
                    Assert.IsTrue(_pageTitleSelectors.JoinPrsAsaWriter.Text.Contains((string)formData.PageTitle));
                    break;

                case "Sign up for an online membership account":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_pageTitleSelectors.MemberSignUp);
                    });
                    Assert.IsTrue(_pageTitleSelectors.MemberSignUp.Text.Contains((string)formData.PageTitle));
                    break;

                case "Make a claim for music usage in the UK or overseas":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_pageTitleSelectors.MakeaClaimForMusicUsageInTheUkOrOverseas);
                    });
                    Assert.IsTrue(_pageTitleSelectors.MakeaClaimForMusicUsageInTheUkOrOverseas.Text.Contains((string)formData.PageTitle));
                    break;

                case "New claim (Overseas music usage)":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_pageTitleSelectors.NewClaimOverseasMusicUsage);
                    });
                    Assert.IsTrue(_pageTitleSelectors.NewClaimOverseasMusicUsage.Text.Contains((string)formData.PageTitle));
                    break;

                case "New claim (Radio)":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_pageTitleSelectors.NewClaimRadio);
                    });
                    Assert.IsTrue(_pageTitleSelectors.NewClaimRadio.Text.Contains((string)formData.PageTitle));
                    break;

                case "Live Performances":
                    TaskHelper.ExecuteTask(() =>
                    {
                        WindowsHandling.SelectLastHandle("Report Live", _driver);
                    });


                    TaskHelper.ExecuteTask(() =>
                    {
                        new WebDriverExtensions(_driver).WaitForPresence(_pageTitleSelectors.LivePerformances);
                    });
                    Assert.IsTrue(_pageTitleSelectors.LivePerformances.Text.Contains((string)formData.PageTitle));
                    break;

                case "Forgot password":
                  TaskHelper.ExecuteTask(() =>
                  {
                    new WebDriverExtensions(_driver).WaitForPresence(_pageTitleSelectors.ForgottenPassword);
                  });
                  Assert.IsTrue(_pageTitleSelectors.ForgottenPassword.Text.Contains((string)formData.PageTitle));
                  break;

        default:
                    Console.WriteLine("*** UNKnown Page Title passed test");
                    break;
            }
        }
    }
}
