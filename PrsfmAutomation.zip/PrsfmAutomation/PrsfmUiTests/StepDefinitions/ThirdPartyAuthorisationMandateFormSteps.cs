﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class ThirdPartyAuthorisationMandateFormSteps
    {
        private readonly IWebDriver _driver;
        private readonly ThirdPartyAuthorisationMandateFormSelectors _thirdPartyAuthorisationMandateFormSelectors;

        public ThirdPartyAuthorisationMandateFormSteps(IWebDriver driver)
        {
            _driver = driver;

            _thirdPartyAuthorisationMandateFormSelectors = new ThirdPartyAuthorisationMandateFormSelectors();
            PageFactory.InitElements(_driver, _thirdPartyAuthorisationMandateFormSelectors);
        }


        [When(@"Complete Third party authorisation mandate for an authorised person")]
        public void WhenCompleteThirdPartyAuthorisationMandateForAnAuthorisedPerson(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();
            WebDriverExtensions _webDriverExtensions = new WebDriverExtensions(_driver);

            TaskHelper.ExecuteTask(() =>
            {                
                switch ((string)formData.YesNo)
                {
                    case "Yes":                      
                        _webDriverExtensions.JavaScriptClick(_thirdPartyAuthorisationMandateFormSelectors.RadioButtonAuthorisedPersonYes);
                  break;
                    case "No":                      
                        _webDriverExtensions.JavaScriptClick(_thirdPartyAuthorisationMandateFormSelectors.RadioButtonAuthorisedPersonNo);
                        break;
                }
            });
        }
    }
}