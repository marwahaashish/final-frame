﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public sealed class NewClaimOverseasMusicUsageSteps
    {
        private readonly IWebDriver _driver;
        private readonly NewClaimOverseasMusicUsageSelectors _newClaimOverseasMusicUsageSelectors;

        public NewClaimOverseasMusicUsageSteps(IWebDriver driver)
        {
            _driver = driver;

            _newClaimOverseasMusicUsageSelectors = new NewClaimOverseasMusicUsageSelectors();
            PageFactory.InitElements(_driver, _newClaimOverseasMusicUsageSelectors);
        }


        [When(@"Select What type of music usage do you wish to report")]
        public void WhenSelectWhatTypeOfMusicUsageDoYouWishToReport(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();
            
            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_newClaimOverseasMusicUsageSelectors.MusicTypeDropdown);
                new WebDriverExtensions(_driver).JavaScriptSelectFromDropDownList((string)formData.MusicType);
            });

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_newClaimOverseasMusicUsageSelectors.StepInfo);
            });
        }
    }
}
