﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
  [Binding]
  public class LicenceSignUpSteps
  {
    private readonly IWebDriver _driver;

    private readonly LicenceSignUpSelectors _licenceSignUpSelectors;
    public readonly string uniqueData = DatesHelper.ParseDate(DatesHelper.DateTimeRightNow);
    public readonly string uniqueEmailAddress;

    public LicenceSignUpSteps(IWebDriver driver)
    {
      _driver = driver;
      this.uniqueEmailAddress = uniqueData + "@mailinator.com";         
      _licenceSignUpSelectors = new LicenceSignUpSelectors();
      PageFactory.InitElements(_driver, _licenceSignUpSelectors);
    }


    [When(@"Complete licence account form")]
    public void WhenCompleteMemberSignUpForPrimary(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();


      TaskHelper.ExecuteTask(() =>
      {
        new Helpers.WebDriverExtensions(_driver).WaitForPresence(_licenceSignUpSelectors.HasCompanyAccount);
        new Helpers.WebDriverExtensions(_driver).JavaScriptClick(_licenceSignUpSelectors.HasCompanyAccount);
      });
     
      _licenceSignUpSelectors.PRSAccountID.SendKeys(new WebDriverExtensions(_driver).GenerateRandomsInteger(12));
      _licenceSignUpSelectors.FirstName.SendKeys((string)formData.FirstName);
      _licenceSignUpSelectors.LastName.SendKeys((string)formData.LastName);
      //_licenceSignUpSelectors.EmailAddress.SendKeys((string)formData.EmailAddress);
      _licenceSignUpSelectors.EmailAddress.SendKeys(uniqueEmailAddress);
      TaskHelper.ExecuteTask(() =>
      {
        new Helpers.WebDriverExtensions(_driver).WaitForPresence(_licenceSignUpSelectors.Submit);
        new Helpers.WebDriverExtensions(_driver).JavaScriptClick(_licenceSignUpSelectors.Submit);
      });
    }
  }
}
