﻿using System;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors.WebUserAdmin;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using NUnit.Framework;
using System.Threading;

namespace PrsfmUiTests.StepDefinitions.WebUserAdmin
{
  [Binding]
  public sealed class WebUserAdminKeyFlowsSteps
  {
    private readonly IWebDriver _driver;
    private readonly WebUserAdminSelectors _webUserAdminSelectors;
    //private string[] _saveResults;

    public WebUserAdminKeyFlowsSteps(IWebDriver driver)
    {
      _driver = driver;
      _webUserAdminSelectors = new WebUserAdminSelectors();
      PageFactory.InitElements(_driver, _webUserAdminSelectors);
    }

    [When(@"Enter the WebUserLogin email address")]
    public void WhenEnterTheWebUserLoginEmailAddress()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.WebUserLogin.SendKeys("ashish.marwaha@prsformusic.com");
      });
     

      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.WebUserNext.Click();
      });
          
    }

    [Then(@"Select Administration drop dowm")]
    public void ThenSelectAdministrationDropDowm()
    {
    
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.SelectAdministration);
        _webUserAdminSelectors.SelectAdministration.Click();
      });      
    }

    [When(@"Select for member type")]
    public void WhenSelectForMemberType()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.SelectMembers);
        _webUserAdminSelectors.SelectMembers.Click();
      });
    }

    [Then(@"Select all members")]
    public void ThenSelectAllMembers()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.SelectAllMembers.Click();
      });
    }

    [Then(@"Click member view link")]
    public void ThenClickMemberViewLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.ClickView);
        _webUserAdminSelectors.ClickView.Click();
        Thread.Sleep(5000);

      });
    }

    [Then(@"click add memeber button")]
    public void ThenClickAddMemeberButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.ClickAddMember);
        _webUserAdminSelectors.ClickAddMember.Click();
       // Thread.Sleep(5000);

      });
    }

    [Then(@"Enter member serach term")]
    public void ThenEnterMemberSerachTerm()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.AddMemberSeachTerm);
       _webUserAdminSelectors.AddMemberSeachTerm.SendKeys("Ash");        
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.AddMemberAutoSeachTerm);
        _webUserAdminSelectors.AddMemberAutoSeachTerm.Click();
        _webUserAdminSelectors.ClickNext.Click();
       
      });
    }

    [Then(@"Add member and validate")]
    public void ThenAddMemberAndValidate()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.ClickAddPopupButton);
        new Helpers.WebDriverExtensions(_driver).SafeJavaScriptClick(_webUserAdminSelectors.ClickAddPopupButton);
        Thread.Sleep(5000);
      });

      //TaskHelper.ExecuteTask(() =>
      //{
      //  new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.SearchSuccessMessageAddMember);
        
      //});
    }


    [When(@"Select for Licensees type")]
    public void WhenSelectForLicenseesType()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.SelectLicensees.Click();
      });
    }

    [Then(@"Select all Licensees")]
    public void ThenSelectAllLicensees()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.SelectAllLicensees.Click();
      });
    }

    [When(@"Select for ThirdParty type")]
    public void WhenSelectForThirdPartyType()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.SelectThirdParties.Click();
      });
    }

    [Then(@"Select all ThirdParty")]
    public void ThenSelectAllThirdParty()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.SelectAllThirdParties.Click();
      });
    }

    [When(@"Select for Overseas type")]
    public void WhenSelectForOverseasType()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.SelectOverseas.Click();
      });
    }

    [Then(@"Select all Overseas")]
    public void ThenSelectAllOverseas()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.SelectAllOverseas.Click();
      });
    }

    [When(@"Select for Affiliate type")]
    public void WhenSelectForAffiliateType()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.SelectAffiliate.Click();
      });
    }

    [Then(@"Select all Affiliate")]
    public void ThenSelectAllAffiliate()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.SelectAllAffiliate.Click();
      });
    }

    [Then(@"click add button")]
    public void ThenClickAddButton()
    {
      _webUserAdminSelectors.ClickAddButton.Click();
      
    }

    [Then(@"Enter new member details")]
    public void ThenEnterNewMemberDetails()
    {
      //ScenarioContext.Current.Pending();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.MemberName);
        _webUserAdminSelectors.MemberName.SendKeys(DatesHelper.TodayDay + DatesHelper.ThisMonth);
        _webUserAdminSelectors.MemberIPINumber.SendKeys(new WebDriverExtensions(_driver).GenerateRandomsInteger(8));
        _webUserAdminSelectors.MembershipId.SendKeys("0");
        _webUserAdminSelectors.RadioButtonWriter.Click();
        _webUserAdminSelectors.SocietyAffiliation.Click();
        _webUserAdminSelectors.SaveMember.Click();       

      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.CheckSaveMember);
      });
    }

    [Then(@"Enter Administrator Licensee details")]
    public void ThenEnterAdministratorLicenseeDetails()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.LicenseeCompanyName);
        _webUserAdminSelectors.LicenseeCompanyName.SendKeys("Lic" +DatesHelper.TodayDay + DatesHelper.ThisMonth);        
        _webUserAdminSelectors.RadioButtonSignUpApprovalType.Click();
        _webUserAdminSelectors.LicenseeCompanyType.Click();
        _webUserAdminSelectors.SaveLicensee.Click();

      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.CheckLicensee);
      });
    }

    [Then(@"Enter WhiteLsited Licensee details")]
    public void ThenEnterWhiteLsitedLicenseeDetails()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.LicenseeCompanyName);
        _webUserAdminSelectors.LicenseeCompanyName.SendKeys("LicWhiteListed" + DatesHelper.TodayDay + DatesHelper.ThisMonth);
        _webUserAdminSelectors.RadioButtonWhiteLsitedApprovalType.Click();
        _webUserAdminSelectors.AddDomainNames.SendKeys("mailinator.com");
        _webUserAdminSelectors.LicenseeCompanyType.Click();
        _webUserAdminSelectors.SaveLicensee.Click();

      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.CheckLicensee);
      });
    }


    [Then(@"Enter Third Party details")]
    public void ThenEnterThirdPartyDetails()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.ThirdPartyOrganisationName);
        _webUserAdminSelectors.ThirdPartyOrganisationName.SendKeys("Third_Party" + DatesHelper.TodayDay + DatesHelper.ThisMonth);       
        _webUserAdminSelectors.ThirdPartyBusinessOwner.SendKeys("TestThirdParty");        
        _webUserAdminSelectors.SaveThirdParty.Click();

      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.CheckLicensee);
      });
    }



    [Then(@"Enter the search term for organisation")]
    public void ThenEnterTheSearchTermForOrganisation(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();

      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.EnterSearchTerm.SendKeys((string)formData.SearchTerm);
        _webUserAdminSelectors.ClickSearchButton.Click();
      });
    }

    [Then(@"Enter the search term for member organisation")]
    public void ThenEnterTheSearchTermForMemberOrganisation(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();

      TaskHelper.ExecuteTask(() =>
      {
        _webUserAdminSelectors.EnterSearchTerm.SendKeys((string)formData.SearchTerm);
        _webUserAdminSelectors.ClickMemberSearchButton.Click();
      });
    }


    [Then(@"Validate WebUserAdmin message shown")]
    public void ThenValidateWebUserAdminMessageShown(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();

      switch ((string)formData.Text)
      {
        case "A D Music":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.SearchSuccessMessageMemeber);
            Assert.IsTrue(_webUserAdminSelectors.SearchSuccessMessageMemeber.Text.Contains((string)formData.Text));
            Thread.Sleep(2000);
          });
          break;

        case "Abbott Mead Vickers":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.SearchSuccessMessageLicensee);
            Assert.IsTrue(_webUserAdminSelectors.SearchSuccessMessageLicensee.Text.Contains((string)formData.Text));
            Thread.Sleep(2000);
          });
          break;

        case "The PRS Foundation":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.SearchSuccessMessageThirdParties);
            Assert.IsTrue(_webUserAdminSelectors.SearchSuccessMessageThirdParties.Text.Contains((string)formData.Text));
            Thread.Sleep(2000);
          });
          break;

        case "PRS Overseas Agents":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.SearchSuccessMessageOverseas);
            Assert.IsTrue(_webUserAdminSelectors.SearchSuccessMessageOverseas.Text.Contains((string)formData.Text));
            Thread.Sleep(2000);
          });
          break;

        case "AGADU":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_webUserAdminSelectors.SearchSuccessMessageAffiliate);
            Assert.IsTrue(_webUserAdminSelectors.SearchSuccessMessageAffiliate.Text.Contains((string)formData.Text));
            Thread.Sleep(2000);
          });
          break;

        default:
          Assert.Fail();
          Console.WriteLine("*** UNKnown Page Title passed test");
          break;
      }
    }

  }
}
