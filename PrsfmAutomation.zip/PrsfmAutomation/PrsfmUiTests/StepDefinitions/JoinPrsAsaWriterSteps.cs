﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class JoinPrsAsaWriterSteps
    {
        private readonly IWebDriver _driver;
        private readonly JoinPrsAsaWriterSelectors _joinPrsAsaWriterSelectors;

        public JoinPrsAsaWriterSteps(IWebDriver driver)
        {
            _driver = driver;

            _joinPrsAsaWriterSelectors = new JoinPrsAsaWriterSelectors();
            PageFactory.InitElements(_driver, _joinPrsAsaWriterSelectors);
        }


        [Then(@"Select join prs membership application accept button")]
        public void ThenSelectJoinPrsMembershipApplicationAcceptButton()
        {
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_joinPrsAsaWriterSelectors.Form);
          });

          new IframeHelper(_driver).Iframe_PrsWriterMembershipApplication();

      TaskHelper.ExecuteTask(() =>
            {
                ((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].click();", _joinPrsAsaWriterSelectors.Accept);
            });
        }

    }
}
