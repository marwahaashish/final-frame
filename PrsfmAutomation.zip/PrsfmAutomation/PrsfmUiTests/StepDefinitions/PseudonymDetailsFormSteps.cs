﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class PseudonymDetailsFormSteps
    {
        private readonly IWebDriver _driver;
        private readonly PseudonymDetailsFormSelectors _pseudonymDetailsFormSelectors;

        public PseudonymDetailsFormSteps(IWebDriver driver)
        {
            _driver = driver;

            _pseudonymDetailsFormSelectors = new PseudonymDetailsFormSelectors();
            PageFactory.InitElements(_driver, _pseudonymDetailsFormSelectors);
        }


        [When(@"Complete Pseudonym details")]
        public void WhenCompletePseudonymDetails(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() =>
            {
                new WebDriverExtensions(_driver).WaitForPresence(_pseudonymDetailsFormSelectors.ForenameTextOne);

                _pseudonymDetailsFormSelectors.ForenameTextOne.SendKeys((string)formData.Forename);
                _pseudonymDetailsFormSelectors.SurnameTextOne.SendKeys((string)formData.Surname);
            });
        }

    }
}
