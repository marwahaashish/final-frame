﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
    [Binding]
    public class RestrictedMembershipFormSteps
    {
        private readonly IWebDriver _driver;
        private readonly RestrictedMembershipFormSelectors _restrictedMembershipFormSelectors;

        public RestrictedMembershipFormSteps(IWebDriver driver)
        {
            _driver = driver;

            _restrictedMembershipFormSelectors = new RestrictedMembershipFormSelectors();
            PageFactory.InitElements(_driver, _restrictedMembershipFormSelectors);
        }


        [When(@"Complete Restricted Membership Are you a member of another Prs")]
        public void WhenCompleteRestrictedMembershipAreYouAMemberOfAnotherPrs(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();
            WebDriverExtensions _webDriverExtensions = new WebDriverExtensions(_driver);

            TaskHelper.ExecuteTask(() =>
            {
                switch ((string)formData.YesNo)
                {
                    case "Yes":                       
                        _webDriverExtensions.JavaScriptClick(_restrictedMembershipFormSelectors.RadioButtonAnotherPrsMemberYes);
                        break;
                    case "No":                       
                        _webDriverExtensions.JavaScriptClick(_restrictedMembershipFormSelectors.RadioButtonAnotherPrsMemberNo);
                  break;
                }
            });
        }

        [When(@"Complete Restricted Membership Do you wish to exclude certain countries")]
        public void WhenCompleteRestrictedMembershipDoYouWishToExcludeCertainCountries(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();
            WebDriverExtensions _webDriverExtensions = new WebDriverExtensions(_driver);

             TaskHelper.ExecuteTask(() =>
                {              
                switch ((string)formData.YesNo)
                {
                    case "Yes":                    
                      _webDriverExtensions.JavaScriptClick(_restrictedMembershipFormSelectors.RadioButtonExcludeCountiesYes);
                        break;
                    case "No":                      
                      _webDriverExtensions.JavaScriptClick(_restrictedMembershipFormSelectors.RadioButtonExcludeCountiesNo);
                      break;
                }
            });
        }

    }
}
