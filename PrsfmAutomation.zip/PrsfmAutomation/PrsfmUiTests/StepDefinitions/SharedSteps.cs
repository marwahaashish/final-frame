﻿using System;
using System.Configuration;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
  [Binding]
  public class SharedSteps
  {
    private readonly IWebDriver _driver;
    public readonly bool IsQaEnv = Convert.ToBoolean(ConfigurationManager.AppSettings.Get("IsQaEnv"));

    private readonly SharedSelectors _sharedSelectors;
    private readonly NavigationBarSelectors _navigationBarSelectors;
    private readonly NewClaimOverseasMusicUsageSelectors _newClaimOverseasMusicUsageSelectors;
    private string commonBaseUrl = "https://apps-rt.prsformusic.com/";

    public SharedSteps(IWebDriver driver)
    {
      _driver = driver;

      _navigationBarSelectors = new NavigationBarSelectors();
      PageFactory.InitElements(_driver, _navigationBarSelectors);

      _sharedSelectors = new SharedSelectors();
      PageFactory.InitElements(_driver, _sharedSelectors);

      _newClaimOverseasMusicUsageSelectors = new NewClaimOverseasMusicUsageSelectors();
      PageFactory.InitElements(_driver, _newClaimOverseasMusicUsageSelectors);
    }


    [Given(@"Homepage has launched")]
    public void GivenHomepageHasLaunched()
    {
      EnvironmentSelect(null);
     // TaskHelper.ExecuteTask(() => new WebDriverExtensions(_driver).WaitForPresence(_navigationBarSelectors.SiteLogo));
     
    }

    [Given(@"WebUserAdmin homepage has launched")]
    public void GivenWebUserAdminHomepageHasLaunched()
    {
      _driver.Navigate().GoToUrl("https://azp-ms-app-qa-webuseradmin-01.azurewebsites.net/Administration");
     // _driver.Navigate().GoToUrl(" https://webuseradminsg01.prsformusic.com/Administration");
      //_driver.Navigate().GoToUrl("https://webuseradmin.prsformusic.com/Administration");
    }

    [Given(@"Homepage has launched via back door")]
    public void GivenHomepageHasLaunchedViaBackDoor()
    {
      _driver.Navigate().GoToUrl("https://beta.sg01.prsformusic.com/iamlogin");
    }


    [Given(@"Assimlate Homepage has launched")]
    public void GivenAssimlateHomepageHasLaunched()
    {
      // _driver.Navigate().GoToUrl("https://apps-rt.prsformusic.com/alternatelogin/login.aspx?returnurl=https://setlist03.qa01.prsformusic.com");
     //  _driver.Navigate().GoToUrl("https://apps-rt.prsformusic.com/alternatelogin/login.aspx?returnurl=https://setlist03.sg01.prsformusic.com");
      _driver.Navigate().GoToUrl("https://beta02.qa01.prsformusic.com/login?returnUrl=https://setlist03.qa01.prsformusic.com/#/performances/saved");
    }

    [Given(@"Sitecore hompage has launched")]
    public void GivenSitecoreHompageHasLaunched()
    {
      EnvironmentSelect(null);
      //TaskHelper.ExecuteTask(() => new WebDriverExtensions(_driver).WaitForPresence(_navigationBarSelectors.Login));
      //((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].click();", _navigationBarSelectors.Login);
    }

    private void EnvironmentSelect(string page)
    {
      _driver.Navigate().GoToUrl(IsQaEnv
              ? ConfigurationManager.AppSettings.Get("BaseUrlQa") + page
              : ConfigurationManager.AppSettings.Get("BaseUrlStg") + page);
    }

    [Given(@"I navigate to web page '(.*)'")]
    public void GivenINavigateToWebPage(string urlExtension)
    {
      if(urlExtension!=null)
        _driver.Navigate().GoToUrl("https://beta.sg01.prsformusic.com/join");
      else
      EnvironmentSelect(urlExtension);
      TaskHelper.ExecuteTask(() => new WebDriverExtensions(_driver).WaitForPresence(_navigationBarSelectors.SiteLogo));
    }

    [Given(@"Navigate to url '(.*)'")]
    public void GivenNavigateToUrl(string urlString)
    {
      _driver.Navigate().GoToUrl(commonBaseUrl + urlString);
    }

    [Given(@"I navigate to apps web page '(.*)'")]
    public void GivenINavigateToAppsWebPage(string url)
    {
      switch (url)
      {
        case "PRS Writer Membership Application":
          AppsEnvironmentSelect(null);
          break;
      }
    }

    private void AppsEnvironmentSelect(string page)
    {
      _driver.Navigate().GoToUrl(IsQaEnv
              ? ConfigurationManager.AppSettings.Get("AdmissionsUrlQa") + page
              : ConfigurationManager.AppSettings.Get("AdmissionsUrlStg") + page);
    }

    [Then(@"Validate article title displayed '(.*)'")]
    public void ThenValidateArticleTitleDisplayed(string articleTitleText)
    {
      Thread.Sleep(2000);
      bool? trueFalse = null;     

      TaskHelper.ExecuteTask(() =>
      {
        trueFalse = new WebDriverExtensions(_driver).IsElementVisible(_driver,
          By.XPath(_sharedSelectors.PageTitleH2(articleTitleText)));
      });

      if (trueFalse == false)
      {
        TaskHelper.ExecuteTask(() =>
        {
          new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath(_sharedSelectors.PageTitleH2WithSpan(articleTitleText))));
          //new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath(_sharedSelectors.PageTitleH2(articleTitleText))));
        });
      }
      Assert.IsTrue(trueFalse == true
          ? _driver.FindElement(By.XPath(_sharedSelectors.PageTitleH2(articleTitleText))).Text.Contains(articleTitleText)
          : _driver.FindElement(By.XPath(_sharedSelectors.PageTitleH2WithSpan(articleTitleText))).Text.Contains(articleTitleText));
    }


    [Then(@"Validate article displayed '(.*)'")]
    public void ThenValidateArticleHDisplayed(string articleTitleText)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath(_sharedSelectors.PageTitleH1(articleTitleText))));
      });

    }

     [Then(@"Validate warning message not shown")]
    public void ThenValidateWarningMessageNotShown(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();

      new WebDriverExtensions(_driver).IsElementNotVisible(_driver, By.XPath(_sharedSelectors.WarningMessageText((string)formData.Text)));
    }

    [Then(@"Validate warning message is shown")]
    public void ThenValidateWarningMessageIsShown(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();

      new WebDriverExtensions(_driver).IsElementVisible(_driver, By.XPath(_sharedSelectors.WarningMessageText((string)formData.Text)));
    }

    [Then(@"Click next page button")]
    public void ThenClickNextPageButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_sharedSelectors.NextButton);
        new WebDriverExtensions(_driver).JavaScriptClick(_sharedSelectors.NextButton);
      });
    }

    [Then(@"Click submit new claim")]
    public void ThenClickSubmitNewClaim()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_sharedSelectors.SubmitButton);
        new WebDriverExtensions(_driver).JavaScriptClick(_sharedSelectors.SubmitButton);
      });
    }

    [Then(@"Click return page button")]
    public void ThenClickReturnPageButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_newClaimOverseasMusicUsageSelectors.ReturnButton);
        new WebDriverExtensions(_driver).JavaScriptClick(_newClaimOverseasMusicUsageSelectors.ReturnButton);
      });
    }

  }
}
