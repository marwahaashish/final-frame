﻿using IamUiTests.Selectors;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System.Threading;
using TechTalk.SpecFlow;

namespace IamUiTests.StepDefinitions
{
  [Binding]
  class LegacyAppLogonSteps
  {
    private readonly IWebDriver _driver;
    private readonly LegacyAppLogonSelectors _legacyAppLogonSelectors;

    public LegacyAppLogonSteps(IWebDriver driver)
    {
      _driver = driver;

      _legacyAppLogonSelectors = new LegacyAppLogonSelectors();
      PageFactory.InitElements(_driver, _legacyAppLogonSelectors);
    }


    [Then(@"Logon in FD Assimlate account")]
    public void ThenLogonInFDAssimlateAccount()
    {

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.FDEmailAddress);
      });

      _legacyAppLogonSelectors.FDEmailAddress.SendKeys("eBusinessTest2@prsformusic.com");
      _legacyAppLogonSelectors.FDNext.Click();

     // _legacyAppLogonSelectors.EmailAddress.SendKeys("eBusinessTest2@prsformusic.com");


      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.Password);
      });
      _legacyAppLogonSelectors.Password.SendKeys("e*Bizsystest");

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.AssimilatCAE);
      });

      _legacyAppLogonSelectors.AssimilatCAE.SendKeys("122517311");

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.AssimilateSubmit);
      });

      _legacyAppLogonSelectors.AssimilateSubmit.Click();

      Thread.Sleep(5000);
    }


    [Then(@"Logon in sitecore account")]
    public void ThenLogonInsitecoreAccount()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.Login);
      });

      new WebDriverExtensions(_driver).SafeJavaScriptClick(_legacyAppLogonSelectors.Login);
      //_legacyAppLogonSelectors.Login.Click();

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.EmailAddress);
      });

      _legacyAppLogonSelectors.EmailAddress.SendKeys("Legacy.member@mailinator.com");         

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.Password);
      });
      _legacyAppLogonSelectors.Password.SendKeys("Automation123");
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_legacyAppLogonSelectors.Submit);    
      Thread.Sleep(10000);

    }

    [Then(@"Logon in Assimlate account")]
    public void ThenLogonInAssimlateAccount()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.LogonTextAssimilate);
      });

      _legacyAppLogonSelectors.AssimilateEmailAddress.SendKeys("eBusinessTest2@prsformusic.com");
      _legacyAppLogonSelectors.AssimilatePassword.SendKeys("e*Bizsystest");
     

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.AssimilatCAE);
      });

      _legacyAppLogonSelectors.AssimilatCAE.SendKeys("285701258");    
      Thread.Sleep(10000);
    }


    [Then(@"Logon in legacy Overseas account")]
    public void ThenLogonInLegacyOverseasAccount()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.Login);
      });

      _legacyAppLogonSelectors.Login.Click();

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.EmailAddress);
      });
      _legacyAppLogonSelectors.EmailAddress.SendKeys("Legacy.overseas@mailinator.com");
      _legacyAppLogonSelectors.Password.SendKeys("Automation123");
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_legacyAppLogonSelectors.Submit);      
      Thread.Sleep(10000);
    }


    [Then(@"Logon in legacy licensee account")]
    public void ThenLogonInLegacyLicenseeAccount()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.Login);
      });

      _legacyAppLogonSelectors.Login.Click();

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_legacyAppLogonSelectors.EmailAddress);
      });

      _legacyAppLogonSelectors.EmailAddress.SendKeys("Legacy.licensee@mailinator.com");
      _legacyAppLogonSelectors.Password.SendKeys("Automation123");
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_legacyAppLogonSelectors.Submit);     
    }
    
  }
}
