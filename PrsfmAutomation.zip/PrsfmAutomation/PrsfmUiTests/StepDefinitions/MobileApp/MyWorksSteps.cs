﻿using NUnit.Framework;
using OpenQA.Selenium;
using PrsfmUiTests.Selectors.MobileApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.MobileApp
{
  [Binding]
  public sealed class MyWorksSteps
  {
    private readonly IWebDriver _driver;
    private readonly MyWorksPage _myWorksPage;
    private readonly SearchResultPage _searchResultPage;

    public MyWorksSteps(IWebDriver driver)
    {
      _driver = driver;
      _searchResultPage = new SearchResultPage(_driver);
      _myWorksPage = new MyWorksPage(_driver);
    }
    [Then(@"I should have Page header title ""(.*)""")]
    public void ThenIShouldHavePageHeaderTitle(string PageHeaderTitle)
    {
      StringAssert.AreEqualIgnoringCase(PageHeaderTitle, _myWorksPage.GetPageHeaderTitle());
    }

    [Then(@"I should have name of profile selected ""(.*)""")]
    public void ThenIShouldHaveNameOfProfileSelected(string UserProfileName)
    {
      StringAssert.AreEqualIgnoringCase(UserProfileName, _myWorksPage.GetSelctedUserProfileName());
    }
    [Then(@"I should have  selected user name from userprofile  ""(.*)""")]
    public void ThenIShouldHaveSelectedUserNameFromUserprofile(string UserProfileName2)
    {
      StringAssert.AreEqualIgnoringCase(UserProfileName2, _myWorksPage.GetPageHeaderTitleAnotherUser());
    }

    [Then(@"I should have number of results for publisher ""(.*)""")]
    public void ThenIShouldHaveNumberOfResultsForPublisher(string NumberOfResults)
    {
      _myWorksPage.IsNumberOfResultsDisplayed(NumberOfResults);
    }
    [Then(@"I should have first search card header ""(.*)""")]
    public void ThenIShouldHaveFirstSearchCardHeader(string FirstSearchCardHeader)
    {
      _myWorksPage.IsFirstSearchCardDisplayed();
    }
    [Then(@"I should have first search card header")]
    public void ThenIShouldHaveFirstSearchCardHeader()
    {
      _myWorksPage.IsFirstSearchCardHeaderDisplayed();
    }

    [Then(@"I also have same header text of searh resultpage ""(.*)""")]
    public void ThenIAlsoHaveSameHeaderTextOfSearhResultpage(string FirstSearchCardHeader)
    {
      StringAssert.AreEqualIgnoringCase(FirstSearchCardHeader, _myWorksPage.GetSearhResultHeaderMatchesInShareholderHeader());
    }
    [Then(@"I also have same header text of searh resultpage")]
    public void ThenIAlsoHaveSameHeaderTextOfSearhResultpage()
    {
      _myWorksPage.IsPageHeaderInShareHolderTabMatchFirstSearchCardHeaderDisplayed();
    }

    [Then(@"I should have writer name of search card ""(.*)""")]
    public void ThenIShouldHaveWriterNameOfSearchCard(string SearchCardWriter)
    {
      StringAssert.AreEqualIgnoringCase(SearchCardWriter, _myWorksPage.GetFirstSearchCardWriterName());
    }
    [Then(@"I should have writer name")]
    public void ThenIShouldHaveWriterName()
    {
      _myWorksPage.IsMyworksSearchCardHeaderDisplayed();
    }

    [When(@"I click on first search result")]
    public void WhenIClickOnFirstSearchResult()
    {
      _myWorksPage.ClickMyWorksFirstResultLink();
    }

    [Then(@"I should have page header link""(.*)""")]
    public void ThenIShouldHavePageHeaderLink(string PageHeaderLink)
    {
      StringAssert.AreEqualIgnoringCase(PageHeaderLink, _myWorksPage.GetPageHeaderTitle());
    }

    [Then(@"I should have share holder page tab active ""(.*)""")]
    public void ThenIShouldHaveShareHolderPageTabActive(string ActiveTab)
    {
      StringAssert.AreEqualIgnoringCase(ActiveTab, _searchResultPage.GetShareHolderActiveTab());
    }
    [When(@"I expand shareholder tab")]
    public void WhenIExpandShareholderCard()
    {
      _searchResultPage.ClickFirstShareholderCard();
    }
    [Then(@"I should have viewworks link ""(.*)""")]
    public void WhenIShouldHaveViewworksLink(string LinkName)
    {
      StringAssert.AreEqualIgnoringCase(LinkName, _searchResultPage.GetViewWorksLink());
    }
    [Then(@"I should have same writer name of firstsearchcard  ""(.*)""")]
    public void ThenIShouldHaveSameWriterNameOfFirstsearchcard(string WriterName)
    {
      StringAssert.AreEqualIgnoringCase(WriterName, _myWorksPage.GetSearhCardWriterNameMatchesInShareHolderTab());
    }
    [Then(@"I should have same writer name of firstsearchcard")]
    public void ThenIShouldHaveSameWriterNameOfFirstsearchcard()
    {
      _myWorksPage.IsWriterNameInShareHolderTabMatchFirstSearchCardDisplayed();
    }

    [Then(@"I should have differentfirst search card header ""(.*)""")]
    public void ThenIShouldHaveDifferentfirstSearchCardHeader(string DiffFirstSearchCardHeader)
    {
    _myWorksPage.IsSearchCardHeaderDifferentForOtherUserDisplayed();
    }
    [Then(@"I also have same header text of search resultpage ""(.*)""")]
    public void ThenIAlsoHaveSameHeaderTextOfSearchResultpage(string FirstSearchCardHeader)
    {
      StringAssert.AreEqualIgnoringCase(FirstSearchCardHeader, _myWorksPage.GetSearhResultHeaderMatchesInShareholderHeader());
    }
    [Then(@"I also have same header of search result page")]
    public void ThenIAlsoHaveSameHeaderOfSearchResultPage()
    {
      _myWorksPage.IsSearchCardWriterNameMatchesInShareHolderTab();
    }
    [Then(@"I should have tunecode")]
    public void ThenIShouldHaveTunecode()
    {
      _myWorksPage.IsTuneCodeDisplayed();
    }
    [Then(@"I should have Performing share")]
    public void ThenIShouldHavePerformingShare()
    {
      _myWorksPage.IsPeformingShareDisplayed();
    }

    [Then(@"I should have CAE number")]
    public void ThenIShouldHaveCAENumber()
    {
      _myWorksPage.IsCAENumberDisplayed();
        
    }

    [Then(@"I should have mechanical share")]
    public void ThenIShouldHaveMechanicalShare()
    {
      _myWorksPage.IsMechanicalShareDisplayed();
    }

    [Then(@"I should have chain of title")]
    public void ThenIShouldHaveChainOfTitle()
    {
      _myWorksPage.IsChainOfTitleDisplayed();
    }

    [Then(@"I should have current Uk Performing society")]
    public void ThenIShouldHaveCurrentUkPerformingSociety()
    {
      _myWorksPage.IsCurrentUkPerformingSocietyDisplayed();
    }

    [Then(@"I should have current uk mechanical society")]
    public void ThenIShouldHaveCurrentUkMechanicalSociety()
    {
      _myWorksPage.IsCurrentUkMechanicalSocietyDisplayed();
    }


  }
}
