﻿using NUnit.Framework;
using OpenQA.Selenium;
using PrsfmUiTests.Selectors.MobileApp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.MobileApp
{
  [Binding]
  public sealed class LoginLogoutSteps
  {
    private readonly IWebDriver _driver;
    private readonly LoginMobileAppPage _loginMobileAppPage;
    private readonly HomePage _homePage;
    string settings = ConfigurationManager.AppSettings["MobileAppStgUrl"];
    public LoginLogoutSteps(IWebDriver driver)
    {
      _driver = driver;
      _loginMobileAppPage = new LoginMobileAppPage(_driver);
      _homePage = new HomePage(_driver);
    }
    [Given(@"I navigate to MobileApp application")]
    public void GivenINavigateToMobileAppApplication()
    {     
      _driver.Navigate().GoToUrl(settings);
    }

    [When(@"I log in using credentials ""(.*)"", ""(.*)""")]
    [When(@"I log in using valid credentials ""(.*)"", ""(.*)""")]
    public void WhenILogInUsingValidCredentials(string email, string password)
    {
      _loginMobileAppPage.EnterEmail(email);
      _loginMobileAppPage.EnterPassword(password);
      _loginMobileAppPage.ClickLogin();
    }
    [Given(@"I login into mobileapp application with valid crdentials")]
    public void GivenILoginIntoMobileappApplicationWithValidCrdentials()
    {
      _driver.Navigate().GoToUrl(settings);
      _loginMobileAppPage.GenericEnterMobileAppEmail();
      _loginMobileAppPage.GenericEnterMobileAppPassword();
      _loginMobileAppPage.ClickLogin();

    }
    [Given(@"I securely loggedin and switch to publisher from user profile")]
    public void GivenISecurelyLoggedinAndSwitchToPublisherFromUserProfile()
    {
      _driver.Navigate().GoToUrl(settings);
      _loginMobileAppPage.GenericEnterMobileAppEmail();
      _loginMobileAppPage.GenericEnterMobileAppPassword();
      _loginMobileAppPage.ClickLogin();
      _homePage.AssertPRSMobileApp();
      _homePage.SelectUserFromUserProfileMenu();
    }
    [Given(@"I securely loggedin into mobileapp application")]
    public void GivenISecurelyLoggedinIntoMobileappApplication()
    {
      _driver.Navigate().GoToUrl(settings);
      _loginMobileAppPage.GenericEnterMobileAppEmail();
      _loginMobileAppPage.GenericEnterMobileAppPassword();
      _loginMobileAppPage.ClickLogin();
    }

    [Then(@"I am successfully logged into PRSFM MobileApp application")]
    public void WhenIAmSuccessfullyLoggedIntoPRSFMMobileAppApplication()
    {
      _homePage.AssertPRSMobileApp();
    }
    [Then(@"I should be on landing page ""(.*)""")]
    [Then(@"I should see landing page title ""(.*)""")]
    public void ThenIShouldSeeLandingPageTitle(string HeaderTitle)
    {
      StringAssert.AreEqualIgnoringCase(HeaderTitle, _homePage.GetHeaderTitle());
    }
    [When(@"I navigate to user profile menu and select user")]
    public void WhenINavigateToUserProfileMenuAndSelectUser()
    {
      _homePage.SelectUserFromUserProfileMenu();
    }
    [When(@"I navigate to user profile menu and select another user")]
    public void WhenINavigateToUserProfileMenuAndSelectAnotherUser()
    {
      _homePage.SelectAnotherUserFromUserProfileMenu();
    }

    [Then(@"I see logged in user ""(.*)""")]
    public void ThenISeeLoggedInUser(string landingPageLoggedInuser)
    {
      StringAssert.AreEqualIgnoringCase(landingPageLoggedInuser, _homePage.GetLandingPageLoggedInUser());
    }

    [Then(@"I should be logout successfully ""(.*)""")]
    public void ThenIShouldBeLogoutSuccessfully(string LoginButtonText)
    {
      StringAssert.AreEqualIgnoringCase(LoginButtonText, _loginMobileAppPage.GetLoginBtn());
    }
    [Then(@"I should be presented with valid error message ""(.*)"" error message")]
    public void ThenIShouldBePresentedWithValidErrorMessageErrorMessage(string ErrorMessage)
    {
      StringAssert.AreEqualIgnoringCase(ErrorMessage, _loginMobileAppPage.GetInvaliPwdErrMsg());
    }
    [Then(@"I should be presented with valid ""(.*)"" error message")]
    public void ThenIShouldBePresentedWithValidErrorMessage(string ErrorMessage)
    {
      StringAssert.AreEqualIgnoringCase(ErrorMessage, _loginMobileAppPage.GetInvaliEmailErrMsg());
    }
    [Then(@"I should be presented with ""(.*)"" email error message")]
    public void ThenIShouldBePresentedWithEmailErrorMessage(string ErrorMessage)
    {
      StringAssert.AreEqualIgnoringCase(ErrorMessage, _loginMobileAppPage.GetEmailValidErrMsg());
    }

  }
}
