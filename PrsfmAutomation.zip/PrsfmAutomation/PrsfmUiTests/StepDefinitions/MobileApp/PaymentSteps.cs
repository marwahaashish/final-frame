﻿using NUnit.Framework;
using OpenQA.Selenium;
using PrsfmUiTests.Selectors.MobileApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.MobileApp
{
  [Binding]
  public sealed class PaymentSteps
  {
    private readonly IWebDriver _driver;
    private readonly PaymentsPage _paymentsPage;

    public PaymentSteps(IWebDriver driver)
    {
      _driver = driver;
      _paymentsPage = new PaymentsPage(_driver);
    }

   
    [Then(@"I should have payments page header title ""(.*)""")]
    public void ThenIShouldHavePaymentsPageHeaderTitle(string PageheaderTitle)
    {
      StringAssert.AreEqualIgnoringCase(PageheaderTitle, _paymentsPage.GetPaymentPageHeader());
    }

    [When(@"I select a month")]
    public void WhenISelectAMonth()
    {
      _paymentsPage.SelectMonth();
    }

    [When(@"I select a usage type")]
    public void WhenISelectAUsageType()
    {
      _paymentsPage.SelectUsageType();
    }

    [Then(@"I should have selected month ""(.*)""")]
    public void ThenIShouldHaveSelectedMonth(string SelectedMonth)
    {
      StringAssert.AreEqualIgnoringCase(SelectedMonth, _paymentsPage.GetSelectedMonth());
    }

    [Then(@"I should have selected usage type ""(.*)""")]
    public void ThenIShouldHaveSelectedUsageType(string SelectUsage)
    {
      StringAssert.AreEqualIgnoringCase(SelectUsage, _paymentsPage.GetSelectedUsageType());
    }

    [Then(@"I should have payment message ""(.*)""")]
    public void ThenIShouldHavePaymentMessage(string PaymentMsg)
    {
      _paymentsPage.IsPaymentMessageDisplayed(PaymentMsg);
    }
    [Then(@"I see a distribution month after edit ""(.*)""")]
    [Then(@"I see a distribution month ""(.*)""")]
    public void ThenISeeADistributionMonth(string DistMonth)
    {
      StringAssert.AreEqualIgnoringCase(DistMonth, _paymentsPage.GetDistributionAmount());
    }

    [When(@"I edit month")]
    public void WhenIEditMonth()
    {
      _paymentsPage.ClickAugMonthBtn();
    }

    [When(@"I edit usagetype")]
    public void WhenIEditUsagetype()
    {
      _paymentsPage.ClickOnlineUsageBtn();
    }

    [Then(@"I should have edit month ""(.*)""")]
    public void ThenIShouldHaveEditMonth(string EditMonth)
    {
      StringAssert.AreEqualIgnoringCase(EditMonth, _paymentsPage.GetSelectedMonth());
    }

    [Then(@"I should have edit usagetype ""(.*)""")]
    public void ThenIShouldHaveEditUsagetype(string EditUsageType)
    {
      StringAssert.AreEqualIgnoringCase(EditUsageType, _paymentsPage.GetSelectedUsageType());
    }
    [Then(@"I should have type of royalty")]
    public void ThenIShouldHaveTypeOfRoyalty()
    {
      _paymentsPage.IsTypeOfRoyaltyDisplayed();  
    }
    [Then(@"I should have footer link as Overseas ""(.*)""")]
    public void ThenIShouldHaveFooterLinkAsOverseas(string FooterLink)
    {
      StringAssert.AreEqualIgnoringCase(FooterLink, _paymentsPage.GetOverseasFooterLink());
    }
    [Then(@"I should have footer link as Latest Info ""(.*)""")]
    public void ThenIShouldHaveFooterLinkAsLatestInfo(string FooterLink)
    {
      StringAssert.AreEqualIgnoringCase(FooterLink, _paymentsPage.GetLatestInfoFooterLink());
    }
    [When(@"I click on overseas")]
    public void WhenIClickOnOverseas()
    {
      _paymentsPage.ClickOverSeasFooterLink();
    }
    [Then(@"I should see latest info url redirects to different page ""(.*)""")]
    public void ThenIShouldSeeLatestInfoUrlRedirectsToDifferentPage(string Url)
    {
      _paymentsPage.IsLatestInfoLinkRedirectionUrlDisplayed(Url);
    }

    [When(@"I click on latest info")]
    public void WhenIClickOnLatestInfo()
    {
      _paymentsPage.ClickLatestInfoFooterLink();
    }
    [Then(@"I should see overseas url redirects to different page ""(.*)""")]
    public void ThenIShouldSeeOverseasUrlRedirectsToDifferentPage(string Url)
    {
      _paymentsPage.IsOverseasLinkRedirectionUrlDisplayed(Url);
    }

  }
}
