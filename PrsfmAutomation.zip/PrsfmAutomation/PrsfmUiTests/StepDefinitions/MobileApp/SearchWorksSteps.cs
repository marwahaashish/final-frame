﻿using NUnit.Framework;
using OpenQA.Selenium;
using PrsfmUiTests.Selectors.MobileApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.MobileApp
{
  [Binding]
  public sealed class SearchWorksSteps
  {

    private readonly IWebDriver _driver;
    private readonly SearchWorksPage _searchWorkPage;
    private readonly SearchResultPage _searchResultPage;
    private readonly  MemWorksPage _memWorksPage;

    public SearchWorksSteps(IWebDriver driver)
    {
      _driver = driver;
      _searchWorkPage = new SearchWorksPage(_driver);
      _searchResultPage = new SearchResultPage(_driver);
      _memWorksPage = new MemWorksPage(_driver);

    }

    [Then(@"I should have search works page ""(.*)""")]
    public void ThenIShouldHaveSearchWorksPage(string PageTitle)
    {
      StringAssert.AreEqualIgnoringCase(PageTitle, _searchWorkPage.GetPageHeader());
    }
    [When(@"I enter work title ""(.*)""")]
    public void WhenIEnterWorkTitle(string WorkTitle)
    {
      _searchWorkPage.EnterWorkTitle(WorkTitle);
    }
    [When(@"I enter last name ""(.*)""")]
    public void WhenIEnterLastName(string LastName)
    {
      _searchWorkPage.EnterLastName(LastName);
    }
    [When(@"I search")]
    public void WhenISearch()
    {
      _searchWorkPage.ClickSearchButton();
    }
    [Then(@"I should be on search results page ""(.*)""")]
    public void ThenIShouldBeOnSearchResultsPage(string PageHeaderLinK)
    {
      StringAssert.AreEqualIgnoringCase(PageHeaderLinK, _searchResultPage.GetSearchResultsPageHeaderLink());
    }
    [Then(@"I should have header with worktitle and lastname ""(.*)""")]
    public void ThenIShouldHaveHeaderWithWorktitleAndLastname(string WorkTitleAndLastName)
    {
      StringAssert.AreEqualIgnoringCase(WorkTitleAndLastName, _searchResultPage.GetPageHeaderWorktitleAndLastName());
    }

    [Then(@"I should have header work title ""(.*)""")]
    public void ThenIShouldHaveHeaderWorkTitle(string workTitle)
    {
      StringAssert.AreEqualIgnoringCase(workTitle, _searchResultPage.GetSearchCardHeader());
    }
    [Then(@"I should have lastname matches in first search card result paragraph ""(.*)""")]
    public void ThenIShouldHaveLastnameMatchesInFirstSearchCardResultParagraph(string LastName)
    {
      _searchResultPage.IsLastNameMatchesWithFirstSearchCardParagraph(LastName);
    }
    [When(@"I click on firstsearch card")]
    public void WhenIClickOnFirstsearchCard()
    {
      _searchResultPage.ClickFirstSearchCardLink();

    }
    [Then(@"I should have worktitle as page header in search results page ""(.*)""")]
    public void ThenIShouldHaveWorktitleAsPageHeaderInSearchResultsPage(string WorkTitle)
    {
      StringAssert.AreEqualIgnoringCase(WorkTitle, _searchResultPage.GetTitleOfPageHeader());
    }

    [Then(@"I should have tab active ""(.*)""")]
    public void ThenIShouldHaveTabActive(string ActiveTab)
    {
      StringAssert.AreEqualIgnoringCase(ActiveTab, _searchResultPage.GetShareHolderActiveTab());
    }
  
    [Then(@"I should have inactive tab ""(.*)""")]
    public void ThenIShouldHaveInactiveTab(string Inactivetab)
    {
      StringAssert.AreEqualIgnoringCase(Inactivetab, _searchResultPage.GetMoreInactiveTab());
    }

    [When(@"I expand interested party")]
    public void WhenIExpandInterestedParty()
    {
      _searchResultPage.ClickFirstShareholderCard();
    }

    [Then(@"I should see view works ""(.*)""")]
    public void ThenIShouldSeeViewWorks(string LinkName)
    {
      StringAssert.AreEqualIgnoringCase(LinkName, _searchResultPage.GetViewWorksLink());
    }
    [When(@"I click on view works link")]
    public void WhenIClickOnViewWorksLink()
    {
      _searchResultPage.ClickViewWorks();
    }
    [Then(@"I should see writer name on memworks ""(.*)"" same on shareholder page")]
    public void ThenIShouldSeeWriterNameOnMemworksSameOnShareholderPage(string WriterName)
    {
      StringAssert.AreEqualIgnoringCase(WriterName, _memWorksPage.GetWriterNameMemWorks());
    }
    [Then(@"I should see writer name on viewWorks ""(.*)"" matches with writer name on shareholder tab")]
    public void ThenIShouldSeeWriterNameOnViewWorksMatchesWithWriterNameOnShareholderTab(string WriterName)
    {
      StringAssert.AreEqualIgnoringCase(WriterName, _memWorksPage.GetWriterNameMemWorks());
    }
    [Then(@"I should see writername on memworks")]
    public void ThenIShouldSeeWriternameOnMemworks()
    {
    _memWorksPage.IsWriterNameOnDisplayedonMemWorks();

    }
    [Then(@"I see membershipno")]
    public void ThenISeeMembershipno()
    {
      _memWorksPage.IsMembershipNumberDisplayed();
    }

    [Then(@"I should see writer name on header ""(.*)""")]
    public void ThenIShouldSeeWriterNameOnHeader(string WriterName)
    {
      StringAssert.AreEqualIgnoringCase(WriterName, _memWorksPage.GetWriterNameMemWorks());
     
    }
    [Then(@"I see membershipno ""(.*)""")]
    public void ThenISeeMembershipno(string MembershipNo)
    {
      StringAssert.AreEqualIgnoringCase(MembershipNo, _memWorksPage.GetMemberShipNumber());
    }

    [When(@"I click on more tab")]
    public void WhenIClickOnMoreTab()
    {
      _searchResultPage.ClickInactiveTab();
    }
    [Then(@"I should have registered title")]
    public void ThenIShouldHaveRegisteredTitle()
    {
      _searchResultPage.IsRegisteredTitleDisplayed();
    }
    [Then(@"I should have registered title matches with page header ""(.*)""")]
    public void ThenIShouldHaveRegisteredTitleMatchesWithPageHeader(string RegisteredTitle)
    {
      StringAssert.AreEqualIgnoringCase(RegisteredTitle, _searchResultPage.GetRegisteredTitle());
    }
    [Then(@"I should have registered title matches with page header")]
    public void ThenIShouldHaveRegisteredTitleMatchesWithPageHeader()
    {
      _searchResultPage.IsRegisteredTitleMatchesPageHeaderDisplayed();
    }

    [When(@"I click on shareholder tab")]
    public void WhenIClickOnShareholderTab()
    {
      _searchResultPage.ClickInactiveTab();
    }
    [Then(@"I should have ISWC")]
    public void ThenIShouldHaveISWC()
    {
      _searchResultPage.IsISWCDisplayed();
    }

    [Then(@"I should have work status")]
    public void ThenIShouldHaveWorkStatus()
    {
      _searchResultPage.IsWorkStatusdDisplayed();
    }

    [Then(@"I should have PRS last distribution")]
    public void ThenIShouldHavePRSLastDistribution()
    {
      _searchResultPage.IsPRSLastDistributionDisplayed();
    }

    [Then(@"I should have MCPS last distribution")]
    public void ThenIShouldHaveMCPSLastDistribution()
    {
      _searchResultPage.IsMCPSDistributionDisplayed();
    }

    [Then(@"I should have Work Amendment date")]
    public void ThenIShouldHaveWorkAmendmentDate()
    {
      _searchResultPage.IsWorkAmendmentDateDisplayed();
    }

    [Then(@"I should have work creation date")]
    public void ThenIShouldHaveWorkCreationDate()
    {
      _searchResultPage.IsWorkCreationDateDisplayed();
    }

    [Then(@"I should have publisher work reference\(s\)")]
    public void ThenIShouldHavePublisherWorkReferenceS()
    {
      _searchResultPage.IsPublisherWorkReferenceDisplayed();
    }

  }
}
