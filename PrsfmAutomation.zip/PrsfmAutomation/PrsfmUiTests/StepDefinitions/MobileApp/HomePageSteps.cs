﻿using NUnit.Framework;
using OpenQA.Selenium;
using PrsfmUiTests.Selectors.MobileApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.MobileApp
{
  [Binding]
  public sealed class HomePageSteps
  {
   
   private readonly IWebDriver _driver;
   private readonly HomePage _homePage;
   private readonly TermsAndConditionsPage _termsAndConditionPage;

   public HomePageSteps(IWebDriver driver)
    {
      _driver = driver;
     _homePage = new HomePage(driver);
      _termsAndConditionPage = new TermsAndConditionsPage(_driver);
    }

    [Then(@"I see membership ""(.*)""")]
    public void ThenISeeMembership(string MembershipNumber)
    {
      StringAssert.AreEqualIgnoringCase(MembershipNumber, _homePage.GetMembershipNumber());
    }
    [Then(@"I see my distribution amount")]
    public void ThenISeeMyDistributionAmount()
    {
      _homePage.IsDistributionAmountDisplayed();
    }

    [When(@"I click signout link from Hamburger menu")]
    public void WhenIClickSignoutLinkFromHamburgerMenu()
    {
      _homePage.ClickHamburgerMenuAndSignout();
    }

    [Then(@"I should see page with title ""(.*)""")]
    public void ThenIShouldSeePageWithTitle(string LogoutHeader)
    {
      StringAssert.AreEqualIgnoringCase(LogoutHeader, _homePage.GetLogoutPageHeader());
    }

    [When(@"I confirm to click logout")]
    public void WhenIConfirmToClickLogout()
    {
      _homePage.ClickLogoutBtn();
    } 

    [When(@"I expand DAO")]
   public void WhenIExpandDAO()
   {
      _homePage.ClickDAOButton();
   }

   [Then(@"I should have message ""(.*)""")]
   public void ThenIShouldHaveMessage(string DAOMessage)
   {
      StringAssert.AreEqualIgnoringCase(DAOMessage, _homePage.GetDAOText());
   }

   [When(@"I close DAO")]
   public void WhenICloseDAO()
   {
      _homePage.ClickDAOButton();
    }
    [When(@"I click on my works")]
    public void WhenIClickOnMyWorks()
    {
      _homePage.ClickMyWorks();
    }
    [When(@"I click on landing page payment dates")]
    public void WhenIClickOnLandingPagePaymentDates()
    {
      _homePage.ClickPaymentDatesLink();
    }
    [Then(@"I logout from hamburger menu")]
    public void WhenILogoutFromHamburgerMenu()
    {
      _homePage.ClickAndConfirmLogout();
    }
    [When(@"I click on works")]
    public void WhenIClickOnWorks()
    {
      _homePage.ClickWorks();
    }
    [Then(@"I should have terms and conditons ""(.*)""")]
    public void ThenIShouldHaveTermsAndConditons(string ButtonText)
    {
      StringAssert.AreEqualIgnoringCase(ButtonText, _termsAndConditionPage.GetProceddBtn());
    }
    [When(@"I proceed")]
    public void WhenIProceed()
    {
      _termsAndConditionPage.ClickProceedBtn();
    }

  }
}
