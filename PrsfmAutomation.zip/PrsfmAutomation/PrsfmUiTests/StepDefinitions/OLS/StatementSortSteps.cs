﻿using NUnit.Framework;
using OpenQA.Selenium;
using PrsfmUiTests.Selectors.OLS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.OLS
{
  [Binding]
  public sealed class StatementSortSteps
  {

    private readonly IWebDriver _driver;
    private readonly StatementSortPage _statementsortpage;
    

    public StatementSortSteps(IWebDriver driver) 
    {
      _driver = driver;
      _statementsortpage = new StatementSortPage(_driver);
    }
   
    [When(@"I sort statements by oldest date")]
    public void WhenISortStatementsByOldestDate()
    {
      _statementsortpage.ClickOldestSortListBtn();
    }

    [When(@"I sort statements by newest date")]
    public void WhenISortStatementsByNewestDate()
    {
      _statementsortpage.ClickNewestSortListBtn();
    }

  }
}
