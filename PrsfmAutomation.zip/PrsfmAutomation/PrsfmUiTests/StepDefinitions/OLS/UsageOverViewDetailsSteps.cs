﻿using OpenQA.Selenium;
using PrsfmUiTests.Selectors.OLS;
using System;
using NUnit.Framework;
using OlsUiTests.Pages;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.OLS
{
  [Binding]
  public sealed class UsageOverViewDetailsSteps
  {
    private readonly IWebDriver _driver;
    private readonly  UsageOverviewDetailsPage _usageOverviewDetails;

    public UsageOverViewDetailsSteps (IWebDriver driver)
    {
              _driver = driver;
      _usageOverviewDetails = new UsageOverviewDetailsPage(_driver);
    }

    [Then(@"I should see usage detail overview with title ""(.*)""")]
    public void ThenIShouldSeeUsageDetailOverviewWithTitle(string UsageTitle)
    {
      StringAssert.AreEqualIgnoringCase(UsageTitle, _usageOverviewDetails.GetUsageOverviewTitle());
    }
    [Then(@"I see usage percentage of total work ""(.*)""")]
    public void ThenISeeUsagePercentageOfTotalWork(string Percentageoftotalwork)
    {
      StringAssert.AreEqualIgnoringCase(Percentageoftotalwork, _usageOverviewDetails.GetPercentageOfTotalWork());
    }
    [Then(@"I see usage overview amount ""(.*)""")]
    public void ThenISeeUsageOverviewAmount(string UsageAmount)
    {
      StringAssert.AreEqualIgnoringCase(UsageAmount, _usageOverviewDetails.GetUsageAmount());
    }
    [Then(@"I should see usage table ""(.*)""")]
    public void ThenIShouldSeeUsageTable(string ColumnName)
    {
      StringAssert.AreEqualIgnoringCase(ColumnName, _usageOverviewDetails.GetUsageColumnName());
    }

    [Then(@"I should have table ""(.*)""")]
    public void ThenIShouldHaveTable(string TableColumnName)
    {
      StringAssert.AreEqualIgnoringCase(TableColumnName, _usageOverviewDetails.GetTitleColumnName());
    }

    [When(@"I sort usage column in descending order")]
    [When(@"I sort usage column in ascending order")]
    public void WhenISortUsageColumnInAscendingOrder()
    {
      _usageOverviewDetails.ClickUsageColumn();
    }
    [When(@"I sort title column in descending order")]
    [When(@"I sort title column in ascending order")]
    public void WhenISortTitleColumnInAscendingOrder()
    {
      _usageOverviewDetails.ClickTitleColumn();
    }

    [When(@"I sort subtotal in descending order")]
    [When(@"I sort subtotal in ascending order")]
    public void WhenISortSubtotalInAscendingOrder()
    {
      _usageOverviewDetails.ClickSubtotalColumn();
    }

    [Then(@"I should have amount ""(.*)"" in first row")]
    public void ThenIShouldHaveAmountInFirstRow(string UsageAmount)
    {
      StringAssert.AreEqualIgnoringCase(UsageAmount, _usageOverviewDetails.GetFirstUsageRowSubTotal());
    }

    [Then(@"I should have ""(.*)"" in first row")]
    public void ThenIShouldHaveInFirstRows(string UsageTitle)
    {
      StringAssert.AreEqualIgnoringCase(UsageTitle, _usageOverviewDetails.GetFirstUsageRowContent());
    }
    [When(@"I select first usage row content")]
    public void WhenISelectFirstUsageRowContent()
    {
      _usageOverviewDetails.ClickUsageFirstRow();
    }
    [Then(@"I should have usage song ""(.*)"" in first row")]
    public void ThenIShouldHaveUsageSongInFirstRow(string UsageSongTitle)
    {
      StringAssert.AreEqualIgnoringCase(UsageSongTitle, _usageOverviewDetails.GetFirstUsageRowSongTitle());
    }

    [When(@"I select first usage row content and first usage group song")]
    public void WhenISelectFirstUsageRowContentAndFirstUsageGroupSong()
    {
      _usageOverviewDetails.ClickFirstUsageRowSong();
    }
    [When(@"I sort usage work royalty amount in descending order")]
    [When(@"I sort usage work royalty amount in ascending order")]
    public void WhenISortUsageWorkRoyaltyAmountInAscendingOrder()
    {
      _usageOverviewDetails.ClickRoyaltyColumn();
    }
    [Then(@"I should have royaltyamount ""(.*)"" in first row")]
    public void ThenIShouldHaveRoyaltyamountInFirstRow(string RoyaltyAmount)
    {
      StringAssert.AreEqualIgnoringCase(RoyaltyAmount, _usageOverviewDetails.GetFirstUsageRowRoyaltyAmount());
    }
    [Then(@"I should have usagework accordian title""(.*)"" in first row")]
    public void ThenIShouldHaveUsageworkAccordianTitleInFirstRow(string UsageWorkTitle)
    {
      StringAssert.AreEqualIgnoringCase(UsageWorkTitle, _usageOverviewDetails.GetFirstUsagerowAccordianContent());
    }
    [When(@"I expand first accordion row of usage group")]
    public void WhenIExpandFirstAccordionRowOfUsageGroup()
    {
      _usageOverviewDetails.ClickFirstUsageAccordianRow();
    }
    [Then(@"I should have accordian content as ""(.*)""")]
    public void ThenIShouldHaveAccordianContentAs(string BroadCastRegion)
    {

      StringAssert.AreEqualIgnoringCase(BroadCastRegion, _usageOverviewDetails.GetBroadCastRegion());
    }
  
    [Then(@"I should have accordian title as ""(.*)""")]
    public void ThenIShouldHaveAccordianTitleAs(string AccordianRowTitle)
    {
      StringAssert.AreEqualIgnoringCase(AccordianRowTitle, _usageOverviewDetails.GetAccordianRowTitle());

    }

    [Then(@"I should have period ""(.*)""")]
    public void ThenIShouldHavePeriod(string Period)
    {
      StringAssert.AreEqualIgnoringCase(Period, _usageOverviewDetails.GetPeriod());
    }

    [Then(@"I should have usagetype ""(.*)""")]
    public void ThenIShouldHaveUsagetype(string UsageType)
    {
      StringAssert.AreEqualIgnoringCase(UsageType, _usageOverviewDetails.GetUsageType());
    }

    [Then(@"I should have type ""(.*)""")]
    public void ThenIShouldHaveType(string Type)
    {
      StringAssert.AreEqualIgnoringCase(Type, _usageOverviewDetails.GetAdjustment());
    }

    [Then(@"I should have time ""(.*)""")]
    public void ThenIShouldHaveTime(string Duration)
    {
      StringAssert.AreEqualIgnoringCase(Duration, _usageOverviewDetails.GetDuration());
    }

    [Then(@"I should have Reason ""(.*)""")]
    public void ThenIShouldHaveReason(string Reason)
    {
      StringAssert.AreEqualIgnoringCase(Reason, _usageOverviewDetails.GetReason());
    }


  }
}
