﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using PrsfmUiTests.Selectors.OLS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.OLS
{
  [Binding]
  public sealed class BreadCrumbSteps
  {
    private readonly IWebDriver _driver;
    private readonly BreadCrumbPage _breadcrumbPage;

    public BreadCrumbSteps(IWebDriver driver)
    {
      _driver = driver;
      _breadcrumbPage = new BreadCrumbPage(_driver);
    }

    [Then(@"I should have breadcrumb active page title ""(.*)""")]
    public void ThenIShouldHaveBreadcrumbActivePageTitle(string BreadCrumbUsageSongTitle)
    {
      StringAssert.AreEqualIgnoringCase(BreadCrumbUsageSongTitle, _breadcrumbPage.GetActiveBreadCrumbActiveUsageSongTitle());
    }

    [When(@"I navigate back accordian breadcrumb title")]
    public void WhenINavigateBackAccordianBreadcrumbTitle()
    {
      _breadcrumbPage.ClickBreadCrumbAccLink();
    }

    [Then(@"I should see active breadcrumb title link ""(.*)""")]
    public void ThenIShouldSeeActiveBreadcrumbTitleLink(string BreadcrumbAccTitle)
    {
      StringAssert.AreEqualIgnoringCase(BreadcrumbAccTitle, _breadcrumbPage.GetActiveAccordianTitle());
    }

    [When(@"I navigate back usagecard breadcrumb title")]
    public void WhenINavigateBackUsagecardBreadcrumbTitle()
    {
      _breadcrumbPage.ClickBreadCrumbUsageLink();
    }

    [Then(@"I should see active usage card active breadcrumb title link ""(.*)""")]
    public void ThenIShouldSeeActiveUsageCardActiveBreadcrumbTitleLink(string BreadcrumbUsageCardTitle)
    {
      StringAssert.AreEqualIgnoringCase(BreadcrumbUsageCardTitle, _breadcrumbPage.GetActiveUsageTitle());
    }

    [When(@"I navigate back PRS breadcrumb title")]
    public void WhenINavigateBackPRSBreadcrumbTitle()
    {
      _breadcrumbPage.ClickBreadCrumbPRSLink();
    }

    [Then(@"I should have breadcrumb title ""(.*)""")]
    public void ThenIShouldHaveBreadcrumbTitle(string PRSBreadCrumbTitle)
    {
      StringAssert.AreEqualIgnoringCase(PRSBreadCrumbTitle, _breadcrumbPage.GetActivePRSTitle());
    }

    [When(@"I navigate back on All statements")]
    public void WhenINavigateBackOnAllStatements()
    {
      _breadcrumbPage.ClickAllStmtsBreadCrumbLink();
    }

    [Then(@"I should see Page title ""(.*)""")]
    public void ThenIShouldSeePageTitle(string PageTitle)
    {
      StringAssert.AreEqualIgnoringCase(PageTitle, _breadcrumbPage.GetHeaderTitle());
    }
    [Then(@"I should see navigation button ""(.*)""")]
    public void ThenIShouldSeeNavigationButton(string ButtonText)
    {
      StringAssert.AreEqualIgnoringCase(ButtonText, _breadcrumbPage.GetBackBtn());
    }

    [When(@"I navigate back by using back button")]
    public void WhenINavigateBackByUsingBackButton()
    {
      _breadcrumbPage.ClickBackButton();
    }

  }
}
