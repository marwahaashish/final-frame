﻿using NUnit.Framework;
using OpenQA.Selenium;
using PrsfmUiTests.Selectors.OLS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.OLS
{
  [Binding]
  public sealed class TerritorySteps
  {
    private readonly IWebDriver _driver;
    private readonly TerritoryPage _territoryPage;

    public TerritorySteps(IWebDriver driver)
    {
      _driver = driver;
      _territoryPage = new TerritoryPage(_driver);
    }

    [Then(@"I see territory map")]
    public void ThenISeeTerritoryMap()
    {
      _territoryPage.IsMapDisplays();
    }
    [Then(@"I see table with column name ""(.*)""")]
    public void ThenISeeTableWithColumnName(string Column1)
    {
      StringAssert.AreEqualIgnoringCase(Column1, _territoryPage.GetEarningCountries());
    }

    [Then(@"I see another column name ""(.*)""")]
    public void ThenISeeAnotherColumnName(string Column2)
    {
      StringAssert.AreEqualIgnoringCase(Column2, _territoryPage.GetSubtotal());
    }

    [When(@"I sort earning countries column in descending order")]
    [When(@"I sort earning countries column in ascending order")]
    public void WhenISortEarningCountriesColumnInAscendingOrder()
    {
      _territoryPage.ClickEarningCountriesCol();
    }

    [Then(@"I should have first row percentage ""(.*)""")]
    public void ThenIShouldHaveFirstRowPercentage(string FirstRowPercentage)
    {
      StringAssert.AreEqualIgnoringCase(FirstRowPercentage, _territoryPage.GetFirstRowPercentage());
    }

    [When(@"I sort subtotal column in descending order")]
    [When(@"I sort subtotal column in ascending order")]
    public void WhenISortSubtotalColumnInAscendingOrder()
    {
      _territoryPage.ClickSubtotalColumn();
    }

    [Then(@"I should have first row subtotal ""(.*)""")]
    public void ThenIShouldHaveFirstRowSubtotal(string FirstRowSubtotal)
    {
      StringAssert.AreEqualIgnoringCase(FirstRowSubtotal, _territoryPage.GetFirstRowSubtotal());
    }
    [When(@"I select first row of earning country and territory row")]
    public void WhenISelectFirstRowOfEarningCountryAndTerritoryRow()
    {
      _territoryPage.ClickFirstEarningCountryRow();
    }

    [Then(@"I should have SWP overview header ""(.*)""")]
    public void ThenIShouldHaveSWPOverviewHeader(string HeaderTitle)
    {
      StringAssert.AreEqualIgnoringCase(HeaderTitle, _territoryPage.GetSWPOverViewHeader());
    }

    [Then(@"I have share variance button ""(.*)""")]
    public void ThenIHaveShareVarianceButton(string ButtonText)
    {
      StringAssert.AreEqualIgnoringCase(ButtonText, _territoryPage.GetShareVarianceButton());
    }
    [When(@"I click on share variance button")]
    public void WhenIClickOnShareVarianceButton()
    {
      _territoryPage.ClickShareVarianceBtn();
    }

    [Then(@"I should have popup header title ""(.*)""")]
    public void ThenIShouldHavePopupHeaderTitle(string PopUpheaderTitle)
    {
      StringAssert.AreEqualIgnoringCase(PopUpheaderTitle, _territoryPage.GetSharevariancePopUpHeader());
    }
    [When(@"I select sharevariance table first row")]
    public void WhenISelectSharevarianceTableFirstRow()
    {
      _territoryPage.ClickShareVarinaceFirstRow();
    }

    [Then(@"I should have share ""(.*)""")]
    public void ThenIShouldHaveShare(string Share)
    {
      _territoryPage.IsShareDisplayed(Share);
    }

  }

}
