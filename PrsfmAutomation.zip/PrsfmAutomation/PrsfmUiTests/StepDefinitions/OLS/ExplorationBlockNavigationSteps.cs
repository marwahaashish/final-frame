﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using PrsfmUiTests.Helpers;

namespace OlsUiTests.Steps
{
  [Binding]
  internal class ExplorationBlockNavigationSteps
  {
    private readonly IWebDriver _driver;
    private readonly ExplorationBlockPage _explorationBlock;


    public ExplorationBlockNavigationSteps(IWebDriver driver)
    {
      _driver = driver;
      _explorationBlock = new ExplorationBlockPage(_driver);
    }

    [When(@"I click on Usage Type tab")]
    public void WhenIClickOnUsageTypeTab()
    {
      _explorationBlock.ClickUsageTypeTab();
    }
    [Then(@"I should be taken to usage section ""(.*)""")]
    public void ThenIShouldBeTakenToUsageSection(string SectionTitle1)
    {
      StringAssert.AreEqualIgnoringCase(SectionTitle1, _explorationBlock.GetUsageTypePage());
    }

    [When(@"I click on Territory tab")]
    public void ThenIClickOnTerritoryTab()
    {
      _explorationBlock.ClickTerritoryTab();
    }

    [Then(@"I should be taken to territory section ""(.*)""")]
    public void ThenIShouldBeTakenToTerritorySection(string SectionTitle2)
    {
      StringAssert.AreEqualIgnoringCase(SectionTitle2, _explorationBlock.GetTerritoryPage());
    }

    [Then(@"I click on Works tab")]
    public void ThenIClickOnWorksTab()
    {
      _explorationBlock.ClickWorksTab();
    }

    [Then(@"I should be taken to works section ""(.*)""")]
    public void ThenIShouldBeTakenToWorksSection(string SectionTitle3)
    {
      StringAssert.AreEqualIgnoringCase(SectionTitle3, _explorationBlock.GetEarningWorksPage());
    }

    [Then(@"I should see stacked bar chart ""(.*)""")]
    public void ThenIShouldSeeStackedBarChart(string HeaderTitle)
    {
      StringAssert.AreEqualIgnoringCase(HeaderTitle, _explorationBlock.GetStackBarHeader());
    }
    [Then(@"I see usage card ""(.*)""")]
    public void ThenISeeUsageCard(string UsageCardTitle)
    {
      StringAssert.AreEqualIgnoringCase(UsageCardTitle, _explorationBlock.GetUsageCardHeader());
    }
    [When(@"I navigate to usage card")]
    public void WhenINavigateToUsageCard()
    {
      
      _explorationBlock.ClickUsageCard();
    }


  }
}
