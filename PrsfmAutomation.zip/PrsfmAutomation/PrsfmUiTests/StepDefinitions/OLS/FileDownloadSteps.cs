﻿using NUnit.Framework;
using OpenQA.Selenium;
using PrsfmUiTests.Selectors.OLS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.OLS
{
  [Binding]
  public sealed class FileDownloadSteps
  {
    private readonly IWebDriver _driver;
    private readonly FileDownloadPage _fileDownloadPage;

    public FileDownloadSteps(IWebDriver driver)
    {

      _driver = driver;
      _fileDownloadPage = new FileDownloadPage(_driver);
    }
    [When(@"I click download from PRS july stmt")]
    public void WhenIClickDownloadFromPRSJulyStmt()
    {
      _fileDownloadPage.ClickDownload();
    }

    [Then(@"I should have statement modal dialog opened ""(.*)""")]
    public void ThenIShouldHaveStatementModalDialogOpened(string ModalDialogTitle)
    {

      StringAssert.AreEqualIgnoringCase(ModalDialogTitle, _fileDownloadPage.GetModalDialogTitle());

    }
    [When(@"I click on download")]
    public void WhenIClickOnDownload()
    {
      _fileDownloadPage.ClickModalDialogDownload();
    }
    [Then(@"I should see file download successfully ""(.*)""")]
    public void ThenIShouldSeeFileDownloadSuccessfully(string FileName)
    {
      _fileDownloadPage.CheckFileDownloaded(FileName);
    }

  }
}
