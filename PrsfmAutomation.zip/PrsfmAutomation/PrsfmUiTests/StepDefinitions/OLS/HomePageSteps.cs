﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using PrsfmUiTests.StepDefinitions.OLS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace OlsUiTests.Steps
{
  [Binding]
  public sealed class HomePageSteps
  {
    private readonly IWebDriver _driver;
    private readonly HomePagePage _homePage;
    private readonly LogInAndLogOutSteps _logInSteps;
   // private readonly StatementFilterSteps _statementFilterSteps;


    public HomePageSteps(IWebDriver driver)
    {
      _driver = driver;
      _homePage = new HomePagePage(_driver);
      _logInSteps = new LogInAndLogOutSteps(_driver);
    }

    [Then(@"I should have '(.*)'")]
    public void ThenIShouldHave(string CaeIpi)
    {
      StringAssert.AreEqualIgnoringCase(CaeIpi, _homePage.GetHomePageTitle());
    }
    [Then(@"I should see header ""(.*)""")]
    public void ThenIShouldSeeHeader(string HeaderText)
    {
      StringAssert.AreEqualIgnoringCase(HeaderText, _homePage.GetHomePageTitle());
    }

    [Then(@"I should be presented with '(.*)'")]
    public void ThenIShouldBePresentedWith(string NOP)
    {
      StringAssert.AreEqualIgnoringCase(NOP, _homePage.GetNOP());
    }

    [When(@"I click on All Statement link")]
    public void WhenIClickOnAllStatementLink()
    {
      _homePage.ClickAllStatementsLink();
    }

    [When(@"I click on Analytics link")]
    public void WhenIClickOnAnalyticsLink()
    {
      _homePage.ClickAnalyticsLink();
    }

    [When(@"I click on Royal Statement link")]
    public void WhenIClickOnRoyalStatementLink()
    {
      _homePage.ClickRoyalStatementsLink();
    }

    //[Then(@"I should be directed to '(.*)' page")]
    //public void ThenIShouldBeDirectedToPage(string PageHeader)
    //{
    //    StringAssert.AreEqualIgnoringCase(PageHeader, _homePage.GetPageHeaderTitleText());
    //}
    [Then(@"I should navigate to '(.*)' page")]
    public void ThenIShouldNavigateToPage(string PageHeader)
    {
      StringAssert.AreEqualIgnoringCase(PageHeader, _homePage.GetHomePageTitle());
    }

    //[AfterScenario]
    //public void logout()
    //{
    //  if (_homePage.IsLoggedIn())
    //  {
    //   _logInSteps.ThenWhenISignOut();
    //  }

    //}

    [Then(@"I should see statement card ""(.*)"" on allstatements page")]
    public void ThenIShouldSeeStatementCardOnAllstatementsPage(string StmtDateYear)
    {
      StringAssert.AreEqualIgnoringCase(StmtDateYear, _homePage.GetStmtDateandYear());
    }

    [Then(@"I should see content container with notice heading ""(.*)"" in allstatements page")]
    public void ThenIShouldSeeContentContainerWithNoticeHeadingInAllstatementsPage(string HeaderText)
    {
      StringAssert.AreEqualIgnoringCase(HeaderText, _homePage.GetNoticeHeader());
    }
    [Then(@"I should see single stmt card ""(.*)""")]
    public void ThenIShouldSeeSingleStmtCard(string StmtDateYear)
    {
      StringAssert.AreEqualIgnoringCase(StmtDateYear, _homePage.GetSignleStmtCard());
    }
    [When(@"I click on sort toggle button")]
    public void WhenIClickOnSortToggleButton()
    {
      
      _homePage.ClickSortButton();
    }
    [Then(@"I should see statement with date ""(.*)""")]
    public void ThenIShouldSeeStatementWithDate(string StmtDate)
    {
      StringAssert.AreEqualIgnoringCase(StmtDate, _homePage.GetFirstStmtYear());
    }
    [When(@"I click on list view button")]
    public void WhenIClickOnListViewButton()
    {
      _homePage.ClickListViewButton();
    }

    [Then(@"I should see statements all statements list table ""(.*)""")]
    public void ThenIShouldSeeStatementsAllStatementsListTable(string AccordianTitle)
    {
      StringAssert.AreEqualIgnoringCase(AccordianTitle, _homePage.GetAccordianTitle());
    }

  }
}
