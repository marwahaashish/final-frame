﻿using NUnit.Framework;
using OpenQA.Selenium;
using PrsfmUiTests.Selectors.OLS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.OLS
{
  [Binding]
  public sealed class SearchSteps
  {
    private readonly IWebDriver _driver;
    private readonly SearchPage _searchPage;

    public SearchSteps(IWebDriver driver)
    {

      _driver = driver;
      _searchPage = new SearchPage(_driver);

    }

    [When(@"I search with invalid term ""(.*)""")]
    public void WhenISearchWithInvalidTerm(string SearchTerm)
    {
      _searchPage.ClickStatementSearchWithInvalidTerm(SearchTerm);
    } 

    [Then(@"I should have no search results ""(.*)""")]
    public void ThenIShouldHaveNoSearchResults(string NoResultsheader)
    {
      StringAssert.AreEqualIgnoringCase(NoResultsheader, _searchPage.GetNoResultsHeader());
    }

    [When(@"I search with valid term ""(.*)""")]
    public void WhenISearchWithValidTerm(string SearchTerm)
    {
      _searchPage.ClearSearchResultAndValidSearch(SearchTerm);
    }
    [When(@"I clear searchresult and search with valid term ""(.*)""")]
    public void WhenIClearSearchresultAndSearchWithValidTerm(string SearchTerm)
    { 
      _searchPage.ClearSearchResultAndValidSearch(SearchTerm);
    }

    [Then(@"I should have results displayed ""(.*)""")]
    public void ThenIShouldHaveResultsDisplayed(string SearchResultTitle)
    {

      StringAssert.AreEqualIgnoringCase(SearchResultTitle, _searchPage.GetSearchResultTitle());
    }

    [Then(@"I Should see table with column name ""(.*)""")]
    public void ThenIShouldSeeTableWithColumnName(string ColumnName)
    {
      StringAssert.AreEqualIgnoringCase(ColumnName, _searchPage.GetEarningCountries());
    }

    [Then(@"I should have usage searchresults ""(.*)""")]
    public void ThenIShouldHaveUsageSearchresults(string SearchResultTitle)
    {
      StringAssert.AreEqualIgnoringCase(SearchResultTitle, _searchPage.GetUsageFirstResultTitle());
    }

    [Then(@"I should have no search results for territories ""(.*)""")]
    public void ThenIShouldHaveNoSearchResultsForTerritories(string NoResultsheader)
    {
      StringAssert.AreEqualIgnoringCase(NoResultsheader, _searchPage.GetTerritoriesValidSearchErrorNotification());
    }
    [Then(@"I should have no search results for usages ""(.*)""")]
    public void ThenIShouldHaveNoSearchResultsForUsages(string NoResultsheader)
    {
      StringAssert.AreEqualIgnoringCase(NoResultsheader, _searchPage.GetUsagesValidSearchErrorNotification());
    }

    [Then(@"I should have no search results for works ""(.*)""")]
    public void ThenIShouldHaveNoSearchResultsForWorks(string NoResultsheader)
    {
      StringAssert.AreEqualIgnoringCase(NoResultsheader, _searchPage.GetWorksValidSearchErrorNotification());

    }


  }
}
