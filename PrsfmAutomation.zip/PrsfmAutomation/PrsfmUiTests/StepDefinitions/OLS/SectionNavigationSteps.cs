﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace OlsUiTests.Steps
{
  [Binding]
  public sealed class SectionNavigationSteps
  {
    private readonly IWebDriver _driver;
    private readonly LoginPrsfmPage _loginPrsfmPage;
    private readonly HomePagePage _homePage;
    private readonly AuthorizationPage _authPage;

    public SectionNavigationSteps(IWebDriver driver)
    {
      _driver = driver;
      _homePage = new HomePagePage(_driver);
      _loginPrsfmPage = new LoginPrsfmPage(_driver);
      _authPage = new AuthorizationPage(_driver);
    }

    [Given(@"I securely logged in as writer earning writer's royalty with PRS")]
    public void GivenISecurelyLoggedInAsWriterEarningWriterSRoyaltyWithPRS()
    {     
      _loginPrsfmPage.GenericEnterEmail();
      _loginPrsfmPage.GenericEnterPassword();
      _loginPrsfmPage.ClickSubmitBtn();    

    }

    [Given(@"I securely logged in as writer earning writer's royalty with PRS&MCPS")]
    public void GivenISecurelyLoggedInAsWriterEarningWriterSRoyaltyWithPRSMCPS()
    {
      _loginPrsfmPage.GenericEnterEmail();
      _loginPrsfmPage.GenericEnterPassword();
      _loginPrsfmPage.ClickSubmitBtn();
      _loginPrsfmPage.SelectPRSMCPSWriter();

    }

    [Given(@"I securely logged in and select publisher member")]
    public void GivenISecurelyLoggedInAndSelectPublisherMember()
    {
      _loginPrsfmPage.GenericEnterEmail();
      _loginPrsfmPage.GenericEnterPassword();
      _loginPrsfmPage.ClickSubmitBtn();
      _loginPrsfmPage.SelectPRSMCPSWriter();
    }

    [Given(@"I securely logged in as publisher earning publishing royalty with PRS&MCPS")]
    public void GivenISecurelyLoggedInAsPublisherEarningPublishingRoyaltyWithPRSMCPS()
    {
      _loginPrsfmPage.GenericEnterEmail();
      _loginPrsfmPage.GenericEnterPassword();
      _loginPrsfmPage.ClickSubmitBtn();
      //_loginPrsfmPage.SelectPRSMCPSPublisher();
      _loginPrsfmPage.AssertPRSLoggedIn();
    }

    [When(@"I navigate to All Statement section")]
    public void WhenINavigateToAllStatementSection()
    {
      _homePage.ClickAllStatementsLink();
    }

    [Then(@"I should be on All Statements page")]
    public void ThenIShouldBeOnAllStatementsPage()
    {
      StringAssert.AreEqualIgnoringCase("All statements", _homePage.GetAllStatementText());
    }

    [Then(@"I should be on All Statements page ""(.*)""")]
    public void ThenIShouldBeOnAllStatementsPage(string PageTitle)
    {
      StringAssert.AreEqualIgnoringCase(PageTitle, _homePage.GetAllStatementText());
    }

    [Then(@"I see selector tab text""(.*)""")]
    public void ThenISeeSelectorTabText(string SelectorTab)
    {
      StringAssert.AreEqualIgnoringCase(SelectorTab, _homePage.GetStatementGroup());
    }
    [When(@"I navigate to Royalties section")]
    public void ThenINavigateToRoyaltiesSection()
    {
      _homePage.ClickRoyalStatementsLink();
    }

    [Then(@"I should be on Royalties page")]
    public void ThenIShouldBeOnRoyaltiesPage()
    {
      StringAssert.AreEqualIgnoringCase("Earning works", _homePage.GetRoyaltyText());
    }

    [Then(@"I navigate to Analytic section")]
    public void ThenINavigateToAnalyticSection()
    {
      _homePage.ClickAnalyticsLink();
    }

    //[Then(@"I should be on Analytic page")]
    //public void ThenIShouldBeOnAnalyticPage()
    //{
    //    StringAssert.AreEqualIgnoringCase("Analysis Page", _homePage.GetPageHeaderTitleText());
    //}
    [Then(@"I see all statements memberships dropdown")]
    public void ThenISeeAllStatementsMembershipsDropdown()
    {
      _homePage.IsMembersDropDownDisplayed();
    }
    [Then(@"I see filter toggle button ""(.*)""")]
    public void ThenISeeFilterToggleButton(string filterToggleButtontext)
    {
      StringAssert.AreEqualIgnoringCase(filterToggleButtontext, _homePage.GetFilterButtontext());
    }
    [Then(@"I see sort toggle button ""(.*)""")]
    public void ThenISeeSortToggleButton(string sortToggleButtontext)
    {
      StringAssert.AreEqualIgnoringCase(sortToggleButtontext, _homePage.GetSortButtonText());
    }
    [Then(@"I see card view button")]
    public void ThenISeeCardViewButton()
    {
      _homePage.IsCardViewToggleBtnDisplayed();
    }
    [Then(@"I see list view button")]
    public void ThenISeeListViewButton()
    {
      _homePage.IsListViewToggleBtnDisplayed();
    }
    [When(@"I click on view of mcps statement card content")]
    public void WhenIClickOnViewOfMcpsStatementCardContent()
    {
     _loginPrsfmPage.ClickMcpsStatementViewLink();
    }
    [When(@"I click on view of prs statement card content")]
    public void WhenIClickOnViewOfPrsStatementCardContent()
    {
      _loginPrsfmPage.ClickPrsStatementViewlink();
    }
    [When(@"I navigate to view prs statement")]
    public void WhenINavigateToViewPrsStatement()
    {
      _loginPrsfmPage.ClickPrsStatementViewlink();
    }
    [When(@"I navigate to view mcps statement")]
    public void WhenINavigateToViewMcpsStatement()
    {
      _loginPrsfmPage.ClickMcpsStatementViewLink();
    }
    [When(@"I click filter toggle button")]
    public void WhenIClickFilterToggleButton()
    {
      _homePage.ClickFilterToggleBtn();
    }
    [When(@"I navigate and select july prs statement")]
    public void WhenINavigateAndSelectJulyPrsStatement()
    {
      _loginPrsfmPage.ClickPrsStmyJulyViewLink();

    }

  }
}
