﻿using NUnit.Framework;
using PrsfmUiTests.Helpers;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace OlsUiTests.Steps
{
  [Binding]
  internal class ExplorationBlockWorksTableSteps
  {
    private readonly IWebDriver _driver;
    private readonly ExplorationBlockPage _explorationBlock;


    public ExplorationBlockWorksTableSteps(IWebDriver driver)
    {
      _driver = driver;
      _explorationBlock = new ExplorationBlockPage(_driver);
    }

    [Then(@"I can view royalty earning works table")]
    public void ThenICanViewRoyaltyEarningWorksTable()
    {
      _explorationBlock.isWorksGraphPresent();
    }

    [Then(@"I can view royalty earning works graph")]
    public void ThenICanViewRoyaltyEarningWorksGraph()
    {
      _explorationBlock.isWorksGraphPresent();
    }

    [When(@"I navigate to page two on row four")]
    public void WhenINavigateToPageTwoOnRowFour()
    {
      _explorationBlock.ClickPageTwo();
    }

    [Then(@"I should be presented ""(.*)"" and ""(.*)""")]
    public void ThenIShouldBePresentedAnd(string WorksTitle, string RoyaltyAmount)
    {
      StringAssert.AreEqualIgnoringCase(WorksTitle, _explorationBlock.GetRowFourWorksTitle());
      StringAssert.AreEqualIgnoringCase(RoyaltyAmount, _explorationBlock.GetRowFourRoyaltyAmount());
    }

    [Then(@"I navigate to page eight row one")]
    public void ThenINavigateToPageEightRowOne()
    {
      _explorationBlock.ClickPageEight();
    }

    [Then(@"I should also have ""(.*)"" and ""(.*)""")]
    public void ThenIShouldAlsoHaveAnd(string WorksTitle1, string RoyaltyAmount1)
    {
      StringAssert.AreEqualIgnoringCase(WorksTitle1, _explorationBlock.GetRowOneWorkTitle());
      StringAssert.AreEqualIgnoringCase(RoyaltyAmount1, _explorationBlock.GetRowOneRoyaltyAmount());
    }

    [When(@"I sort all works by royalty ascending")]
    public void WhenISortAllWorksByRoyaltyAscending()
    {
      _explorationBlock.SortByRoyalty();
      _explorationBlock.ClickSortRoyaltyAscending();
    }

    [Then(@"I should have ""(.*)"" in the first row")]
    public void ThenIShouldHaveInTheFirstRow(string worksTitle)
    {
      StringAssert.AreEqualIgnoringCase(worksTitle, _explorationBlock.GetRowOneWorkTitle());
    }

    [When(@"I sort all works by royalty descending")]
    public void WhenISortAllWorksByRoyaltyDescending()
    {
      _explorationBlock.SortByRoyalty();
      _explorationBlock.ClickSortRoyaltyDescending();
    }

    [When(@"I sort top works by title ascending")]
    public void WhenISortTopWorksByTitleAscending()
    {
      _explorationBlock.SortByTitle();
      _explorationBlock.ClickSortTitleAscending();
    }

    [When(@"I sort all works by title descending")]
    public void WhenISortAllWorksByTitleDescending()
    {
      _explorationBlock.SortByTitle();
      _explorationBlock.ClickSortTitleDescending();
    }

    [Then(@"I should have ""(.*)"" in the first row for sorting")]
    public void ThenIShouldHaveInTheFirstRowForSorting(string p0)
    {
      new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath($"//div[@class='works-table__title-text'][contains(text(),'{p0}')]")));
    }

    [When(@"I hover on graph")]
    public void WhenIHoverOnGraph()
    {
      _explorationBlock.HoverOnWorksBarChart();
    }

    [Then(@"I should see tool tip")]
    public void ThenIShouldSeeToolTip()
    {

    }

    [Then(@"I have earning amount first bar ""(.*)""")]
    public void ThenIHaveEarningAmountOneFirstBar(string FirstBarEarAmount)
    {
      _explorationBlock.IsFirstbarEarningAmountDisplayed(FirstBarEarAmount);
    }

    [Then(@"I have earning amount second bar chart ""(.*)""")]
    public void ThenIHaveEarningAmountSecondBarChart(string SecondBarEarAmount)
    {
      _explorationBlock.IsSecondbarEarningAmountDisplayed(SecondBarEarAmount);
    }

    [Then(@"I have earning amount third bar chart ""(.*)""")]
    public void ThenIHaveEarningAmountThirdBarChart(string ThirdBarEarAmount)
    {
      _explorationBlock.IsThirdbarEarningAmountDisplayed(ThirdBarEarAmount);
    }

    [Then(@"I have earning amount Foruth bar chart ""(.*)""")]
    public void ThenIHaveEarningAmountForuthBarChart(string FourthBarEarAmount)
    {
      _explorationBlock.IsFourthbarEarningAmountDisplayed(FourthBarEarAmount);
    }

    [Then(@"I have earning amount Fifth bar chart  ""(.*)""")]
    public void ThenIHaveEarningAmountFifthBarChart(string FifthBarEarAmount)
    {
      _explorationBlock.IsFifthbarEarningAmountDisplayed(FifthBarEarAmount);
    }

  }
}
