﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace OlsUiTests.Steps
{
  [Binding]
  public sealed class LogInAndLogOutSteps
  {

    private readonly IWebDriver _driver;
    private readonly LoginPrsfmPage _loginPrsfmPage;
    private readonly NavigationBarPage _navigationBarPage;
    private readonly StatementSelectorPage _statementSelectorPage;


    public LogInAndLogOutSteps(IWebDriver driver)
    {
      _driver = driver;
      _loginPrsfmPage = new LoginPrsfmPage(_driver);
      _navigationBarPage = new NavigationBarPage(_driver);
      _statementSelectorPage = new StatementSelectorPage(_driver);
    }

    [Given(@"Prsfm login page has launched")]
    public void GivenPrsfmLoginPageHasLaunched()
    {
      _navigationBarPage.PRSFMSiteIsLaunched();
    }

    [When(@"I sign in using valid credentials ""(.*)"", ""(.*)""")]
    public void WhenISignInUsingValidCredentials(string username, string password)
    {
      _loginPrsfmPage.EnterUsername(username);
      _loginPrsfmPage.EnterPassword(password);
      _loginPrsfmPage.ClickSubmitBtn();
    }

    [When(@"I am successfully logged into PRSFM")]
    public void WhenIAmSuccessfullyLoggedIntoPRSFM()
    {
      _loginPrsfmPage.AssertPRSLoggedIn();
    }
        
   [Given(@"I navigate to OLS")]
    public void WhenINavigateToOLS() 
    {
     _driver.Navigate().GoToUrl("https://statements01.qa01.prsformusic.com/");
     //_driver.Navigate().GoToUrl("https://statementssg01.prsformusic.com/#/");
    }

    [Then(@"I should see title ""(.*)""")]
    public void ThenIShouldSeeTitle(string HeaderTitle)
    {
      StringAssert.AreEqualIgnoringCase(HeaderTitle, _statementSelectorPage.AssertOLSHomePage());
    }

    [Then(@"when I sign out")]
    public void ThenWhenISignOut()
    {
      _driver.Navigate().GoToUrl("https://statements01.qa01.prsformusic.com/authorization/logout");
      _loginPrsfmPage.ClickLoginLink();
    }

    [Then(@"I should be presented ""(.*)"" error message")]
    public void ThenIShouldBePresentedErrorMessage(string ErrorMessage)
    {
      StringAssert.AreEqualIgnoringCase(ErrorMessage, _loginPrsfmPage.GetEnterEmailRequest());
    }

    [Then(@"I should be presented ""(.*)"" password error message")]
    public void ThenIShouldBePresentedPasswordErrorMessage(string ErrorMessage)
    {
      StringAssert.AreEqualIgnoringCase(ErrorMessage, _loginPrsfmPage.GetPasswordError());
    }

    [Then(@"I should be presented ""(.*)"" email error message")]
    public void ThenIShouldBePresentedEmailErrorMessage(string ErrorMessage)
    {
      StringAssert.AreEqualIgnoringCase(ErrorMessage, _loginPrsfmPage.GetEmailError());
    }
    
    [When(@"I click on logout")]
    public void WhenIClickOnLogout()
    {
     _loginPrsfmPage.Clicklogout();

    }

    [Then(@"I should be logout successfully")]
    public void ThenIShouldBeLogoutSuccessfully()
    {
      StringAssert.AreEqualIgnoringCase("LOG IN", _loginPrsfmPage.GetLoginButtontext());
    }


  }
}
