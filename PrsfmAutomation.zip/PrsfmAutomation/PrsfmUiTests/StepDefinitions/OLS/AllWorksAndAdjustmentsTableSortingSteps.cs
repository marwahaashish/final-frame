﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace OlsUiTests.Steps
{
  [Binding]
  internal class AllWorksAndAdjustmentsTableSortingSteps
  {
    private readonly IWebDriver _driver;
    private readonly AllWorksAndAdjustmentsPage _allworks;

    public AllWorksAndAdjustmentsTableSortingSteps(IWebDriver driver)
    {
      _driver = driver;
      _allworks = new AllWorksAndAdjustmentsPage(_driver);
    }

    [When(@"I sort all works table in descending order")]
    public void WhenISortAllWorksTableInDescendingOrder()
    {
      _allworks.ClickAllWorkTablesSortingArrow();
    }

    [Then(@"I should have ""(.*)""")]
    public void ThenIShouldHave(string WorkTitle)
    {
      StringAssert.AreEqualIgnoringCase(WorkTitle, _allworks.GetAllWorksFirstWorkTitle(WorkTitle));
    }

    [Then(@"I should have first work title as descending ""(.*)""")]
    public void ThenIShouldHaveFirstWorkTitleAsDescending(string FirstWorkTitleCodeDescending)
    {
      _allworks.IsDescAllWorksFirstWorkTitleDisplayed(FirstWorkTitleCodeDescending);
    }
    [Then(@"I should have first work title as ascending ""(.*)""")]
    public void ThenIShouldHaveFirstWorkTitleAsAscending(string FirstWorkTitleCodeDescending)
    {
      _allworks.IsAsceAllWorksFirstWorkTitleDisplayed(FirstWorkTitleCodeDescending);
    }


    [When(@"I sort all works table by all works ascending")]
    [Then(@"I sort all works table by all works ascending")]
    public void ThenISortAllWorksTableByAllWorksAscending()
    {
      _allworks.ClickAllWorkTablesSortingArrow();
    }

    [When(@"I sort adjustments table in descending order")]
    public void WhenISortAdjustmentsTableInDescendingOrder()
    {
      _allworks.ClickAdjustmentsTableSortingArrow();
    }

    [Then(@"I sort adjustments table by all works ascending")]
    public void ThenISortAdjustmentsTableByAllWorksAscending()
    {
      _allworks.ClickAdjustmentsTableSortingArrow();
    }

    [Then(@"I should have ""(.*)"" for adjustment table")]
    public void ThenIShouldHaveForAdjustmentTable(string WorkTitle)
    {
      StringAssert.AreEqualIgnoringCase(WorkTitle, _allworks.GetAdjustmentsFirstWorkTitle());
    }

  }
}
