﻿using PrsfmUiTests.Helpers;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Threading;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace OlsUiTests.Steps
{
  [Binding]
  public sealed class AuthorizationSteps
  {
    private readonly IWebDriver _driver;
    private readonly AuthorizationPage _authorizationPage;

    public AuthorizationSteps(IWebDriver driver)
    {
      _driver = driver;
      _authorizationPage = new AuthorizationPage(_driver);
      PageFactory.InitElements(_driver, _authorizationPage);
    }


    [When(@"Enter security authorization password")]
    public void WhenEnterSecurityAuthorizationPassword(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();

      new WebDriverExtensions(_driver).ElementIsDisplayed(_authorizationPage.PasswordTextbox);
      _authorizationPage.PasswordTextbox.SendKeys((string)formData.Password);
    }


    [When(@"Complete security authorization memorable phrase")]
    public void WhenCompleteSecurityAuthorizationMemorablePhrase()
    {
      _authorizationPage.AnswerSecurityQiestion();
    }

    [Then(@"Click submit for security authorization")]
    public void ThenClickSubmitForSecurityAuthorization()
    {
      _authorizationPage.ClickSubmitBtnOnSecurity();
    }
  }
}
