﻿using NUnit.Framework;
using OlsUiTests.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace OlsUiTests.Steps
{
  [Binding]
  internal class EarningAllWorksUsagesSteps
  {
    private readonly IWebDriver _driver;
    private readonly EarningAllWorksUsageCardPage _usagePage;

    public EarningAllWorksUsagesSteps(IWebDriver driver)
    {
      _driver = driver;
      _usagePage = new EarningAllWorksUsageCardPage(_driver);
    }


    [When(@"I click on a single work")]
    public void WhenIClickOnASingleWork()
    {
      _usagePage.ClickSingleWork();
    }

    //[Then(@"I should see a modal pop up with the following usages details:")]
    //public void ThenIShouldSeeAModalPopUpWithTheFollowingUsagesDetails(Table table)
    //{
    //  var usageHeader = table.CreateInstance<UsageHeaderDetails>();

    //  Assert.AreEqual(usageHeader.WorkTitle, _usagePage.GetWorksTitle());
    //  Assert.AreEqual(usageHeader.WorkNumber, _usagePage.GetWorkNum());
    //  Assert.AreEqual(usageHeader.YourShare, _usagePage.GetYourShare());
    //  Assert.AreEqual(usageHeader.IP1, _usagePage.GetIP1());
    //  Assert.AreEqual(usageHeader.RoyaltyAmount, _usagePage.GetTotalRoyalty());
    //}
    [Then(@"I should see work title as ""(.*)""")]
    public void ThenIShouldSeeWorkTitleAs(string WorkTitle)
    {
      Assert.AreEqual(WorkTitle, _usagePage.GetWorksTitle(WorkTitle));
    }
    [Then(@"I see  work number as ""(.*)""")]
    public void ThenISeeWorkNumberAs(string WorkNumber)
    {
      _usagePage.IsWorkNumDisplayed(WorkNumber);
    }
  
    [Then(@"I see your share as ""(.*)""")]
    public void ThenISeeYourShareAs(string Share)
    {
       _usagePage.IsShareDisplayed(Share);
    }

    [Then(@"I see interested party member name ""(.*)""")]
    public void ThenISeeInterestedPartyMemberName(string IPl)
    {
      _usagePage.IsInterestedPartyMemberNameDisplayed(IPl);

    }

    [Then(@"I see royalty amount ""(.*)""")]
    public void ThenISeeRoyaltyAmount(string RoyaltyAmount)
    {
      StringAssert.AreEqualIgnoringCase(RoyaltyAmount, _usagePage.GetTotalRoyalty());
    }

    [Then(@"I should see a pop up modal with the following usages details:")]
    public void ThenIShouldSeeAPopUpModalWithTheFollowingUsagesDetails(Table table)
    {
      var usageDetails = table.CreateInstance<UsagesDetails>();

      Assert.AreEqual(usageDetails.Usage, _usagePage.GetUsage());
      if (!String.IsNullOrEmpty(usageDetails.Region))
      {
        Assert.AreEqual(usageDetails.Region, _usagePage.GetRegion());
      }
      if (!String.IsNullOrEmpty((usageDetails.Production)))
      {
        Assert.AreEqual(usageDetails.Production, _usagePage.GetProduction());
      }
      StringAssert.StartsWith(usageDetails.Period, _usagePage.GetPeriod());
      Assert.AreEqual(usageDetails.Duration, _usagePage.GetDuration());
      Assert.AreEqual(usageDetails.Performances, _usagePage.GetPerformances());
      Assert.AreEqual(usageDetails.Subtotal, _usagePage.GetSubtotal());
    }

    public class UsageHeaderDetails
    {
      public string WorkTitle { get; set; }
      public string WorkNumber { get; set; }
      public string YourShare { get; set; }
      public string IP1 { get; set; }
      public string IP2 { get; set; }
      public string IP3 { get; set; }
      public string IP4 { get; set; }
      public string RoyaltyAmount { get; set; }

    }

    public class UsagesDetails
    {
      public string Usage { get; set; }
      public string Region { get; set; }
      public string Production { get; set; }
      public string Period { get; set; }
      public string Duration { get; set; }
      public string Performances { get; set; }
      public string Subtotal { get; set; }
    }

  }
}
