﻿using NUnit.Framework;
using OpenQA.Selenium;
using PrsfmUiTests.Selectors.OLS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PrsfmUiTests.StepDefinitions.OLS
{
  [Binding]
  public sealed class StatementFilterSteps
  {

    private readonly IWebDriver _driver;
    private readonly StatementFilterPage _statementfilterpage;

    public StatementFilterSteps(IWebDriver driver)
    {
      _driver = driver;
      _statementfilterpage = new StatementFilterPage(_driver);

    }

    [Then(@"I should see filterlist opened")]
    public void ThenIShouldSeeFilterlistOpened()
    {
      _statementfilterpage.IsFilterlistDisplayed();
    }

    [Then(@"I see society filter PRS and MCPS checkboxes already selected")]
    public void ThenISeeSocietyFilterPRSAndMCPSCheckboxesAlreadySelected()
    {
      _statementfilterpage.IsPRSSocietyFilterChecked();
      _statementfilterpage.IsMCPSSocietyFilterChecked();
    }
    
    [When(@"I click on filter type statements")]
    public void WhenIClickOnFilterTypeStatements()
    {
      _statementfilterpage.ClickStatementFilter();
    }
    [Then(@"I should see statement type Main and Mini are selected")]
    public void ThenIShouldSeeStatementTypeMainAndMiniAreSelected()
    {
      _statementfilterpage.IsMainStatementTypeCheckboxSelected();
      _statementfilterpage.IsMiniStatementTypeCheckboxSelected();
    }
    [When(@"I filter main statement type")]
    public void WhenIFilterMainStatementType()
    {
      _statementfilterpage.UncheckMainStmtFilter();
    }
    [When(@"I filter mini statement type")]
    public void WhenIFilterMiniStatementType()
    {
      _statementfilterpage.UncheckMiniStmtFilter();
    }

    [When(@"I filter prs society statements")]
    public void WhenIFilterPrsSocietyStatements()
    {
      _statementfilterpage.UncheckPRSSocietyStmts();
    }

    [When(@"I filter stmts by year ""(.*)""")]
    public void WhenIFilterStmtsByYear(string Year)
    {
      _statementfilterpage.ClickYear(Year);
    }

    [When(@"I filter stmts by month ""(.*)""")]
    public void WhenIFilterStmtsByMonth(string Month)
    {
      _statementfilterpage.ClickMonth(Month);
    }


  }
}
