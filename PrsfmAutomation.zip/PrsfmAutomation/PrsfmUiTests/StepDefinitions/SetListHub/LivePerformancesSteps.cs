﻿using System;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors.SetlistHub;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using NUnit.Framework;
using System.Threading;

namespace PrsfmUiTests.StepDefinitions.SetListHub
{
  [Binding]
  public sealed class LivePerformancesSteps
  {
    private readonly IWebDriver _driver;
    private readonly LivePerformanceSelectors _livePerformanceSelectors;
    private string[] _saveResults;
    

    public LivePerformancesSteps(IWebDriver driver)
    {
      _driver = driver;
      _livePerformanceSelectors = new LivePerformanceSelectors(driver);
      PageFactory.InitElements(_driver, _livePerformanceSelectors);

    }


    [Then(@"Click Report a Live Performance button")]
    public void ThenClickReportALivePerformanceButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ReportLivePerformanceButton2);
        _livePerformanceSelectors.ReportLivePerformanceButton2.Click();
      });
    }


    [When(@"The performance datepicker is opened")]
    public void WhenThePerformanceDatepickerIsOpened()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
        _livePerformanceSelectors.PerformanceDatePicker.Click();
      });
    }

    [Then(@"no validation assimilate message shown")]
    public void ThenNoValidationAssimilateMessageShown()
    {
      Assert.IsFalse(_livePerformanceSelectors.LessThan1YearUSCountryValidationMsg.Displayed);
    }
    [Then(@"validation assimilate message displayed")]
    public void ThenNoValidationAssimilateMessageDisplayed()
    {
      Assert.IsTrue(_livePerformanceSelectors.LessThan1YearUSCountryValidationMsg.Displayed);
    }

    [Then(@"I validate setlist name date@Venue")]
    public void ThenIValidateSetlistNameDateVenue()
    {
      Thread.Sleep(4000);
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SetListName);
        var SetListPopulatedName = _livePerformanceSelectors.SetListName.Text;
        var VenueNamePopulated = _livePerformanceSelectors.VenueSearch.Text;
       Assert.IsTrue(_livePerformanceSelectors.SetListName.Text.Contains(VenueNamePopulated));
        Console.WriteLine(SetListPopulatedName);
      });
      
    }

    [When(@"Select a ""(.*)"" performance date")]
    public void ThenSelectAPerformanceDate(string specificDate)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
        _livePerformanceSelectors.PerformanceDatePicker.Click();

        _livePerformanceSelectors.PerformanceDatePicker.SendKeys(specificDate);
      });      
    }


    [Then(@"Select a performance date")]
    public void ThenSelectAPerfromanceDate(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      switch ((string)formData.PerformanceDate)
      {
        case "Gr 7 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusSevenYears);
          });
          break;
        case "less than 4 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusFourYears);
            Thread.Sleep(3000);
          });
          break;

        case "Gr 2 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusTwoYears);
          });

          break;

        case "Eq 1 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusOneYear);
          });
          break;

        case "Yesterday":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();
            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.Yesterday);
            Thread.Sleep(2000);
          });
          break;

        case "Today":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.Today);
            Thread.Sleep(3000);
          });
          break;
        case "less than 7 Years plus 1 day":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusSevenYearsPlusAddDay);
            Thread.Sleep(3000);
          });
          break;
        case "less than 7 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusSevenYears);
            Thread.Sleep(3000);
          });
          break;
          case "less than 1 Year minus 1 day":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusOneYearMinusOneDay);
            Thread.Sleep(3000);
          });
          break;
          case "Today's date plus 1 day ":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.TodayPlusAddDay);
            Thread.Sleep(3000);
          });
          break;
          case "less than 2 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusTwoYears);
          });

          break;
          case "less than 1 Year":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusOneYear);
            Thread.Sleep(3000);
          });
          break;
         
          case "MinusOneYear and add FourMonths":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusOneYearAddFourMonths);
            Thread.Sleep(3000);
          });
          break;
        case "Today Minus Ten Days":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();
            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.TodayMinusTenDays);
            Thread.Sleep(3000);
          });
          break;
        case "Today Minus Six Months":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();
            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.TodayMinusSixMonths);
            Thread.Sleep(3000);
          });
          break;
        case "TodaysDate MinusOneyear AddMonth MinusSixMonths":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();
            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.TodaysDateMinusOneyearAddMonthMinusSixMonths);
            Thread.Sleep(3000);
          });
          break;
        default:
          Console.WriteLine("*** UNKnown date");
          break;
      }
    }
    [Then(@"I validate selected performance date appears in date field")]
    public void ThenIValidateSelectedPerformanceDateAppearsInDateField(Table table)
    {
      Assert.IsTrue(_livePerformanceSelectors.PerformanceDatePicker.Displayed);
           
    }
 
    [Then(@"Select a International territory")]
    public void ThenSelectAInternationalTerritory(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.CountrySearch);
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.CountrySearch);
        _livePerformanceSelectors.CountrySearch.SendKeys((string)formData.Country);
        _livePerformanceSelectors.VenueSearch.SendKeys(Keys.Tab);
        _livePerformanceSelectors.WhiteSpace.Click();
      });
    }


    [Then(@"Validate message shown")]
    public void ThenValidateMessageShown(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();

      switch ((string)formData.Text)
      {
        case "We require additional validation where members report a performance which is more than seven years old. Please":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Greater7YrsMsg);
            Assert.IsTrue(_livePerformanceSelectors.Greater7YrsMsg.Text.Contains((string)formData.Text));
          });
          break;

        case "International performances must have occurred in the past two years in order to be valid":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Greater2YrsMsg);
            Assert.IsTrue(_livePerformanceSelectors.Greater2YrsMsg.Text.Contains((string)formData.Text));
          });
          break;

        case "Your performance at this venue must have occurred in the past year in order to be valid.":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Equal1YrMsg);
            Assert.IsTrue(_livePerformanceSelectors.Equal1YrMsg.Text.Contains((string)formData.Text));
          });
          break;

        case "Please select valid country":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.InvaldCountry);
            Assert.IsTrue(_livePerformanceSelectors.InvaldCountry.Text.Contains((string)formData.Text));
          });
          break;



        default:
          Console.WriteLine("*** UNKnown Page Title passed test");
          break;

      }

    }

    [Then(@"Select a venue")]
    public void ThenSelectAVenue(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.VenueSearch);

      });
      _livePerformanceSelectors.VenueSearch.SendKeys((string)formData.Venue);

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AssimilateSearch);

      });
     // Thread.Sleep(10000);

      //TaskHelper.ExecuteTask(() =>
      //{
      //  new WebDriverExtensions(_driver).WaitForPresence(
      //            _driver.FindElement(
      //                By.XPath(_livePerformanceSelectors.HighlightedResult((string)formData.Venue))));

       
      //});
     
      //TaskHelper.ExecuteTask(() =>
      //{
      //  new WebDriverExtensions(_driver).SafeJavaScriptClick(_driver.FindElement(
      //       By.XPath(_livePerformanceSelectors.HighlightedResult((string)formData.Venue))));

      //});

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.VenueSearchResult);


      });

      _livePerformanceSelectors.VenueSearchResult.Click();
      //*[@id="venueSearch"]/div[2]/ul/li[3]/div

    }

    [Then(@"Select a venue not in search list")]
    public void ThenSelectAVenueNotInSearchList(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.VenueSearch);
        _livePerformanceSelectors.VenueSearch.SendKeys((string)formData.Venue);
      });
    }

    [Then(@"Click Submit button")]
    public void ThenClickSubmitButton()
    {
      TaskHelper.ExecuteTask(() =>
      {       
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SubmitButton);
        new WebDriverExtensions(_driver).SafeJavaScrollToElement(_livePerformanceSelectors.SubmitButton);
        _livePerformanceSelectors.SubmitButton.Click();
      });
    }

    [Then(@"Click final Submit button")]
    public void ThenClickFinalSubmitButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.FinalSubmit);
        _livePerformanceSelectors.FinalSubmit.Click();
      });
     }

    [Then(@"Validate details submitted")]
    public void ThenValidateDetailsSubmitted()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.FinalSubmitPageText);
        Assert.IsTrue(_livePerformanceSelectors.FinalSubmitPageText.Text.Contains("Thank you for reporting your performance."));
      });
    }


    [Then(@"Click Find more Venues button")]
    public void ThenClickFindMoreVenuesButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.FindMoreVenues);
        _livePerformanceSelectors.FindMoreVenues.Click();
      });
    }

    [Then(@"Select a venue from the Google search")]
    public void ThenSelectAVenueFromTheGoogleSearch(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.GooglevenueSearch);
        _livePerformanceSelectors.GooglevenueSearch.SendKeys((string)formData.Venue);
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.GooglevenueSearch.SendKeys(Keys.Down);
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.GooglevenueSearch.SendKeys(Keys.Return);
      });
    }

    [Then(@"Select a Performer")]
    public void ThenSelectAPerformer(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformerName);
        _livePerformanceSelectors.PerformerName.SendKeys((string)formData.Performer);

      });
     
     
    }

    [Then(@"Click the Save button")]
    public void ThenClickTheSaveButton()
    {
      _saveResults = SaveDetails();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SaveForLaterButton);
        _livePerformanceSelectors.SaveForLaterButton.Click();
      });
    }

    private string[] SaveDetails()
    {
      string[] results = new string[3];
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
        var perforrmancedate = _livePerformanceSelectors.PerformanceDatePicker.GetAttribute("value");
        results[0] = perforrmancedate;
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.VenueSearch);
        var venue = _livePerformanceSelectors.VenueSearch.GetAttribute("value");
        results[1] = venue;
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformerName);
        var performer = _livePerformanceSelectors.PerformerName.GetAttribute("value");
        results[2] = performer;
      });

      return results;
    }

    private string SaveDetails(IWebElement element)
    {
      string details = "";
      string[] results = new string[1];
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(element);
        details = element.GetAttribute("value");
      });

      return details;
    }

    [Then(@"Validate detials saved")]
    public void ThenValidateDetialsSaved()
    {
      var date = _saveResults[0].Remove(0, 1);
      Assert.IsTrue(_livePerformanceSelectors.SavedPerformanceDetail(date).Contains(date));

      var place = _saveResults[1];
      Assert.IsTrue(_livePerformanceSelectors.SavedPerformanceDetail(place).Contains(place));

      var who = _saveResults[2];
      Assert.IsTrue(_livePerformanceSelectors.SavedPerformanceDetail(who).Contains(who));
    }

    [Then(@"Click the Add Works button")]
    public void ThenClickTheAddWorksButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AddWorksButton);
        _livePerformanceSelectors.AddWorksButton.Click();
      });
    }

    [Then(@"Validate Add Works form is displayed")]
    public void ThenValidateAddWorksFormIsDisplayed()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AddWorksLabel);
        Assert.IsTrue(_livePerformanceSelectors.AddWorksLabel.Displayed);
      });
    }

    [Then(@"Enter a Work Search '(.*)'")]
    public void ThenEnterAWorkSearch(string workItem)
    {

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.WorkSearch);     

      });
      TaskHelper.ExecuteTask(() =>
      {       
        _livePerformanceSelectors.WorkSearch.Clear();
        _livePerformanceSelectors.WorkSearch.SendKeys(workItem);
      
      });
    }
    [Then(@"I select the displayed criteria")]
    public void ThenISelectTheDisplayedCriteria()
    {
      TaskHelper.ExecuteTask(() =>
      {
       // _livePerformanceSelectors.AddWorkBtn.Click();
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AddWorkBtn);
         Thread.Sleep(3000);
      });
    }
    [Then(@"Select displayed result")]
    public void ThenSelectDisplayedResult()
    {
      TaskHelper.ExecuteTask(() =>
      {
        Thread.Sleep(3000);
      _livePerformanceSelectors.SearchResult.Click();
        Thread.Sleep(2000);

      });

    }

    [Then(@"Select the '(.*)'")]
    public void ThenSelectThe(string workItem)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath(_livePerformanceSelectors.WorksList(workItem))));    
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).JavaScriptClick(_driver.FindElement(By.XPath(_livePerformanceSelectors.WorksList(workItem))));
      });
    }
    [Then(@"select the search results list")]
    public void ThenSelectTheSearchResultsList()
    {
      //Thread.Sleep(8000);
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.YourWorkFirstSearchResult);
      });

      _livePerformanceSelectors.SafeJavaScriptClick(_livePerformanceSelectors.YourWorkFirstSearchResult);
    }
    [Then(@"I enter work search '(.*)'")]
    public void WhenIEnterWorkSearch(string workItem)
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.WorkSearch.Clear();
        _livePerformanceSelectors.AdvanceSearch.SendKeys(Keys.Control + "a");
        _livePerformanceSelectors.AdvanceSearch.SendKeys(workItem);
         
      });
      Thread.Sleep(6000);
    }
    [When(@"I enter IPI ""(.*)""")]
    public void WhenIEnterIPI(string  IPI)
    {
      Thread.Sleep(10000);
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.WorkSearch.SendKeys(Keys.Clear);
        _livePerformanceSelectors.AdvanceSearch.SendKeys(Keys.Control + "a");
        _livePerformanceSelectors.AdvanceSearch.SendKeys(IPI);
        
      });

    }

    [When(@"I enter writername '(.*)'")]
    public void WhenIEnterWritername(string WriterName)
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.ClearSearchButton.Click();
        _livePerformanceSelectors.AdvanceSearch.SendKeys(Keys.Control + "a");
        _livePerformanceSelectors.AdvanceSearch.SendKeys(WriterName);
        Thread.Sleep(6000);
      });
    }

    [Then(@"Select the twelth returned result")]
    public void ThenSelectTheTwelthReturnedResult()
    {
     // Thread.Sleep(20000);
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(By.XPath("//h2[contains(text(),'Other Works')]")));
      });    
      _livePerformanceSelectors.TwelThResultAForest.Click();
   
    }

    [Then(@"Click the Done button")]
    public void ThenClickTheDoneButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddWorksDoneButton.Click();
      });
      Thread.Sleep(5000);
    }


    [Then(@"Validate '(.*)' saved")]
    public void ThenValidateSaved(string passedText)
    {

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.WorklistDetails.Click();
      });
      Thread.Sleep(5000);
      IWebElement element = _driver.FindElement(By.XPath(_livePerformanceSelectors.WorkInfo));
      Assert.AreEqual(element.Text, passedText);
    }
    [Then(@"Validate '(.*)' displays in workinfo")]
    public void ThenValidateDisplaysInWorkinfo(string Criteria)
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.WorklistDetails.Click();
      });
      Assert.IsTrue(_livePerformanceSelectors.WriterNameInWorkInfo.Text.Contains(Criteria));
     
    }
    [Then(@"Validate work added '(.*)' displays in workinfo")]
    public void ThenValidateWorkAddedDisplaysInWorkinfo(string Title)
    {
      Assert.IsTrue(_livePerformanceSelectors.AddedWorkTitle.Text.Contains(Title));
    }

    [Then(@"Validate added work '(.*)' saved")]
    public void ThenValidateAddedWorkSaved(string WriterName)
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.WorklistDetails.Click();
      });

      var WNameOnItemList = _livePerformanceSelectors.WriterNameonAddedItemList.Text;
      Assert.AreEqual(WNameOnItemList, WriterName);
    }

    [Then(@"Validate TuneCode '(.*)' saved")]
    public void ThenValidateTuneCodeSaved(string tunecodeText)
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.WorklistDetails.Click();
      });

      IWebElement tunecode = _driver.FindElement(By.XPath(_livePerformanceSelectors.Tunecode(tunecodeText)));
      Assert.AreEqual(tunecode.Text, tunecodeText);
    }

    [Then(@"Delete the '(.*)' from the list")]
    public void ThenDeleteTheFromTheList(string workItem)
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.DeleteWorklistIcon.Click();
      });
    }

    [Then(@"validate the '(.*)' is deleted from the list")]
    public void ThenValidateTheIsDeletedFromTheList(string p0)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).IsElementNotVisible(_driver,
                  By.XPath(_livePerformanceSelectors.WorkInfo));
      });
    }



    [Then(@"Enter a new Setlist name")]
    public void ThenEnterANewSetlistName()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.SetListName);
        _livePerformanceSelectors.SetListName.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(20));

      });
    }




    [Then(@"Select a random venue")]
    public void ThenSelectARandomVenue()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.VenueSearch);
        _livePerformanceSelectors.VenueSearch.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(20));
      });
    }


    [Then(@"Press the add existing setlist link")]
    public void ThenPressTheAddExistingSetlistLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScrollToElement(_livePerformanceSelectors.AddExistingSetList);
        _livePerformanceSelectors.AddExistingSetList.Click();
      });
    }
    [Then(@"click and add existing setlist link")]
    public void ThenClickAndAddExistingSetlistLink()
    {
      Thread.Sleep(3000);
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScrollToElement(_livePerformanceSelectors.AddExistingSetListBtn);
        _livePerformanceSelectors.AddExistingSetListBtn.Click();
      });
    }

    [Then(@"Select a exisitng setlist")]
    public void ThenSelectAExisitngSetlist()
    {
      //select the first item in the list


      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SelectExistingSetList);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.SelectExistingSetList);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SelectExistingSetList);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.SelectExistingSetList);
      });
    }


    [Then(@"Click the Add setlist button")]
    public void ThenClickTheAddSetlistButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddSetListbutton.Click();
      });
    }


    [Then(@"Click Advanced link")]
    public void ThenClickAdvancedLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AdvancedWorksearchLink.Click();
      });
    }

    [Then(@"Click Can't find it link")]
    public void ThenClickCanTFindItLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.CantFindItLink);
        //_livePerformanceSelectors.CantFindItLink.Click();

      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.CantFindItLink);     

      });
    }   

    [Then(@"Check the Register Work link")]
    public void ThenClcikTheRwegisterWorkLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.RegisterYourWorkHere);
      });
      //_livePerformanceSelectors.RegisterYourWorkHere.Click();

    }

    [Then(@"Validate the register work page is displayed")]
    public void ThenValidateTheRegisterWorkPageIsDisplayed()
    {

      TaskHelper.ExecuteTask(() =>
      {
        _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);
      });

      TaskHelper.ExecuteTask(() =>
      {
        WindowsHandling.SelectLastHandle("Register or Amend My Music - Home", _driver);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.RegisterWorksPageHeader);
        var text = _livePerformanceSelectors.RegisterWorksPageHeader.Text;
        Assert.AreEqual(text, "Register or amend my music");
      });


    }

    [Then(@"Check for Upload Fiches link Work link")]
    public void ThenClcikTheUploadFichesLinkWorkLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
              //_livePerformanceSelectors.Uploadfiches.Click();              
              new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Uploadfiches);
      });
    }

    [Then(@"Validate the Upload Fiches page is displayed")]
    public void ThenValidateTheUploadFichesPageIsDisplayed()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(20);
      });
      WindowsHandling.SelectLastHandle("Raise a query", _driver);
    }

    [Then(@"Click the Add Venue details Manually button")]
    public void ThenClickTheAddVenueDetailsManuallyButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AddVenueDetailsManually);
        _livePerformanceSelectors.AddVenueDetailsManually.Click();
      });
    }


    [Then(@"populate venue details")]
    public void ThenPopulateVenueDetails()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _saveResults = new string[1];
        _livePerformanceSelectors.AddVenueDetailsManuallyName.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(15));
        _saveResults[0] = SaveDetails(_livePerformanceSelectors.AddVenueDetailsManuallyName);
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyCity.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(8));
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyPostCode.SendKeys("SW16 1ER");
      });
    }

    [Then(@"populate venue details max chars")]
    public void ThenPopulateVenueDetailsMaxChars()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _saveResults = new string[1];
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AddVenueDetailsManuallyName);
        _livePerformanceSelectors.AddVenueDetailsManuallyName.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(256));
        _saveResults[0] = SaveDetails(_livePerformanceSelectors.AddVenueDetailsManuallyName);
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyCity.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(256));
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyPostCode.SendKeys("SW16 1ER");
      });
    }


    [Then(@"Validate venue details")]
    public void ThenValidateVenueDeatils()
    {
      var x = _livePerformanceSelectors.VenueSearch.GetAttribute("value");
      Assert.IsTrue(_livePerformanceSelectors.VenueSearch.GetAttribute("value").Contains(_saveResults[0]));
      Assert.AreEqual(x, _saveResults[0]);
    }


    [Then(@"Select Headliner")]
    public void ThenSelectHeadliner()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.HeadlinerRadioButton.Click();
      });
    }


    [Then(@"Click the Create A New SetList button")]
    public void ThenClickTheCreateANewSetListButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.CreateAnewSetList.Click();
      });
    }


    [Then(@"Select the festival radio button")]
    public void ThenSelectTheFestivalRadioButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.YesFestivalRadioButton.Click();
      });
    }

    [Then(@"Populate the Add Festival details form max chars")]
    public void ThenPopulateTheAddFestivalDetailsFormMaxChars()
    {
      _saveResults = new string[3];
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.FestivalName.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(256));
      });
    }

    [Then(@"validate error message displayed '(.*)'")]
    public void ThenValidateErrorMessageDispaled(string screen)
    {
      switch (screen)
      {
        case "FestivalVenue":
          TaskHelper.ExecuteTask(() =>
          {
            var x = _livePerformanceSelectors.InvalidFestivalVenueMessage.Text;
            Assert.AreEqual("You have exceeded the maximum character limit for this field.", x);
          });
          break;

        case "Venue":
          TaskHelper.ExecuteTask(() =>
          {
            var x = _livePerformanceSelectors.InvalidVenueNameMessage.Text;
            Assert.AreEqual("You have exceeded the maximum character limit for this field.", x);
          });
          break;


        default:
          Console.WriteLine("*** UNKnown Error");
          break;
      }
    }

    [Then(@"press the Amend Festival details button")]
    public void ThenPressTheAmendFestivalDetailsButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AmendFestivalButton);
        _livePerformanceSelectors.AmendFestivalButton.Click();
      });
    }


    [Then(@"Press the Done button")]
    public void ThenPressTheDoneButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddWorksDoneButton.Click();
      });
    }

    [Then(@"validate Festival Details are displayed")]
    public void ThenValidateFestivalDetailsAreDisplayed()
    {
      bool x = _livePerformanceSelectors.reviewFestivalName.Text.Contains(_saveResults[0]);

      var y = _livePerformanceSelectors.reviewFestivalName.GetAttribute("value");
      var z = _livePerformanceSelectors.reviewFestivalName.Text;


      Assert.AreEqual(x, y);
    }

    [Then(@"Select the PRS Logo")]
    public void ThenSelectThePRSLogo()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.PRSLogo.Click();
      });
    }

    [Then(@"Select the '(.*)' link")]
    public void ThenSelectTheLink(string link)
    {
      switch (link)

      {
        case
              "PRS Logo"
              :
          TaskHelper.ExecuteTask(() =>
          {
            _livePerformanceSelectors.PRSLogo.Click();

          });
          break;

        case
              "Contact Us"
              :
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.LivePerformances);
                      // _livePerformanceSelectors.ContactUs.Click();
                    });
          break;


        default:
          Console.WriteLine("*** UNKnown Page Title passed test");
          break;
      }
    }


    [Then(@"Validate screen '(.*)' is displayed")]
    public void ThenValidateScreenIsDisplayed(string screen)
    {
      switch (screen)
      {
        case
              "SavedPerformace"
              :
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.LivePerformances);
          });
          TaskHelper.ExecuteTask(() =>
                    {
                      Assert.IsNotNull(WindowsHandling.ReturnWindonwTitle(_driver));
                      var tabUrl = WindowsHandling.ReturnWindonwURL(_driver);

                      StringAssert.Contains("performances/saved", tabUrl);

                    });
          break;

        //case
        //    "Contact Us"
        //    :
        //    TaskHelper.ExecuteTask(() =>
        //    {
        //        var newTab = WindowsHandling.SelectLastHandle("Set List Feedback - Formstack",_driver);
        //        var tabUrl = WindowsHandling.ReturnWindonwURL(newTab);
        //        Assert.IsNotNull(WindowsHandling.ReturnWindonwTitle(newTab));
        //        StringAssert.Contains( "forms/setlist",tabUrl);

        //    });
        //    break;

        case
              "Submitted"
              :
          TaskHelper.ExecuteTask(() =>
          {
            Assert.IsNotNull(WindowsHandling.ReturnWindonwTitle(_driver));
            var tabUrl = WindowsHandling.ReturnWindonwURL(_driver);
            StringAssert.Contains("performances/submitted", tabUrl);

          });
          break;

        default:
          Console.WriteLine("*** UNKnown Screen");
          break;
      }
    }
    [Then(@"I have saved and submitted performance claim tabs")]
    public void ThenIHaveSavedAndSubmittedPerformanceClaimTabs()
    {
      TaskHelper.ExecuteTask(() =>
      {
        //new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ReportLivePerformanceButton2);
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SavedTab);
      Assert.IsTrue(_livePerformanceSelectors.SavedTab.Displayed);
      Assert.IsTrue(_livePerformanceSelectors.SubmittedTab.Displayed);
      });
    }
    
  }
}
