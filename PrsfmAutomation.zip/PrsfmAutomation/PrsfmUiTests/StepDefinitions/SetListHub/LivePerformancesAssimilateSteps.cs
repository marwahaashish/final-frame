﻿using System;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors.SetlistHub;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using NUnit.Framework;
using System.Threading;
using System.Collections.Generic;

namespace PrsfmUiTests.StepDefinitions.SetListHub
{
  [Binding]
  public sealed class LivePerformancesAssimilateSteps 
  {
    private readonly IWebDriver _driver;
    private readonly LivePerformanceSelectors _livePerformanceSelectors;
    private string[] _saveResults;
    //private string PopulatedVenueName;


    public LivePerformancesAssimilateSteps(IWebDriver driver)
    {
      _driver = driver;

      _livePerformanceSelectors = new LivePerformanceSelectors(driver);
      PageFactory.InitElements(_driver, _livePerformanceSelectors);

    }

    [Then(@"Select a assimilate International territory")]
    public void ThenSelectAAssimilateInternationalTerritory(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.CountrySearch);
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.CountrySearch);
        _livePerformanceSelectors.CountrySearch.SendKeys((string)formData.Country);
        _livePerformanceSelectors.AssimilateVenueSearch.SendKeys(Keys.Tab);
        _livePerformanceSelectors.WhiteSpace.Click();
      });
    }
    [When(@"I confirm Ok")]
    public void WhenIConfirmOk()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.OkBtn);

      });
    }   
    [Then(@"I should have saved performances tab")]
    public void ThenIShouldHaveSavedPerformancesTab()
    {
  
     if (_livePerformanceSelectors.SavedPerformanceWork != null)
      {
        Assert.IsTrue(_livePerformanceSelectors.SavedPerformanceWork.Displayed);
      }
      else
      {
        Assert.Fail();
      }
    }

    [Then(@"Validate assimilate message shown")]
    public void ThenValidateAssimilateMessageShown(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();

      switch ((string)formData.Text)
      {
        case "We require additional validation where members report a performance which is more than seven years old. Please":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Greater7YrsMsg);
            Assert.IsTrue(_livePerformanceSelectors.Greater7YrsMsg.Text.Contains((string)formData.Text));
          });
          break;

        case "International performances must have occurred in the past two years in order to be valid":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Greater2YrsMsg);
            Assert.IsTrue(_livePerformanceSelectors.Greater2YrsMsg.Text.Contains((string)formData.Text));
          });
          break;

        case "Your performance at this venue must have occurred in the past year in order to be valid.":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Equal1YrMsg);
            Assert.IsTrue(_livePerformanceSelectors.Equal1YrMsg.Text.Contains((string)formData.Text));
          });
          break;

        case "Please select valid country":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.InvaldCountry);
            Assert.IsTrue(_livePerformanceSelectors.InvaldCountry.Text.Contains((string)formData.Text));
          });
          break;
        case "Unfortunately the event date you have entered falls outside the US societies performance period claim.":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.LessThan1YearUSCountryValidationMsg);
            Assert.IsTrue(_livePerformanceSelectors.LessThan1YearUSCountryValidationMsg.Text.Contains((string)formData.Text));
          });
          break;
        case "This set list name already exists. Please choose a new name. This will help you find it later when adding existing set lists":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SetListNameAlreadyExistValidationMsg);
            Assert.IsTrue(_livePerformanceSelectors.SetListNameAlreadyExistValidationMsg.Text.Contains((string)formData.Text));
          });
          break;
        case "You can return to your saved performance claims at any time and change the details before you submit them. You cannot change a claim once it’s been submitted.":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ThankYouConfirmationMsg);
            Assert.IsTrue(_livePerformanceSelectors.ThankYouConfirmationMsg.Text.Contains((string)formData.Text));
          });
          break;

        default:
          Console.WriteLine("*** UNKnown Page Title passed test");
          break;

      }

    }

    [Then(@"Click Report a Live Performance button")]
    public void ThenClickReportALivePerformanceButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ReportLivePerformanceButton2);
        _livePerformanceSelectors.ReportLivePerformanceButton2.Click();
      });
    }

    [Then(@"Select a performance date")]
    public void ThenSelectAPerfromanceDate(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      switch ((string)formData.PerformanceDate)
      {
        case "Gr 7 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusSevenYears);
          });
          break;
        case "less than 4 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusFourYears);            
          });
          break;

        case "Gr 2 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusTwoYears);
          });

          break;

        case "Eq 1 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusOneYear);
          });
          break;

        case "Yesterday":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();
            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.Yesterday);           
          });
          break;

        case "Today":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.Today);            
          });
          break;
        case "less than 7 Years plus 1 day":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusSevenYearsPlusAddDay);           
          });
          break;
        case "less than 7 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusSevenYears);            
          });
          break;
        case "less than 1 Year minus 1 day":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusOneYearMinusOneDay);            
          });
          break;
        case "Today's date plus 1 day ":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.TodayPlusAddDay);            
          });
          break;
        case "less than 2 Years":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusTwoYears);
          });

          break;
        case "less than 1 Year":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusOneYear);           
          });
          break;

        case "MinusOneYear and add FourMonths":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();

            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.MinusOneYearAddFourMonths);            
          });
          break;
        case "Today Minus Ten Days":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();
            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.TodayMinusTenDays);           
          });
          break;
        case "Today Minus Six Months":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();
            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.TodayMinusSixMonths);           
          });
          break;
        case "TodaysDate MinusOneyear AddMonth MinusSixMonths":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
            _livePerformanceSelectors.PerformanceDatePicker.Click();
            _livePerformanceSelectors.PerformanceDatePicker.SendKeys(DatesHelper.TodaysDateMinusOneyearAddMonthMinusSixMonths);           
          });
          break;
        default:
          Console.WriteLine("*** UNKnown date");
          break;
      }
    }

    [Then(@"Click Submit button")]
    public void ThenClickSubmitButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SubmitButton);
        new WebDriverExtensions(_driver).SafeJavaScrollToElement(_livePerformanceSelectors.SubmitButton);
        _livePerformanceSelectors.SubmitButton.Click();
      });
    }

    [Then(@"Select a venue from the Google search")]
    public void ThenSelectAVenueFromTheGoogleSearch(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.GooglevenueSearch);
        _livePerformanceSelectors.GooglevenueSearch.SendKeys((string)formData.Venue);
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.GooglevenueSearch.SendKeys(Keys.Down);
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.GooglevenueSearch.SendKeys(Keys.Return);
      });
    }


    [Then(@"Click the Done button")]
    public void ThenClickTheDoneButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddWorksDoneButton.Click();
      });     
    }

    [Then(@"Select a Performer")]
    public void ThenSelectAPerformer(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformerName);
        _livePerformanceSelectors.PerformerName.SendKeys((string)formData.Performer);

      });
    }

    [When(@"I rename setlist ""(.*)""")]
    public void WhenIRenameSetlist(string ReNameSetList)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.SetListName);

      });
  
      var Randomtest = new WebDriverExtensions(_driver).GenerateRandomstring(20);
      _livePerformanceSelectors.SetListName.SendKeys(Randomtest);


    }
    [Then(@"Validate set list appears in SAVED column")]
    public void ThenValidateSetListAppearsInSAVEDColumn()
    {     
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SavedSetListInsideSavedTab);      
      });
      Assert.IsTrue(_livePerformanceSelectors.SavedSetListInsideSavedTab.Displayed);
    }

    [When(@"enter and search festival name ""(.*)""")]
    public void ThenEnterAndSearchFestivalName(string festivalName)
    {
          
    }

    [Then(@"click on seach button")]
    public void ThenClickOnSeachButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AssimilateSearch);
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AssimilateSearch);
      });
    }

    [Then(@"click on the report a festival performance link")]
    public void ThenClickOnTheReportAFestivalPerformanceLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ReportAFesival);
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.ReportAFesival);       

      });
    }

    [Then(@"click on the report a festival performance\(Overseas\)link")]
    public void ThenClickOnTheReportAFestivalPerformanceOverseasLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ReportAOverseadFesival);
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.ReportAOverseadFesival);

      });
    }


    [Then(@"enter the festival details")]
    public void ThenEnterTheFestivalDetails()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.FestivalName);
        _livePerformanceSelectors.FestivalName.SendKeys("Test Festival" + ' '+ new WebDriverExtensions(_driver).GenerateRandomstring(4)) ;

        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.FestivalStage);
        _livePerformanceSelectors.FestivalStage.SendKeys("Test Stage");

        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Festivalvenue);
        _livePerformanceSelectors.Festivalvenue.SendKeys("Test Venue");      ;

      });
    }


    [Then(@"select the festival name from the search result")]
    public void ThenSelectTheFestivalNameFromTheSearchResult()
    {
      TaskHelper.ExecuteTask(() =>
      {       
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.FestivalList);
        //new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(
        //    By.XPath(_livePerformanceSelectors.HighlightedAssimilateResult((string)formData.Venue))));
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.FestivalList);       
      });
    }

    [Then(@"Enter the stage name ""(.*)""")]
    public void ThenEnterTheStageName(string stageName)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.StageName);
      _livePerformanceSelectors.StageName.SendKeys(stageName);
      new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(
          By.XPath(_livePerformanceSelectors.HighlightedAssimilateResult(stageName))));
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_driver.FindElement(
             By.XPath(_livePerformanceSelectors.HighlightedAssimilateResult(stageName))));
      
      });
    }

    [Then(@"validate the setlist is auto populated")]
    public void ThenValidateTheSetlistIsAutoPopulated()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SetlistPopulated);       
      });      
    }

    [Then(@"Click the Create A New SetList button")]
    public void ThenClickTheCreateANewSetListButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.CreateAnewSetList.Click();
      });
    }

    [Then(@"Enter a new Setlist name")]
    public void ThenEnterANewSetlistName()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.SetListName);
        _livePerformanceSelectors.SetListName.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(20));

      });
    }

    [Then(@"Click the Add Works button")]
    public void ThenClickTheAddWorksButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AddWorksButton);
        _livePerformanceSelectors.AddWorksButton.Click();
      });
    }

    [Then(@"Validate Add Works form is displayed")]
    public void ThenValidateAddWorksFormIsDisplayed()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AddWorksLabel);
        Assert.IsTrue(_livePerformanceSelectors.AddWorksLabel.Displayed);
      });
    }

    [Then(@"select the search results list")]
    public void ThenSelectTheSearchResultsList()
    {    
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.YourWorkFirstSearchResult);
      });
      _livePerformanceSelectors.SafeJavaScriptClick(_livePerformanceSelectors.YourWorkFirstSearchResult);
    }

    [Then(@"Select displayed result")]
    public void ThenSelectDisplayedResult()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SearchResult);
             
      });
      _livePerformanceSelectors.SearchResult.Click();
    }

    [Then(@"Press the add existing setlist link")]
    public void ThenPressTheAddExistingSetlistLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScrollToElement(_livePerformanceSelectors.AddExistingSetList);
        _livePerformanceSelectors.AddExistingSetList.Click();
      });
    }

    [Then(@"Select a exisitng setlist")]
    public void ThenSelectAExisitngSetlist()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SelectExistingSetList);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.SelectExistingSetList);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SelectExistingSetList);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.SelectExistingSetList);
      });
    }

    [Then(@"Click Can't find it link")]
    public void ThenClickCanTFindItLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.CantFindItLink);        
      });
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.CantFindItLink);      
    }

    [Then(@"I validate selected performance date appears in date field")]
    public void ThenIValidateSelectedPerformanceDateAppearsInDateField(Table table)
    {
      Assert.IsTrue(_livePerformanceSelectors.PerformanceDatePicker.Displayed);
    }

    [Then(@"no validation assimilate message shown")]
    public void ThenNoValidationAssimilateMessageShown()
    {
      Assert.IsFalse(_livePerformanceSelectors.LessThan1YearUSCountryValidationMsg.Displayed);
    }

    [Then(@"validation assimilate message displayed")]
    public void ThenNoValidationAssimilateMessageDisplayed()
    {
      Assert.IsTrue(_livePerformanceSelectors.LessThan1YearUSCountryValidationMsg.Displayed);
    }

    [Then(@"Click the Add setlist button")]
    public void ThenClickTheAddSetlistButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddSetListbutton.Click();
      });
    }

    [Then(@"Click final Submit button")]
    public void ThenClickFinalSubmitButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.FinalSubmit);
        _livePerformanceSelectors.FinalSubmit.Click();
      });
    }

    [Then(@"Select a assimilate venue")]
    public void ThenSelectAAssimilateVenue(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AssimilateVenueSearch);

      });
      _livePerformanceSelectors.AssimilateVenueSearch.SendKeys((string)formData.Venue);

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AssimilateSearch);
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AssimilateSearch);
      });

   
      TaskHelper.ExecuteTask(() =>
      {       
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.VenueList);        
        new WebDriverExtensions(_driver).WaitForPresence(_driver.FindElement(
            By.XPath(_livePerformanceSelectors.HighlightedAssimilateResult((string)formData.Venue))));
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_driver.FindElement(
              By.XPath(_livePerformanceSelectors.HighlightedAssimilateResult((string)formData.Venue))));
      });
     
    }
    [Then(@"Select a assimilate venue from list")]
    public void ThenSelectAAssimilateVenueFromList(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.AssimilateVenueSearch);

      });
      _livePerformanceSelectors.AssimilateVenueSearch.SendKeys((string)formData.Venue);

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AssimilateSearch);

      });
     
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PopulatedVenueSearchList);        
      });
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.PopulatedVenueSearchList);
    }

    [Then(@"search and select venue from list")]
    public void ThenSearchAndSelectVenueFromList(Table table)
    {

      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.AssimilateVenueSearch);

      });
      _livePerformanceSelectors.AssimilateVenueSearch.SendKeys((string)formData.Venue);

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScrollToElement(_livePerformanceSelectors.AssimilateSearch);
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AssimilateSearch);

      });
     
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SelectItemListOfVenueName);
      });
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.SelectItemListOfVenueName);
    }

    [Then(@"Ignore search result and click on find it through Google link")]
    public void ThenIgnoreSearchResultAndClickOnFindItThroughGoogleLink()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.GoogleLink);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.GoogleLink);
      });
     
    }
    [Then(@"search for venue name ""(.*)""")]
    public void ThenSearchForVenueName(string VenueName)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AssimilateVenueSearch);
      });

      _livePerformanceSelectors.AssimilateVenueSearch.SendKeys(VenueName);
      _livePerformanceSelectors.AssimilateSearch.Click();
    
    }
    [Then(@"search for venue name ""(.*)"" on new googlevenue search")]
    public void ThenSearchForVenueNameOnNewGooglevenueSearch(string VenueName)
    {
      TaskHelper.ExecuteTask(() =>
      { 
         new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.NewgoogleVenueSearch);
      });
      _livePerformanceSelectors.NewgoogleVenueSearch.SendKeys(VenueName);      
    }


    [Then(@"select venue result")]
    public void ThenSelectVenueResult()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.NewGoogleVenueSearch);
      });
      Thread.Sleep(5000);
      _livePerformanceSelectors.NewGoogleVenueSearch.SendKeys(Keys.ArrowDown);
      Thread.Sleep(5000);
      _livePerformanceSelectors.NewGoogleVenueSearch.SendKeys(Keys.Enter);      
    }

    [Then(@"search for venue ""(.*)"" and select from result list")]
    public void ThenSearchForVenueAndSelectFromResultList(string VenueName)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.GoogleVenueSearchTextBox);
      });

      _livePerformanceSelectors.GoogleVenueSearchTextBox.SendKeys(VenueName);
      Thread.Sleep(5000);
      _livePerformanceSelectors.GoogleVenueSearchTextBox.SendKeys(Keys.ArrowDown);
    
      _livePerformanceSelectors.GoogleVenueSearchTextBox.SendKeys(Keys.Enter);
      Thread.Sleep(5000);
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.GoogleDoneButton);
      });
    }
    [Then(@"search for venue ""(.*)"" in goole venue search")]
    public void ThenSearchForVenueInGooleVenueSearch(string VenueName)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.GoogleVenueSearchTextBox);
      });
      _livePerformanceSelectors.GoogleVenueSearchTextBox.SendKeys(VenueName);
      
    }
    [Then(@"search for venue ""(.*)"" in google venue search and select result")]
    public void ThenSearchForVenueInGooleVenueSearchAndSelectResult(string VenueName)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.NewGoogleVenueSearch);
      });
      _livePerformanceSelectors.SearchAndSelectEventVenue(VenueName);
    }

    [Then(@"ignore result and click still not found link")]
    public void ThenIgnoreResultAndClickStillNotFoundLink()
    {      
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.StillNotFoundLink);
      });
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.StillNotFoundLink);
    }

    [Then(@"enter details manually")]
    public void ThenEnterDetailsManually()
    {
      _livePerformanceSelectors.ModalVenueName.SendKeys("Test Place");
      _livePerformanceSelectors.VenueCityState.SendKeys("Test City");
      _livePerformanceSelectors.VenuePostcode.SendKeys("SW18 4JB");
      _livePerformanceSelectors.GoogleModalDoneButton.Click();
    }
    [Then(@"I validate venuename is populated")]
    public void ThenIValidateVenuenameIsPopulated()
    {    
      Assert.IsTrue(_livePerformanceSelectors.VenueSearch.Text != null); 
     
    }
    [Then(@"I validate postcode is populated")]
    public void ThenIValidatePostcodeIsPopulated()
    {
      Assert.IsTrue(_livePerformanceSelectors.Postcode.Text != null);
    }

    [Then(@"I validate town/city populated")]
    public void ThenIValidateTownCityPopulated()
    {
      Assert.IsTrue(_livePerformanceSelectors.Town.Text != null);
    }
    [Then(@"Validate Selected setlist name")]
    public void ThenValidateSelectedSetlistName()
    {
      Assert.IsTrue(_livePerformanceSelectors.SetListName.Text != null);
    }

    [Then(@"Validate performer name")]
    public void ThenValidatePerformerName()
    {
      Assert.IsTrue(_livePerformanceSelectors.PerformerName.Text != null);
    }

    [When(@"select headliner")]
    public void WhenSelectHeadliner()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.HeadlinerRadioBtn);

      });
    }
    [Then(@"Validate populated performer name")]
    public void ThenValidatePopulatedPerformerName()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.PopulatedTextInPerformerfield);
      });

      Assert.IsTrue(_livePerformanceSelectors.PopulatedTextInPerformerfield.Displayed);

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.PerformerName);
      });
      _livePerformanceSelectors.PerformerName.SendKeys("test");       
    }

    [When(@"I search with text ""(.*)""")]
    public void WhenISearchWithText(string SearchText)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.WorkSearch);
      });
      _livePerformanceSelectors.WorkSearch.SendKeys(SearchText);       
    }

    [When(@"I enter ""(.*)"", ""(.*)"", ""(.*)"" and ""(.*)""")]
    public void WhenIEnterAnd(string Title, string Writer, string RecordingArtistName, string Duration)
    {
      
        TaskHelper.ExecuteTask(() =>
        {       
        _livePerformanceSelectors.WorkTitle.SendKeys(Title);
        _livePerformanceSelectors.WriterTxtBox.SendKeys(Writer);
        _livePerformanceSelectors.ArtistName.SendKeys(RecordingArtistName);
        _livePerformanceSelectors.Duration.SendKeys(Duration);
        });
       
    }

    [When(@"I add work to setlist")]
    public void WhenIAddWorkToSetslist()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AddWorkBtn);
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.DoneBtn);

      });
    }


    [Then(@"Select a assimilate venue not in search list")]
    public void ThenSelectAAssimilateVenueNotInSearchList(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.AssimilateVenueSearch);
        _livePerformanceSelectors.AssimilateVenueSearch.SendKeys((string)formData.Venue);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AssimilateSearch);

      });
      
    }

    [Then(@"Validate assimilate details submitted")]
    public void ThenValidateAssimilateDetailsSubmitted()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.FinalSubmitPageText);
        Assert.IsTrue(_livePerformanceSelectors.FinalSubmitPageText.Text.Contains("Thank you for reporting your performance."));
    
      });
    }
    [When(@"Enter performance reference number")]
    public void WhenEnterPerformanceReferenceNumber()
    {
      
    }
    [When(@"search for Performance number")]
    public void WhenSearchForPerformanceNumber()
    {
      var PerfID = _livePerformanceSelectors.PerformanceIdNum.Text;
      _livePerformanceSelectors.PerformanceId.SendKeys(PerfID);
      _livePerformanceSelectors.AdminConsoleSearch.Click();
    }
    [Then(@"Validate displayed result row")]
    public void ThenValidateDisplayedResultRow()
    {
      Assert.IsTrue(_livePerformanceSelectors.SubmittedPerformanceRecordDetails.Displayed);
    }

    [Then(@"Click assimilate Find more Venues button")]
    public void ThenClickAssimilateFindMoreVenuesButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.FindGoogleVenues);
        
      });
      _livePerformanceSelectors.FindGoogleVenues.Click();
    }

    [Then(@"Click the assimilate Save button")]
    public void ThenClickTheAssimilateSaveButton()
    {
      _saveResults = SaveDetails();
      TaskHelper.ExecuteTask(() =>
      {        
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SaveForLaterButton);
        new WebDriverExtensions(_driver).SafeJavaScrollToElement(_livePerformanceSelectors.SaveForLaterButton);
        _livePerformanceSelectors.SaveForLaterButton.Click();

      });
    }

    private string[] SaveDetails()
    {
      string[] results = new string[3];
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
        var perforrmancedate = _livePerformanceSelectors.PerformanceDatePicker.GetAttribute("value");
        results[0] = perforrmancedate;
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AssimilateVenueSearch);
        var venue = _livePerformanceSelectors.AssimilateVenueSearch.GetAttribute("value");
        results[1] = venue;
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformerName);
        var performer = _livePerformanceSelectors.PerformerName.GetAttribute("value");
        results[2] = performer;
      });

      return results;
    }

    private string SaveDetails(IWebElement element)
    {
      string details = "";
      string[] results = new string[1];
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(element);
        details = element.GetAttribute("value");
      });

      return details;
    }

    [Then(@"Validate assimilate detials saved")]
    public void ThenValidateAssimilateDetialsSaved()
    {
      var date = _saveResults[0].Remove(0, 1);
      Assert.IsTrue(_livePerformanceSelectors.SavedPerformanceDetail(date).Contains(date));

      var place = _saveResults[1];
      Assert.IsTrue(_livePerformanceSelectors.SavedPerformanceDetail(place).Contains(place));

      var who = _saveResults[2];
      Assert.IsTrue(_livePerformanceSelectors.SavedPerformanceDetail(who).Contains(who));
    }

    [Then(@"Select a random venue")]
    public void ThenSelectARandomVenue()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).ControlA(_livePerformanceSelectors.VenueSearch);
        _livePerformanceSelectors.VenueSearch.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(20));
      });
    }
    
    [Then(@"Check Can't find a work\?")]
    public void ThenCheckCanTFindAWork()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.CantFindItText);
        _livePerformanceSelectors.CantFindItText.Click();

      });
    }
    
    [Then(@"Validate the register work page is displayed")]
    public void ThenValidateTheRegisterWorkPageIsDisplayed()
    {

      TaskHelper.ExecuteTask(() =>
      {
        _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);
      });

      TaskHelper.ExecuteTask(() =>
      {
        WindowsHandling.SelectLastHandle("Register or Amend My Music - Home", _driver);
      });

      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.RegisterWorksPageHeader);
        var text = _livePerformanceSelectors.RegisterWorksPageHeader.Text;
        Assert.AreEqual(text, "Register or amend my music");
      });


    }

    [Then(@"Validate the Upload Fiches page is displayed")]
    public void ThenValidateTheUploadFichesPageIsDisplayed()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(20);
      });
      WindowsHandling.SelectLastHandle("Raise a query", _driver);
    }

    [Then(@"Click the assimilate Add Venue details Manually button")]
    public void ThenClickTheAssimilateAddVenueDetailsManuallyButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.AddAssimilateVenueDetailsManually);
        //_livePerformanceSelectors.AddAssimilateVenueDetailsManually.Click();
      });
    }


    [Then(@"populate assimilate venue details")]
    public void ThenPopulateAssimilateVenueDetails()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _saveResults = new string[1];
        _livePerformanceSelectors.AddVenueDetailsManuallyName.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(15));
        _saveResults[0] = SaveDetails(_livePerformanceSelectors.AddVenueDetailsManuallyName);
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyCity.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(8));
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyPostCode.SendKeys("SW16 1ER");
      });
    }
    
    [Then(@"populate venue details max chars")]
    public void ThenPopulateVenueDetailsMaxChars()
    {
      TaskHelper.ExecuteTask(() =>
      {
        _saveResults = new string[1];
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AddVenueDetailsManuallyName);
        _livePerformanceSelectors.AddVenueDetailsManuallyName.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(256));
        _saveResults[0] = SaveDetails(_livePerformanceSelectors.AddVenueDetailsManuallyName);
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyCity.SendKeys(new WebDriverExtensions(_driver).GenerateRandomstring(256));
      });

      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.AddVenueDetailsManuallyPostCode.SendKeys("SW16 1ER");
      });
    }

    [Then(@"Validate assimilate venue details")]
    public void ThenValidateAssimilateVenueDetails()
    {
      var x = _livePerformanceSelectors.AssimilateVenueSearch.GetAttribute("value");
      Assert.IsTrue(_livePerformanceSelectors.AssimilateVenueSearch.GetAttribute("value").Contains(_saveResults[0]));
      Assert.AreEqual(x, _saveResults[0]);
    }

   

    [Then(@"Validate assimilate screen '(.*)' is displayed")]
    public void ThenValidateAssimilateScreenIsDisplayed(string screen)
    {
      switch (screen)
      {
        case
                "SavedPerformace"
                :
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.LivePerformances);
          });
          TaskHelper.ExecuteTask(() =>
          {
            Assert.IsNotNull(WindowsHandling.ReturnWindonwTitle(_driver));
            var tabUrl = WindowsHandling.ReturnWindonwURL(_driver);

            StringAssert.Contains("performances/saved", tabUrl);

          });
          break;

        //case
        //    "Contact Us"
        //    :
        //    TaskHelper.ExecuteTask(() =>
        //    {
        //        var newTab = WindowsHandling.SelectLastHandle("Set List Feedback - Formstack",_driver);
        //        var tabUrl = WindowsHandling.ReturnWindonwURL(newTab);
        //        Assert.IsNotNull(WindowsHandling.ReturnWindonwTitle(newTab));
        //        StringAssert.Contains( "forms/setlist",tabUrl);

        //    });
        //    break;

        case
                "Submitted"
                :
          TaskHelper.ExecuteTask(() =>
          {
            Assert.IsNotNull(WindowsHandling.ReturnWindonwTitle(_driver));
            var tabUrl = WindowsHandling.ReturnWindonwURL(_driver);
            StringAssert.Contains("performances/submitted", tabUrl);

          });
          break;

        default:
          Console.WriteLine("*** UNKnown Screen");
          break;
      }

    }


    [Then(@"Select the assimilate '(.*)' link")]
    public void ThenSelectTheAssimilateLink(string link)
    {
      switch (link)

      {
        case
              "PRS Logo"
              :
          TaskHelper.ExecuteTask(() =>
          {
            _livePerformanceSelectors.AssimilatePRSLogo.Click();

          });
          break;

        case
              "Contact Us"
              :
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.LivePerformances);
            // _livePerformanceSelectors.ContactUs.Click();
          });
          break;


        default:
          Console.WriteLine("*** UNKnown Page Title passed test");
          break;
      }
    }

    [When(@"The assimilate performance datepicker is opened")]
    public void WhenTheAssimilatePerformanceDatepickerIsOpened()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDatePicker);
        _livePerformanceSelectors.PerformanceDatePicker.Click();
      });
    }

    [Then(@"Click Assimilate Report a Live Performance button")]
    public void ThenClickAssimilateReportALivePerformanceButton()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ReportLivePerformanceButton2);
        _livePerformanceSelectors.ReportLivePerformanceButton2.Click();
      });
    }
    [Then(@"I validate PerforamceDateBtnText ""(.*)""")]
    public void ThenIValidatePerforamceDateBtnText(string BtnTxt1)
    {
      StringAssert.AreEqualIgnoringCase(BtnTxt1, _livePerformanceSelectors.GetPerformanceDate());
    }
    [Then(@"I validate SubmittedDateBtnText ""(.*)""")]
    public void ThenIValidateSubmittedDateBtnText(string BtnTxt2)
    {
      StringAssert.AreEqualIgnoringCase(BtnTxt2, _livePerformanceSelectors.GetSubmittedDate());
    }

    [Then(@"I validate DateOfLastChangeBtnText ""(.*)""")]
    public void GivenIValidateDateOfLastChangeBtnText(string BtnTxt2)
    {
      StringAssert.AreEqualIgnoringCase(BtnTxt2, _livePerformanceSelectors.GetDateOfLastChange());
    }

    [Then(@"I validate searchbox Text ""(.*)""")]
    public void GivenIValidateSearchboxText(string SearchBoxText)
    {
      StringAssert.AreEqualIgnoringCase(SearchBoxText, _livePerformanceSelectors.GetSearchTextBoxtext());
    }
    [Then(@"I validate searchbox placeholder text")]
    public void ThenIValidateSearchboxPlaceholderText()
    {
      _livePerformanceSelectors.IsSearchBoxPlaceHolderTextDisplayed();
    }

    [When(@"I click cancel")]
    public void WhenIClickCancel()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.Cancel);
      });
      _livePerformanceSelectors.Cancel.Click();
    }

    [When(@"I click on saved tab")]
    public void WhenIClickOnSavedTab()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SavedTab);      
      });
     // _livePerformanceSelectors.SavedTab.Click();     
    }

    [Then(@"select the performance from the saved tab")]
    public void ThenSelectThePerformanceFromTheSavedTab()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SelectPerformance);
      });      
      _livePerformanceSelectors.SelectPerformance.Click();
    
    }

    [Then(@"Amend the performer name")]
    public void ThenAmendThePerformerName()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformerName);
      });

      var randomName = new WebDriverExtensions(_driver).GenerateRandomstring(6);
      _livePerformanceSelectors.PerformerName.SendKeys(randomName);      
    }


    [When(@"I click Submitted tab")]
    public void WhenIClickSubmittedTab()
    {
      new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SubmittedTab);
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.SubmittedTab);     
    }

    [Then(@"I validate submitted status")]
    public void ThenIValidateSubmittedStatus(Table table)
    {
      dynamic formData = table.CreateDynamicInstance();

      switch ((string)formData.Text)
      {
        case "All":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.AllDDValue);
            Assert.IsTrue(_livePerformanceSelectors.AllDDValue.Text.Contains((string)formData.Text));
          });
          break;

        case "SUBMITTED":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SubmitttedDDValue);
            Assert.IsTrue(_livePerformanceSelectors.SubmitttedDDValue.Text.Contains((string)formData.Text));
          });
          break;

        case "PROCESSING":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ProcessingDDValue);
            Assert.IsTrue(_livePerformanceSelectors.ProcessingDDValue.Text.Contains((string)formData.Text));
          });
          break;

        case "REJECTED":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.REJECTEDDDValue);
            Assert.IsTrue(_livePerformanceSelectors.REJECTEDDDValue.Text.Contains((string)formData.Text));
          });
          break;

        case "SENT FOR PAYMENT":
          TaskHelper.ExecuteTask(() =>
          {
            new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SENTFORPAYMENTDDValue);
            Assert.IsTrue(_livePerformanceSelectors.SENTFORPAYMENTDDValue.Text.Contains((string)formData.Text));
          });
          break;
        default:
          Console.WriteLine("*** UNKnown Page Title passed test");
          break;

      }
    }
    [Then(@"I validate submitted status dropdown values ""(.*)"", ""(.*)"", ""(.*)"", ""(.*)"", ""(.*)""")]
    public void ThenIValidateSubmittedStatusDropdownValues(string DDValue1, string DDValue2, string DDValue3, string DDValue4, string DDValue5)
    {
      StringAssert.AreEqualIgnoringCase(DDValue1, _livePerformanceSelectors.GetAllDDvalue());
      StringAssert.AreEqualIgnoringCase(DDValue2, _livePerformanceSelectors.GetSubmittedDDvalue());
      StringAssert.AreEqualIgnoringCase(DDValue3, _livePerformanceSelectors.GetProcessingDDvalue());
      StringAssert.AreEqualIgnoringCase(DDValue4, _livePerformanceSelectors.GetRejectedDDvalue());
      StringAssert.AreEqualIgnoringCase(DDValue5, _livePerformanceSelectors.GetSENTFORPAYMENTForDDvalue());
    }
    [When(@"I sort performance date arrow pointing up")]
    [When(@"I sort performance date arrow pointing down")]
    public void WhenISortPerformanceDateArrowPointingDown()
    {
      new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDateBtn);
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.PerformanceDateBtn);
      
    }
    [Then(@"I should validate displayed claims lists is ordered by LATEST DATE FIRST")]
    public void ThenIShouldValidateDisplayedClaimsListsIsOrderedByLATESTDATEFIRST()
    {
      var ItemListDate = DatesHelper.TodayWithMonth;
      var ItemListDisplayedFirstResults = _livePerformanceSelectors.ItemListCalenderDate.Text;
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ItemListCalenderDate);
        if(ItemListDisplayedFirstResults != null)
        {
        Assert.IsTrue(_livePerformanceSelectors.ItemListCalenderDate.Displayed);
        }
        else
        {
          Assert.Fail();
        }
      
      });
    
  }
 
    [Then(@"I should validate displayed claims lists is ordered by OLDEST DATE FIRST")]
    public void ThenIShouldValidateDisplayedClaimsListsIsOrderedByOLDESTDATEFIRST()
    {
      Assert.False(_livePerformanceSelectors.ItemListCalenderDate.Text.Contains(DatesHelper.Today));
      //var ItemListDisplayedFirstResults = _livePerformanceSelectors.ItemListCalenderDate.Text;
      //TaskHelper.ExecuteTask(() =>
      //{
        
      //  new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ItemListCalenderDate);
      //  Assert.IsFalse(_livePerformanceSelectors.ItemListCalenderDate.Text.Contains(DatesHelper.TodayWithMonth));

      //});
    }
    [When(@"I sort dateoflastchange is pointing up")]
    [When(@"I sort dateoflastchange is pointing down")]
    public void WhenISortDateoflastchangeIsPointingDown()
    {
      new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.DateOfLastChangeBtn);
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.DateOfLastChangeBtn);    
    }

    [When(@"I search in saved tab ""(.*)""")]
    public void WhenISearchInSavedTab(string SearchText)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchText);
    }
    [When(@"I sort submitted date is pointing up")]
    [When(@"I sort submitted date is pointing down")]
    public void WhenISortSubmittedDateIsPointingDown()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SubmittedDate);        
      });

      _livePerformanceSelectors.SubmittedDate.Click();
      
    }
    [When(@"I click status dropdown")]
    public void WhenIClickStatusDropdown()
    {
      _livePerformanceSelectors.StatusDropdown.Click();
    }
    [When(@"performance date selected and search with text ""(.*)""")]
    public void WhenPerformanceDateSelectedAndSearchWithText(string SearchTerm1)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm1);

    }

    [Then(@"validate displayed performance claims")]
    public void ThenValidateDisplayedPerformanceClaims()
    { 
      var searchTerm = _livePerformanceSelectors.PerformerNameSearchTerm.Text;
      Assert.IsTrue(_livePerformanceSelectors.SearchList.Text.Contains(searchTerm));
     
    }
    [Then(@"validate displayed performance three claims")]
    public void ThenValidateDisplayedPerformanceThreeClaims()
    {
      Thread.Sleep(5000);
      Assert.IsTrue(_livePerformanceSelectors.SinglePerformanceClaim.Displayed);
      Assert.IsTrue(_livePerformanceSelectors.SecondPerformanceClaim.Displayed);
      Assert.IsTrue(_livePerformanceSelectors.ThirdPerformanceClaim.Displayed);
    }

    [When(@"click submitted tab and performance date")]
    public void WhenClickSubmittedTabAndPerformanceDate()
    {
      new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SubmittedTab);
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.SubmittedTab);
      //_livePerformanceSelectors.SubmittedTab.Click();      
      new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.PerformanceDateBtn);
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.PerformanceDateBtn);
      //_livePerformanceSelectors.PerformanceDateBtn.Click();      
    }

    [When(@"performance date selected and search with date ""(.*)""")]
    public void WhenPerformanceDateSelectedAndSearchWithDate(string SearchWithDate)
    {    
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchWithDate);
    }
    [Then(@"validate displayed single performance claim")]
    [Then(@"validate displayed a single claim should remain for a performance on entered searchdate")]
    public void ThenValidateDisplayedASingleClaimShouldRemainForAPerformanceOnEnteredSearchdate()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SinglePerformanceClaim);
        Assert.IsTrue(_livePerformanceSelectors.SinglePerformanceClaim.Displayed);
      });
     
    }

    [When(@"performance date selected and search with another text ""(.*)""")]
    public void WhenPerformanceDateSelectedAndSearchWithAnotherText(string SearchTerm2)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm2);
      
    }
    [Then(@"validate returned two performance claims")]
    [Then(@"validate displayed two claims should remain for London performances")]
    public void ThenValidateDisplayedTwoClaimsShouldRemainForLondonPerformances()
    {
      Thread.Sleep(5000);
        if (_livePerformanceSelectors.SearchList != null)
          Assert.IsTrue(_livePerformanceSelectors.SinglePerformanceClaim.Displayed && _livePerformanceSelectors.SecondPerformanceClaim.Displayed);
        else
          Assert.Fail();
     
    }

    [When(@"performance date selected and search with invalid search term""(.*)""")]
    public void WhenPerformanceDateSelectedAndSearchWithInvalidSearchTerm(string SearchTerm)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm);
     
    }

    [Then(@"validate no claims should be returned")]
    public void ThenValidateNoClaimsShouldBeReturned()
    {
      Assert.IsTrue(_livePerformanceSelectors.ValidationMsgForNoResults.Displayed);  
    }

    [When(@"performance date selected and search with invalid date""(.*)""")]
    public void WhenPerformanceDateSelectedAndSearchWithInvalidDate(string SearchWithDate)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchWithDate);
     
    }

    [When(@"performance date selected and search with another valid search term""(.*)""")]
    public void WhenPerformanceDateSelectedAndSearchWithAnotherValidSearchTerm(string SearchTerm2)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm2);
     
    }

    [When(@"DateOflastchange selected and search with text ""(.*)""")]
    public void WhenDateOflastchangeSelectedAndSearchWithText(string SearchTerm)
    {
      new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.DateOfLastChangeBtn);
      new WebDriverExtensions(_driver).SafeJavaScriptClick(_livePerformanceSelectors.DateOfLastChangeBtn);
     // _livePerformanceSelectors.DateOfLastChangeBtn.Click();
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm);
     
    }
    [When(@"DateOflastchange selected and search with date ""(.*)""")]
    public void WhenDateOflastchangeSelectedAndSearchWithDate(string SearchWithDate)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchWithDate);
    
    }
    [When(@"DateOflastchange selected down and search with another text ""(.*)""")]
    public void WhenDateOflastchangeSelectedDownAndSearchWithAnotherText(string SearchTerm2)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm2);
    }

    [When(@"DateOflastchange selected and search with invalid text ""(.*)""")]
    public void WhenDateOflastchangeSelectedAndSearchWithInvalidText(string SearchTerm)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm);
    }      

    [When(@"DateOflastchange selected and search with invalid format date ""(.*)""")]
    public void WhenDateOflastchangeSelectedAndSearchWithInvalidFormatDate(string SearchWithDate)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchWithDate);
      
    }
    [When(@"performance date selected and search with Refno ""(.*)""")]
    public void WhenPerformanceDateSelectedAndSearchWithRefno(string SearchTermRefNo)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTermRefNo);
    }
    [Then(@"validate no claims submitted should be returned")]
    public void ThenValidateNoClaimsSubmittedShouldBeReturned()
    {
      Assert.IsTrue(_livePerformanceSelectors.NoResultsValidationMsgforSubmitted.Displayed);
    }
    [When(@"Submitted date selected and search with Refno ""(.*)""")]
    public void WhenSubmittedDateSelectedAndSearchWithRefno(string SearchTermRefNo)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTermRefNo);
    }

    [When(@"Submitted date selected and search with text ""(.*)""")]
    public void WhenSubmittedDateSelectedAndSearchWithText(string SearchTerm1)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm1);
    }

    [When(@"Submitted date selected and search with date ""(.*)""")]
    public void WhenSubmittedDateSelectedAndSearchWithDate(string SearchWithDate)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchWithDate);
    }

    [Then(@"validate displayed two perfromace claims")]
    public void ThenValidateDisplayedTwoPerfromaceClaims()
    {
      Thread.Sleep(5000);
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SearchList);
        if (_livePerformanceSelectors.SearchList != null)
          Assert.IsTrue(_livePerformanceSelectors.SinglePerformanceClaim.Displayed && _livePerformanceSelectors.SecondPerformanceClaim.Displayed);
        else
          Assert.IsNull(_livePerformanceSelectors.SearchList);
      });
    }


    [When(@"Submitted selected and search with another text ""(.*)""")]
    public void WhenSubmittedSelectedAndSearchWithAnotherText(string SearchTerm2)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm2);

    }
    [When(@"Submitted tab selected with performance date and search ""(.*)"" in search field and select status dropdown ""(.*)""")]
    public void WhenSubmittedTabSelectedWithPerformanceDateAndSearchInSearchFieldAndSelectStatusDropdown(string SearchTerm1, string DropDownvalue1)
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.SubmittedTab.Click();
        _livePerformanceSelectors.PerformanceDateBtn.Click();
        //_livePerformanceSelectors.SafeJavaScrollToElement(_livePerformanceSelectors.SearchInputWithText);
        _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
        _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm1);
        _livePerformanceSelectors.SelectSubmitted(DropDownvalue1);
      });
     
    }
    [When(@"Submitted tab selected with submitted date and search ""(.*)"" in search field and select status dropdown ""(.*)""")]
    public void WhenSubmittedTabSelectedWithSubmittedDateAndSearchInSearchFieldAndSelectStatusDropdown(string SearchTerm1, string DropDownvalue1)
    {
      TaskHelper.ExecuteTask(() =>
      {
        _livePerformanceSelectors.SubmittedTab.Click();
        _livePerformanceSelectors.SubmittedDate.Click();        
        _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm1);
        _livePerformanceSelectors.SelectSubmitted(DropDownvalue1);
      });

    }

    [When(@"search ""(.*)"" in search field and select status value as processing ""(.*)""")]
    public void WhenSearchInSearchFieldAndSelectStatusValueAsProcessing(string SearchTerm2, string DropDownvalue2)
    {
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm2);
      _livePerformanceSelectors.SelectProcessing(DropDownvalue2);
      
    }
    [When(@"search ""(.*)"" in search field and select status value as rejected ""(.*)""")]
    public void WhenSearchInSearchFieldAndSelectStatusValueAsRejected(string SearchTerm3, string DropDownvalue3)
    {      
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm3);
      _livePerformanceSelectors.SelectRejected(DropDownvalue3);     
    }
    [When(@"search ""(.*)"" in search field and select status value as sentforpayment ""(.*)""")]
    public void WhenSearchInSearchFieldAndSelectStatusValueAsSentforpayment(string SearchTerm4, string DropDownvalue4)
    {      
      _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");         
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm4);
      _livePerformanceSelectors.SelectSentForPayment(DropDownvalue4);      
    }

    [When(@"search ""(.*)"" in search field and select status dropdown ""(.*)""")]
    public void WhenSearchInSearchFieldAndSelectStatusDropdown(string SearchTerm1, string DropDownvalue1)
    {

      // _livePerformanceSelectors.SearchInputWithText.SendKeys(Keys.Control + "a");
      _livePerformanceSelectors.SearchInputWithText.Clear();
      _livePerformanceSelectors.SearchInputWithText.SendKeys(SearchTerm1);
        _livePerformanceSelectors.SelectSubmitted(DropDownvalue1);
      
    }


    [Then(@"Validate a single claim should remain for a performance on (.*) April (.*)")]
    [Then(@"Validate a single claim should remain for a performance on (.*) Mar (.*)")]
    [Then(@"Validate a single claim should remain for a performance on (.*) Jul (.*)")]
    [Then(@"Validate a single claim should remain for a performance on (.*) Jun (.*)")]
    [Then(@"Validate a single claim should remain for a performance on (.*) May (.*)")]
    [Then(@"Validate a single claim should remain for a performance on (.*) Aug (.*)")]
    [Then(@"Validate a single claim should remain for a performance on (.*) Sep (.*)")]
    public void ThenValidateASingleClaimShouldRemainForAPerformanceOnAug(int p0, int p1)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SearchList);
        if (_livePerformanceSelectors.SearchList != null)
          Assert.IsTrue(_livePerformanceSelectors.SinglePerformanceClaim.Displayed);
        else
          Assert.Fail();
      });
    }
    [Then(@"Validate a two claims should remain for a performance on (.*) May (.*)")]
    public void ThenValidateATwoClaimsShouldRemainForAPerformanceOnMay(int p0, int p1)
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SearchList);
          Assert.IsTrue(_livePerformanceSelectors.SinglePerformanceClaim.Displayed);
         Assert.IsTrue(_livePerformanceSelectors.SecondPerformanceClaim.Displayed);

      });
    }
    [When(@"Navigate to adminconsole")]
    public void WhenNavigateToAdminconsole()
    {
      _driver.Navigate().GoToUrl("https://app-setlistadminqa/#/");
    }

    [Then(@"I have saved and submitted performance claim tabs")]
    public void ThenIHaveSavedAndSubmittedPerformanceClaimTabs()
    {
      TaskHelper.ExecuteTask(() =>
      {
        //new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.ReportLivePerformanceButton2);
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SavedTab);
        Assert.IsTrue(_livePerformanceSelectors.SavedTab.Displayed);
        Assert.IsTrue(_livePerformanceSelectors.SubmittedTab.Displayed);
      });
    }

    [Then(@"I validate setlist name date@Venue")]
    public void ThenIValidateSetlistNameDateVenue()
    {
      Thread.Sleep(4000);
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(_livePerformanceSelectors.SetListName);
        var SetListPopulatedName = _livePerformanceSelectors.SetListName.Text;
        var VenueNamePopulated = _livePerformanceSelectors.VenueSearch.Text;
        Assert.IsTrue(_livePerformanceSelectors.SetListName.Text.Contains(VenueNamePopulated));
        Console.WriteLine(SetListPopulatedName);
      });

    }

    [Then(@"click and add existing setlist link")]
    public void ThenClickAndAddExistingSetlistLink()
    {
      Thread.Sleep(5000);
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).SafeJavaScrollToElement(_livePerformanceSelectors.AddExistingSetListBtn);
        _livePerformanceSelectors.AddExistingSetListBtn.Click();
      });
    }


  }
}


