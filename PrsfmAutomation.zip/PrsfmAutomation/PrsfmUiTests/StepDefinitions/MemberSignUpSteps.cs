﻿using System;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using PrsfmUiTests.Selectors;
using System.Threading;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace PrsfmUiTests.StepDefinitions
{
  public class InjectionData
    {
        public Guid Id { get; set; }
    }

    [Binding]
    public class MemberSignUpSteps
    {
        private readonly IWebDriver _driver;

        private readonly MemberSignUpSelectors _memberSignUpSelectors;

        public readonly string uniqueData = DatesHelper.ParseDate(DatesHelper.DateTimeRightNow);
        public readonly string uniqueEmailAddress;

        public MemberSignUpSteps(IWebDriver driver, InjectionData data)
        {
            _driver = driver;

            this.uniqueEmailAddress = uniqueData + "@mailinator.com";

            _memberSignUpSelectors = new MemberSignUpSelectors();
            PageFactory.InitElements(_driver, _memberSignUpSelectors);
        }

   


        [When(@"Complete member sign up for member Account")]
        public void WhenCompleteMemberSignUpForPrimary(Table table)
        {
            dynamic formData = table.CreateDynamicInstance();

            TaskHelper.ExecuteTask(() => new Helpers.WebDriverExtensions(_driver).WaitForPresence(_memberSignUpSelectors.MembershipNumber));

            _memberSignUpSelectors.MembershipNumber.SendKeys((string)formData.MembershipNumber.ToString());
            _memberSignUpSelectors.FirstName.SendKeys((string)formData.FirstName);
            _memberSignUpSelectors.LastName.SendKeys((string)formData.LastName);

            switch ((string)formData.EmailAddress)
            {
              case "UniqueTimeStamp":
                _memberSignUpSelectors.EmailAddress.SendKeys(uniqueEmailAddress);
                break;
              case "None":
                Console.WriteLine("Note... no details required");
                break;
            }
           
            _memberSignUpSelectors.MemberName.SendKeys((string)formData.MemberName);
         

            switch ((string)formData.MemberRole)
            {
                case "Writer":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new Helpers.WebDriverExtensions(_driver).WaitForPresence(_memberSignUpSelectors.MemberRoleWriter);
                        new Helpers.WebDriverExtensions(_driver).JavaScriptClick(_memberSignUpSelectors.MemberRoleWriter);
                    });
                    break;

                case "Publisher":
                    TaskHelper.ExecuteTask(() =>
                    {
                        new Helpers.WebDriverExtensions(_driver).WaitForPresence(_memberSignUpSelectors.MemberRolePublisher);                       
                        new Helpers.WebDriverExtensions(_driver).JavaScriptClick(_memberSignUpSelectors.MemberRolePublisher);
                    });
                    break;
            }

            if ((string)formData.AreyouMember != string.Empty)
            {
              switch ((string)formData.AreyouMember)
              {
                case "Yes":
                  TaskHelper.ExecuteTask(() =>
                  {
                    new Helpers.WebDriverExtensions(_driver).WaitForPresence(_memberSignUpSelectors.RadioButtonAreYouMemberYes);
                    new Helpers.WebDriverExtensions(_driver).JavaScriptClick(_memberSignUpSelectors.RadioButtonAreYouMemberYes);
                  });
                  break;
                case "No":
                  TaskHelper.ExecuteTask(() =>
                  {
                    new Helpers.WebDriverExtensions(_driver).WaitForPresence(_memberSignUpSelectors.RadioButtonAreYouMemberNo);
                    new Helpers.WebDriverExtensions(_driver).JavaScriptClick(_memberSignUpSelectors.RadioButtonAreYouMemberNo);
                  
                  });
                  break;
              }
            }
            if ((string)formData.JobDescription != string.Empty)
            {
              _memberSignUpSelectors.JobDescription.SendKeys((string)formData.JobDescription);
            }

            TaskHelper.ExecuteTask(() =>
            {
              new Helpers.WebDriverExtensions(_driver).WaitForPresence(_memberSignUpSelectors.IdentityCheck);
              _memberSignUpSelectors.IdentityCheck.SendKeys((string)formData.IdentityCheck.ToString());
            });

            Thread.Sleep(2000);

        }

        [Then(@"Click sign up page submit")]
        public void ThenClickSignUpPageSubmit()
        {
          
            TaskHelper.ExecuteTask(() =>
            {
                new Helpers.WebDriverExtensions(_driver).WaitForPresence(_memberSignUpSelectors.Submit);
               // ((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].click();", _memberSignUpSelectors.Submit);
                 new Helpers.WebDriverExtensions(_driver).SafeJavaScriptClick(_memberSignUpSelectors.Submit);  
                 Thread.Sleep(5000);
            });

            TaskHelper.ExecuteTask(() =>
            {
              new Helpers.WebDriverExtensions(_driver).WaitForPresence(_memberSignUpSelectors.SignUpComplete);

            });


    }
    }
}
