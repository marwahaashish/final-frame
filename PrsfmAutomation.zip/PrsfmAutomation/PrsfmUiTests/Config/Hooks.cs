﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Configuration;
using BoDi;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Remote;

namespace PrsfmUiTests.Config
{
    public class CustomRemoteWebDriver : RemoteWebDriver
    {
        public CustomRemoteWebDriver(Uri remoteAddress, ICapabilities desiredCapabilities)
               : base(remoteAddress, desiredCapabilities)
        {
        }

        public string getSessionID()
        { 
            return base.SessionId.ToString();
        }
    }


    [Binding]
    public class Hooks
    {
    private readonly IObjectContainer _objectContainer;

    public Hooks(IObjectContainer objectContainer)
    {
      _objectContainer = objectContainer;
    }

    public const int ExplicitWaitSeconds = 10;
    public const int PollingIntervalMilliseconds = 2000;


    readonly string _whichRunPlatform = ConfigurationManager.AppSettings.Get("RunPlatform");
    readonly string _isDesktopBrowser = ConfigurationManager.AppSettings.Get("IsDesktopBrowser");

    [BeforeScenario]
    public void Initialise()
    {
      switch (_whichRunPlatform)
      {
        case "IE":
          InternetExplorerOptions options1 = new InternetExplorerOptions();
          options1.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
          options1.EnsureCleanSession = true;
          options1.ElementScrollBehavior = InternetExplorerElementScrollBehavior.Bottom;
          //DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
          IWebDriver _driverIe = new InternetExplorerDriver(options1);
          _objectContainer.RegisterInstanceAs<IWebDriver>(_driverIe);
          _driverIe.Manage().Window.Maximize();
          break;

        case "Chrome":
          ChromeOptions options = new ChromeOptions();
          options.AddAdditionalCapability("useAutomationExtension", false);
          options.AddArgument("--start-maximized");

          IWebDriver _driverChrome = new ChromeDriver(options);
          _objectContainer.RegisterInstanceAs<IWebDriver>(_driverChrome);
          break;

        case "BrowserStack":
          CustomRemoteWebDriver _driverBs;


          DesiredCapabilities capability = new DesiredCapabilities();
          capability.SetCapability("acceptSslCerts", "true");

          capability.SetCapability("browserstack.local", "true");
          var browserstackLocalIdentifier = Environment.GetEnvironmentVariable("BROWSERSTACK_LOCAL_IDENTIFIER");
          capability.SetCapability("browserstack.localIdentifier", browserstackLocalIdentifier);
          capability.SetCapability("acceptSslCerts", "true");


          capability.SetCapability("browserstack.user", (ConfigurationManager.AppSettings.Get("BrowserStackUser")));
          capability.SetCapability("browserstack.key", (ConfigurationManager.AppSettings.Get("BrowserStackKey")));
          capability.SetCapability("browserstack.debug", (ConfigurationManager.AppSettings.Get("BrowserStackDebug")));
          capability.SetCapability("browserstack.selenium_version", "3.9.1");


          if (_isDesktopBrowser == "true")
          {
            // Desktop Browser 
            capability.SetCapability("browser_version", (ConfigurationManager.AppSettings.Get("BrowserVersion")));
            capability.SetCapability("browser", (ConfigurationManager.AppSettings.Get("BrowserType")));         
            capability.SetCapability("os", (ConfigurationManager.AppSettings.Get("OsType")));
            capability.SetCapability("os_version", (ConfigurationManager.AppSettings.Get("OsVersion")));
            capability.SetCapability("resolution", (ConfigurationManager.AppSettings.Get("OsResolution")));
          }
          else if (_isDesktopBrowser == "false")
          {
            // Mobile Browser 
            capability.SetCapability("os_version", "11");
            capability.SetCapability("device", "iPhone 8 Plus");
            capability.SetCapability("real_mobile", "true");
            capability.SetCapability("browserstack.local", "true");
            capability.SetCapability("browserstack.appium_version", "1.6.5");
            capability.SetCapability("browserstack.user", "brendanmeade1");
            capability.SetCapability("browserstack.key", "26uh8H6f89ySERBzqn7q");

            //capability.SetCapability("browserName", (ConfigurationManager.AppSettings.Get("BrowserName")));
            //capability.SetCapability("platform", (ConfigurationManager.AppSettings.Get("Platform")));
            //capability.SetCapability("device", (ConfigurationManager.AppSettings.Get("Device")));
          }
          else
          {
            Console.WriteLine("*** Browser type not set in App Config");
          }

          _driverBs = new CustomRemoteWebDriver(new Uri(ConfigurationManager.AppSettings.Get("BrowserStackUrl")), capability);
          _objectContainer.RegisterInstanceAs<IWebDriver>(_driverBs);

          // Platform Select
          string sessionId = _driverBs.getSessionID();
          Console.WriteLine("BROWSERSTACK SESSION ID: " + sessionId);

          // Get Session Id
          if (_isDesktopBrowser == "true")
            _driverBs.Manage().Window.Maximize();

          break;

        default:
          Console.WriteLine("*** UNKnown Run Platform entered");
          break;
      }
    }


    [AfterScenario]
    public void CleanUp(IWebDriver _driver)
    {
      if (_driver != null)
      {
        _driver.Quit();
      }
    }
  }
}
