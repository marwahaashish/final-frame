﻿using System;

namespace PrsfmUiTests.Helpers
{
    public class DatesHelper
    {
        public static string TodayDay = DateTime.Now.ToString("dd");
        public static string ThisMonth = DateTime.Now.ToString("MMMM");
        public static string Today = DateTime.Now.ToUniversalTime().ToString("dd/MM/yyyy");
        public static string Tomorrow = DateTime.Now.AddDays(1).ToString("dd/MM/yyyy");
        public static string TwoWeeksInFuture = DateTime.Now.AddDays(14).ToString("dd/MM/yyyy");
        public static string FourWeeksInFuture = DateTime.Now.AddDays(28).ToString("dd/MM/yyyy");
        public static string YesterdayDay = DateTime.Now.AddDays(-1).ToString("dd");
        public static string YesterdayMonth = DateTime.Now.AddDays(-1).ToString("MM");
        public static string YesterdayYear = DateTime.Now.AddDays(-1).ToString("yyyy");
        public static string Yesterday = DateTime.Now.AddDays(-1).ToString("dd/MM/yyyy");
        public static string YesterdayUsingFullMonthName = DateTime.Now.AddDays(-1).ToString("dd MMMM yyyy");
        public static string TodayUsingFullMonthName = DateTime.Now.ToString("dd MMMM yyyy");
        public static string SevenWeeksPrevious = DateTime.Now.AddDays(-49).ToString("dd/MM/yyyy");
        public static string SevenYearsPrevious = DateTime.Now.AddYears(-7).ToString("dd/MM/yyyy");
        public static string TomorrowDay = DateTime.Now.AddDays(+1).ToString("dd");
        public static string YesterdayYearMonthDay = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");
        public static string TodayYearMonthDay = DateTime.Now.ToString("yyyy-MM-dd");
        public static string TomorrowYearMonthDay = DateTime.Now.AddDays(1).ToString("yyyy-MM-dd");
        public static string FourMonthsPrevious = DateTime.Now.AddMonths(-4).ToString("yyyy,MM,dd");
        public static string FourMonthsPreviousMainScreen = DateTime.Now.AddMonths(-4).ToString("dd/MM/yyyy");
        public static string LastYear = DateTime.Now.AddYears(-1).ToString("yyyy");
        public static string DateTimeRightNow = DateTime.Now.ToUniversalTime().ToString("yyyyMMdd-HHmmss");
        public static string DayMonthYesterdayYear = DateTime.Now.AddYears(-1).ToString("dd/MM/yyyy");
        public static string MinusSevenYears = DateTime.Now.AddYears(-7).ToString("dd/MM/yyyy");
        public static string MinusSevenYearsPlusAddDay = DateTime.Now.AddYears(-7).AddDays(1).ToString("dd/MM/yyyy");
        public static string MinusTwoYears = DateTime.Now.AddYears(-2).ToString("dd/MM/yyyy");
        public static string MinusFourYears = DateTime.Now.AddYears(-4).ToString("dd/MM/yyyy");
        public static string MinusOneYear = DateTime.Now.AddYears(-1).ToString("dd/MM/yyyy");
        public static string MinusOneYearMinusOneDay = DateTime.Now.AddYears(-1).AddDays(-1).ToString("dd/MM/yyyy");
        public static string TodayPlusAddDay = DateTime.Now.ToUniversalTime().AddDays(1).ToString("dd/MM/yyyy");
        public static string TodayWithMonth = DateTime.Now.ToString("dd MMM yyyy");
        public static string MinusOneYearAddFourMonths = DateTime.Now.AddYears(-1).AddMonths(4).ToString("dd/MM/yyyy");
        public static string TodayMinusTenDays = DateTime.Now.ToUniversalTime().AddDays(-10).ToString("dd/MM/yyyy");
    public static string TodayMinusSixMonths = DateTime.Now.AddMonths(-6).ToString("dd/MM/yyyy");        
        public static string TodaysDateMinusOneyearAddMonthMinusSixMonths = DateTime.Now.AddYears(-1).AddMonths(1).AddMonths(-6).ToString("dd/MM/yyyy");



    public static string ParseDate(string date)
        {
            switch (date)
            {
                case "TodayDay":
                    return TodayDay;
                case "ThisMonth":
                    return ThisMonth;
                case "Today":
                    return Today;
                case "YesterdayDay":
                    return YesterdayDay;
                case "YesterdayMonth":
                    return YesterdayMonth;
                case "YesterdayYear":
                    return YesterdayYear;
                case "Yesterday":
                    return Yesterday;
                case "Tomorrow":
                    return Tomorrow;
                case "TwoWeeksInFuture":
                    return TwoWeeksInFuture;
                case "FourWeeksInFuture":
                    return FourWeeksInFuture;
                case "YesterdayUsingFullMonthName":
                    return YesterdayUsingFullMonthName;
                case "TodayUsingFullMonthName":
                    return TodayUsingFullMonthName;
                case "SevenWeeksPrevious":
                    return SevenWeeksPrevious;
                case "SevenYearsPrevious":
                    return SevenYearsPrevious;
                case "TomorrowDay":
                    return TomorrowDay;
                case "YesterdayYearMonthDay":
                    return YesterdayYearMonthDay;
                case "TodayYearMonthDay":
                    return TodayYearMonthDay;
                case "TomorrowYearMonthDay":
                    return TomorrowYearMonthDay;
                case "FourMonthsPrevious":
                    return FourMonthsPrevious;
                case "FourMonthsPreviousMainScreen":
                    return FourMonthsPreviousMainScreen;
                case "LastYear":
                    return LastYear;
                case "DateTimeRightNow":
                    return DateTimeRightNow;
                case "DayMonthYesterdayYear":
                    return DayMonthYesterdayYear;
                case "MinusSevenYears":
                    return MinusSevenYears;
                case "MinusTwoYears":
                    return MinusTwoYears;
                case "MinusOneYear":
                    return MinusOneYear;
                case "MinusFourYears":
                    return MinusFourYears;
                case "MinusSevenYearsPlusAddDay":
                   return MinusSevenYearsPlusAddDay;
                case "MinusOneYearMinusOneDay":
                 return MinusOneYearMinusOneDay;
                case "TodayPlusAddDay":
                 return TodayPlusAddDay;
                case "TodayWithMonth":
                return TodayWithMonth;
                case "MinusOneYearAddFourMonths":
                return MinusOneYearAddFourMonths;
                case "TodayMinusTenDays":
               return TodayMinusTenDays;
               case "TodayMinusSixMonths":
              return TodayMinusSixMonths;
              case "TodaysDateMinusOneyearAddMonthMinusSixMonths":
              return TodaysDateMinusOneyearAddMonthMinusSixMonths;
               default:
               return date;
            }
        }
    }
}
