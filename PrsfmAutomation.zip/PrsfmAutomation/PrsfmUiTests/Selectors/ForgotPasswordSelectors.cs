﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors
{
 public class ForgotPasswordSelectors
  {
    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Forgot your password?')]")]
    public IWebElement ForgotPasswordLink { get; set; }    
  }
}
