﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class SummaryFormSelectors
    {
        [FindsBy(How = How.Id, Using = "submit_page")]
        public IWebElement SubmitCompletedForm { get; set; }
    }
}
