﻿using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.MobileApp
{
 internal class SearchResultPage : WebDriverExtensions
  {
    public SearchResultPage(IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "(//a[contains(@href, '#/search')])[2]")]
    public IWebElement PageHeaderLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//p[contains(text(),'(big business + Amfo)')]")]
    public IWebElement PageHeaderWithWorkTitleAndLastName { get; set; }   

    [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Gerrard Kwabena Amfo-twenefo, Devonte Kasi Perkins Martin, Cassiel Nii Akwei Wuta Ofei, Jonathan James Wrate')]")]
    public IWebElement FirstSearchCardHeaderParagraph { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'search-card')]/a)[1]")]
    public IWebElement FirstSearchCardLink { get; set; }

    [FindsBy(How = How.XPath, Using = "(//h5[contains(text(), 'Big Business')])[1]")]
    public IWebElement SearchCardHeader { get; set; }

    [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Big Business')]")]
    public IWebElement TitleofPageHeader { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'More')]")]
    public IWebElement InactiveTab { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Shareholders')]")]
    public IWebElement ActiveTab { get; set; }

    [FindsBy(How = How.XPath, Using = "//u[contains(text(), 'View works')]")]
    public IWebElement ViewWorksLink { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div/span[contains(@class, 'prs-icon shareholder-card--up prs-icon-chevron-down')])[1]")]
    public IWebElement ShareholderFirstCard { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'search-pane--more-info')]//p)[1]")]
    public IWebElement RegisteredTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'search-pane--more-info')]//p)[2]")]
    public IWebElement ISWC { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'search-pane--more-info')]//p)[3]")]
    public IWebElement WorkStatus { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'search-pane--more-info')]//p)[4]")]
    public IWebElement PRSLastDistribution { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'search-pane--more-info')]//p)[5]")]
    public IWebElement MCPSLastDistribution { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'search-pane--more-info')]//p)[6]")]
    public IWebElement WorkAmendmentDate { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'search-pane--more-info')]//p)[7]")]
    public IWebElement WorkCreationDate { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'search-pane--more-info')]//p)[8]")]
    public IWebElement PublisherWorkReferences { get; set; }

    public void ClickFirstSearchCardLink()
    {
      Thread.Sleep(2000);
      ExecuteTask(() =>
     {
       WaitForPresence(FirstSearchCardLink);
       SafeJavaScrollToElement(FirstSearchCardLink);
       SafeJavaScriptClick(FirstSearchCardLink);

      });
    }

    public string GetPageHeaderWorktitleAndLastName()
    {
      WaitForPresence(PageHeaderWithWorkTitleAndLastName);
      return GetElementText(PageHeaderWithWorkTitleAndLastName);
    }

    public string GetFirstSearchCardParagraph()
    {
      return GetElementText(FirstSearchCardHeaderParagraph);
    }

    public string GetSearchCardHeader()
    {
      return GetElementText(SearchCardHeader);
    }
    public string GetSearchResultsPageHeaderLink()
    {
      return GetElementText(PageHeaderLink);
    }
    public string GetWorkTitleAndLastname()
    {
      return GetElementText(PageHeaderWithWorkTitleAndLastName);
    }
    public string GetTitleOfPageHeader()
    {
      return GetElementText(TitleofPageHeader);
    }
    public string GetShareHolderActiveTab()
    {
      WaitForPresence(ActiveTab);
      return GetElementText(ActiveTab);
    }
    public string GetMoreInactiveTab()
    {
      WaitForPresence(InactiveTab );
      return GetElementText(InactiveTab);
    }
    public void ClickFirstShareholderCard()
    {
      Thread.Sleep(3000);
      ExecuteTask(() =>
      {
        WaitForPresence(ShareholderFirstCard);
        SafeJavaScrollToElement(ShareholderFirstCard);
        SafeJavaScriptClick(ShareholderFirstCard);

      });
    }
    public string GetViewWorksLink()
    {
      WaitForPresence(ViewWorksLink);
      SafeJavaScrollToElement(ViewWorksLink);
      return GetElementText(ViewWorksLink);

    }
    public void ClickViewWorks()
    {
      Thread.Sleep(2000);
      ExecuteTask(() =>
      {
        WaitForPresence(ViewWorksLink);
        SafeJavaScrollToElement(ViewWorksLink);
        SafeJavaScriptClick(ViewWorksLink);
        Thread.Sleep(3000);

    
      });
    }
    public void ClickInactiveTab()
    {
      Thread.Sleep(2000);
      ExecuteTask(() =>
      {
        WaitForPresence(InactiveTab);
        SafeJavaScrollToElement(InactiveTab);
        SafeJavaScriptClick(InactiveTab);
        Thread.Sleep(3000);

      });
    }
    public string GetRegisteredTitle()
    {

      WaitForPresence(RegisteredTitle);
      return GetElementText(RegisteredTitle);
      
    }
    public void IsRegisteredTitleMatchesPageHeaderDisplayed()
    {
      Assert.IsTrue(RegisteredTitle.Displayed);

    }
    public void ClickActiveTab()
    {
      Thread.Sleep(2000);
      ExecuteTask(() =>
      {
        WaitForPresence(ActiveTab);
        SafeJavaScrollToElement(ActiveTab);
        SafeJavaScriptClick(ActiveTab);

      });
    }
    public bool IsRegisteredTitleDisplayed()
    {

      if (RegisteredTitle != null)
      {
        Console.WriteLine("Registered title is displayed");
      }
      else
      {
        Console.WriteLine("Registered title doesn't displayed");
      }
      return DoesElementExist(RegisteredTitle);
    }
    public bool IsISWCDisplayed()
    {
      if(ISWC != null)
      {
        Console.WriteLine("ISWC code displayed");
      }
      else
      {
        Console.WriteLine("ISWC code doesn't displayed");
      }

     return DoesElementExist(ISWC);
    }
    public bool IsWorkStatusdDisplayed()
    {
      if (WorkStatus != null)
      {
        Console.WriteLine("WorkStatus displayed");
      }
      else
      {
        Console.WriteLine("WorkStatus doesn't displyed");
      }
      return DoesElementExist(ISWC);
    }
    public bool IsPRSLastDistributionDisplayed()
    {
      if(PRSLastDistribution != null)
      {
        Console.WriteLine("PRSLastDistribution is displayed");
      }
      else
      {
        Console.WriteLine("PRSLastDistribution doesnot displayed");
      }
      return DoesElementExist(PRSLastDistribution);
    }

    public bool IsMCPSDistributionDisplayed()
    {
      if(MCPSLastDistribution != null)
      {
        Console.WriteLine("MCPSLastDistribution is displayed");
      }
      else
      {
        Console.WriteLine("MCPSLastDistribution doesn't displayed");
      }
      return DoesElementExist(MCPSLastDistribution);
    }
    public bool IsWorkAmendmentDateDisplayed()
    {
      if (WorkAmendmentDate != null)
      {
        Console.WriteLine("WorkAmendmentDate is displayed");
      }
      else
      {
        Console.WriteLine("WorkAmendMentDate doesn't displayed");
      }
      return DoesElementExist(WorkAmendmentDate);
    }

    public bool IsWorkCreationDateDisplayed()
    {
      if(WorkAmendmentDate != null)
      {
        Console.WriteLine("Work creation date displayed");
      }
      else
      {
        Console.WriteLine("Work creation date doesn't displayed");
      }
      return DoesElementExist(WorkCreationDate);
    }
    public bool IsPublisherWorkReferenceDisplayed()
    {
      if (PublisherWorkReferences != null)
      {
        Console.WriteLine("PublisherWorkReferences displayed");
      }
      else
      {
        Console.WriteLine("PublisherWorkReferences doesn't displayed");
      }
      return DoesElementExist(WorkCreationDate);
    }
    public bool IsLastNameMatchesWithFirstSearchCardParagraph(string LastName)
    {
      string Lname = FirstSearchCardHeaderParagraph.Text;

      if (FirstSearchCardHeaderParagraph.Displayed)
      {
        StringAssert.Contains(LastName, Lname);
        Console.WriteLine("FirstSearchCardHeaderParagraph----->" + Lname);
      }
      else
      {
        Console.WriteLine("FirstSearchCardHeaderParagraph doesn't match lastname");
      }
        return DoesElementExist(FirstSearchCardHeaderParagraph);
    }
  }
}
