﻿using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.MobileApp
{
  internal class PaymentsPage : WebDriverExtensions
  {
    public PaymentsPage(IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }
    [FindsBy(How = How.XPath, Using = "//h1[contains(text(), 'Payment dates')]")]
    public IWebElement PaymentsPageHeader { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'JAN')]")]
    public IWebElement SelectJanMonth { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Television')]")]
    public IWebElement UsageType { get; set; }

    [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'You should expect payment in the')]")]
    public IWebElement PopulatedPaymentMessage { get; set; }

    [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'You should expect payment in the')]")]
    public IWebElement PaymentResultsMessageWithMonthAfterEdit { get; set; }

    [FindsBy(How = How.XPath, Using = "//p[contains(@class, 'Camber-Md')]")]
    public IWebElement TypeofRoyalty { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'https://www.prsformusic.com/royalties/royalty-payment-dates/overseas-royalty-payments')]")]
    public IWebElement OverSeasFooterLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'https://www.prsformusic.com/distributionupdate')]")]
    public IWebElement LatestFooterLink { get; set; }

    [FindsBy(How = How.XPath, Using = "(//button[contains(@class, 'schedule__answer')])[1]")]
    public IWebElement PopulatedSelectedMonth { get; set; }

    [FindsBy(How = How.XPath, Using = "(//button[contains(@class, 'schedule__answer')])[2]")]
    public IWebElement PopulatedSelectedUsageType { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'AUG')]")]
    public IWebElement SelectAugMonthBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Online')]")]
    public IWebElement SelectOnlineUsageType { get; set; }

    [FindsBy(How = How.XPath, Using = "//p[contains(@class, 'schedule_results--main')]/strong")]
    public IWebElement DistributionMonth { get; set; }

    public string GetPaymentPageHeader()
    {
      Thread.Sleep(2000);
      WaitForPresence(PaymentsPageHeader);
      SafeJavaScrollToElement(PaymentsPageHeader);
      return GetElementText(PaymentsPageHeader);
    }

    public bool IsOverseasLinkExists()
    {
      MoveToElement(OverSeasFooterLink);
      String Footerlink = OverSeasFooterLink.GetAttribute("href");
      if (Footerlink.Equals(OverSeasFooterLink))
      {
        Console.WriteLine("Overseas footer link works---->" + Footerlink);
      }
      else
      {
        Console.WriteLine("Overseas footer link doesn't work");
      }
      return DoesElementExist(OverSeasFooterLink);
    }

    public bool IsLatestinfolinkExists()
    {

      MoveToElement(LatestFooterLink);
      String Footerlink = LatestFooterLink.GetAttribute("href");
      if (Footerlink.Equals(LatestFooterLink))
      {
        Console.WriteLine("Latestinfo link footer works --->" + Footerlink);
      }
      else
      {
        Console.WriteLine("Latestinfo link footer doesn't worK--->" + Footerlink);
      }
      return DoesElementExist(LatestFooterLink);
    }

    public void SelectMonth()
    {
      Thread.Sleep(2000);
      ExecuteTask(() =>
      {

        WaitForPresence(SelectJanMonth);
        SafeJavaScrollToElement(SelectJanMonth);
        SafeJavaScriptClick(SelectJanMonth);
        Thread.Sleep(1000);

      });

    }

    public void SelectUsageType()
    {
      Thread.Sleep(1000);
      ExecuteTask(() =>
      {
        WaitForPresence(UsageType);
        SafeJavaScrollToElement(UsageType);
        SafeJavaScriptClick(UsageType);
        Thread.Sleep(1000);

      });
    }

    public bool IsPaymentMessageDisplayed(string PaymentMsg)
    {
      Thread.Sleep(2000);
      WaitForPresence(PopulatedPaymentMessage);
      string PaymentResultText = "You should expect payment in the";
      string sub = PaymentResultText.Substring(0, 32);
      if (PaymentResultText.Equals(PaymentMsg))
      {
        Console.WriteLine("Substring: {0}", sub);
      }
      else
      {
        Console.WriteLine("Payment message doesn't displayed");
      }
      return DoesElementExist(PopulatedPaymentMessage);
    }

    public string GetSelectedMonth()
    {
      WaitForPresence(PopulatedSelectedMonth);
      return GetElementText(PopulatedSelectedMonth);
    }
    public string GetSelectedUsageType()
    {
      WaitForPresence(PopulatedSelectedUsageType);
      return GetElementText(PopulatedSelectedUsageType);
    }
    public void ClickAugMonthBtn()
    {
      Thread.Sleep(2000);
      ExecuteTask(() =>
      {
        WaitForPresence(PopulatedSelectedMonth);
        SafeJavaScrollToElement(PopulatedSelectedMonth);
        SafeJavaScriptClick(PopulatedSelectedMonth);
        WaitForPresence(SelectAugMonthBtn);
        SafeJavaScrollToElement(SelectAugMonthBtn);
        SafeJavaScriptClick(SelectAugMonthBtn);
        Thread.Sleep(1000);

      });
    }
    public void ClickOnlineUsageBtn()
    {
      Thread.Sleep(2000);
      ExecuteTask(() =>
      {
        WaitForPresence(PopulatedSelectedUsageType);
        SafeJavaScrollToElement(PopulatedSelectedUsageType);
        SafeJavaScriptClick(PopulatedSelectedUsageType);
        WaitForPresence(SelectOnlineUsageType);
        SafeJavaScrollToElement(SelectOnlineUsageType);
        SafeJavaScriptClick(SelectOnlineUsageType);
        Thread.Sleep(1000);

      });
    }

    public string GetDistributionAmount()
    {
      WaitForPresence(DistributionMonth); 
      return GetElementText(DistributionMonth);
    }
    public string GetDistMonth(string DistMonth)
    {
      WaitForPresence(DistributionMonth);
      return GetElementText(DistributionMonth);
    }

    public bool IsTypeOfRoyaltyDisplayed()
    {
      if (TypeofRoyalty != null)
      {

        Console.WriteLine("Type of royalty displayed ");

      }
      else
      {
        Console.WriteLine("Type of royalty doesn't displayed");

      }
      return DoesElementExist(TypeofRoyalty);
    }

    public string GetOverseasFooterLink()
    {
      return GetElementText(OverSeasFooterLink);
    }
    public string GetLatestInfoFooterLink()
    {
      return GetElementText(LatestFooterLink);
    }
    public void ClickOverSeasFooterLink()
    {
      Thread.Sleep(2000);
      ExecuteTask(() =>
      {
        WaitForPresence(OverSeasFooterLink);
        SafeJavaScrollToElement(OverSeasFooterLink);
        SafeJavaScriptClick(OverSeasFooterLink);
        Thread.Sleep(4000);

      });
    }
    public void ClickLatestInfoFooterLink()
    {
      ExecuteTask(() =>
      {
        WaitForPresence(LatestFooterLink);
        SafeJavaScrollToElement(LatestFooterLink);
        SafeJavaScriptClick(LatestFooterLink);
        Thread.Sleep(4000);

      });
    }
    public bool IsOverseasLinkRedirectionUrlDisplayed(string Url)
    {
      
      Thread.Sleep(2000);
      string redirecturl = OverSeasFooterLink.GetAttribute("href");
      var tabUrl = WindowsHandling.ReturnWindonwURL(_driver);
      if (redirecturl != null)
      {
        StringAssert.AreNotEqualIgnoringCase(Url, tabUrl);
      }
      else
      {
        Console.WriteLine("Url displayed doesn't match");
      }
      return DoesElementExist(OverSeasFooterLink);

    }
    public bool IsLatestInfoLinkRedirectionUrlDisplayed(string Url)
    {
      Thread.Sleep(2000);
      string redirecturl = LatestFooterLink.GetAttribute("href");
      var tabUrl = WindowsHandling.ReturnWindonwURL(_driver);
      if (redirecturl != null)
      {
        StringAssert.AreNotEqualIgnoringCase(Url, tabUrl);
      }
      else
      {
        Console.WriteLine("Url displayed doesn't match");
      }
      return DoesElementExist(LatestFooterLink);
    }


  }

}
