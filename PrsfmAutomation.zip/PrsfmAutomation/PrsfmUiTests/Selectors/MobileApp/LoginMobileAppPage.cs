﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;

namespace PrsfmUiTests.Selectors.MobileApp
{
  internal class LoginMobileAppPage : WebDriverExtensions
  {
    
    public LoginMobileAppPage(IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.Id, Using = "logonIdentifier")]
    public IWebElement EmailField { get; set; }

    [FindsBy(How = How.Id, Using = "password")]
    public IWebElement PasswordField { get; set; }

    [FindsBy(How = How.Id, Using = "next")]
    public IWebElement LoginBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Invalid username or password.')]")]
    public IWebElement IncorrectPasswordValirErrMsg { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(@class, 'error pageLevel')]")]
    public IWebElement IncorrectEmailValidErrMsg { get; set; }

    [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Please enter your email')]")]
    public IWebElement ValidErrMsg { get; set; }


    public void EnterEmail(string email)
    {
      WaitForPresence(EmailField);
      SafeJavaScrollToElement(EmailField);
      SafeSendKeys(EmailField, email);
    }

    public void EnterPassword(string password)
    {
      SafeJavaScrollToElement(PasswordField);
      SafeSendKeys(PasswordField, password);
    }
    public void ClickLogin()
    {
      SafeJavaScrollToElement(LoginBtn);
      SafeJavaScriptClick(LoginBtn);
    }
    public string GetLoginBtn()
    {
      WaitForPresence(LoginBtn);
      return GetElementText(LoginBtn);
    }

    public string GetInvaliPwdErrMsg()
    {
      return GetElementText(IncorrectPasswordValirErrMsg);
    }

    public string GetInvaliEmailErrMsg()
    {
      return GetElementText(IncorrectEmailValidErrMsg);
    }
    public string GetEmailValidErrMsg()
    {
      return GetElementText(ValidErrMsg);
    }
    public void GenericEnterMobileAppEmail()
    {
      SafeSendKeys(EmailField, DataSource.GenericMobileAppLoginCredentials.email);
    }

    public void GenericEnterMobileAppPassword()
    {
      SafeSendKeys(PasswordField, DataSource.GenericMobileAppLoginCredentials.password);
    }
  }
}
