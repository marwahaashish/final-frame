﻿using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.MobileApp
{
  internal class MyWorksPage : WebDriverExtensions
  {
    public MyWorksPage (IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'search-card-list')]/a)[1]")]
    public IWebElement MyWorkFirstResultLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(@href, '#/memberworks')]")]
    public IWebElement PageHeaderLink { get; set; }

    [FindsBy(How = How.XPath, Using = "(//a[contains(@href, '#/memberwork')]) [1]")]
    public IWebElement MyWorkPageHeader { get; set; }

    [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Kobalt Music Publishing Ltd')]")]
    public IWebElement SelectedUserProfileName { get; set; }

    [FindsBy(How = How.XPath, Using = "//h1[contains(text(), 'My works')]")]
    public IWebElement PageHeaderTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Warner Chappell Music Ltd')]")]
    public IWebElement PageHeaderTitleSelectedUser { get; set; }

    [FindsBy(How = How.XPath, Using = "//h5")]
    public IWebElement SearchCardHeaderFoorAnotherUser { get; set; }

    [FindsBy(How = How.XPath, Using = "//h4[contains(text(), '1000')]")]
    public IWebElement NumResults { get; set; }

    [FindsBy(How  = How.XPath, Using = "(//a[contains(@class, 'search-card')]/p)[1])")]
    public IWebElement FirstSearchCardWriterName { get; set; }
  
    [FindsBy(How  = How.XPath, Using = "//div[contains(@class, 'search-card-list')]")]
    public IWebElement SearchResultList { get; set; }

    [FindsBy(How = How.XPath, Using = "(//a[contains(@class, 'search-card')]/h5)[1]")]
    public IWebElement FirstSearchCardHeader { get; set; }

    [FindsBy(How = How.XPath, Using = "(//a[contains(@class, 'search-card')]/p)[1]")]
    public IWebElement MyWorksSearchCardWriterName { get; set; }

    [FindsBy(How = How.XPath, Using = "//header[contains(@class, 'page_header d-flex flex-column with-tabs')]/h1")]
    public IWebElement PageHeaderInShareHolderTab { get; set; }

    [FindsBy(How = How.XPath, Using = "(//button[contains(@class, 'shareholder-card')]/h4)[1]")]
    public IWebElement WriterNameInShareHolderTab { get; set; }

    [FindsBy(How = How.XPath, Using = "//header[contains(@class, 'page_header d-flex flex-column with-tabs')]//strong")]
    public IWebElement TuneCode { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'flex-grow-1')]/p)[1]")]
    public IWebElement PerformingShare { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'flex-grow-1')]/p)[2]")]
    public IWebElement MechanicalShare { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'shareholder-card--below-fold')]/p)[1]")]
    public IWebElement CAENumber { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'shareholder-card--below-fold')]/p)[2]")]
    public IWebElement ChainOfTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'shareholder-card--below-fold')]/p)[3]")]
    public IWebElement CurrenUkPerformingSociety { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'shareholder-card--below-fold')]/p)[4]")]
    public IWebElement CurrentUkMechanicalSociety { get; set; }


    public void ClickMyWorksFirstResultLink()
    {
      Thread.Sleep(2000);
      ExecuteTask(() =>
      {
        WaitForPresence(MyWorkFirstResultLink);
        SafeJavaScrollToElement(MyWorkFirstResultLink);
        SafeJavaScriptClick(MyWorkFirstResultLink);
        Thread.Sleep(2000);

      });
    }

    public string GetPageHeaderTitle()
    {
      WaitForPresence(PageHeaderTitle);
      return GetElementText(PageHeaderTitle);
    }
    public string GetPageHeaderTitleAnotherUser()
    {
      WaitForPresence(PageHeaderTitleSelectedUser);
      return GetElementText(PageHeaderTitleSelectedUser);
    }
    public string GetSelctedUserProfileName()
    {
      WaitForPresence(SelectedUserProfileName);
      return GetElementText(SelectedUserProfileName);       
   }

    public bool IsNumberOfResultsDisplayed(string NumberOfResults)
    {
      string ResultMsg = "Displaying first 1000 results";
      string sub = ResultMsg.Substring(17, 4);
      if (ResultMsg.Contains(NumberOfResults))
      {
        Assert.AreEqual(NumberOfResults, sub);
        Console.WriteLine("Substring: {0}", sub);

      }
      else
      {
        Assert.AreNotEqual(NumberOfResults, sub);
        //Console.WriteLine("Search result count doesn't match");
        
      }
      
      return DoesElementExist(NumResults);
    }
    public bool isSearchResultListDisplayed()
    {
      if (!SearchResultList.Displayed)
      {
        Console.WriteLine("My works search result displayed");
      }
      return DoesElementExist(SearchResultList);
    }
    public string GetFirstSearchCardHeader()
    {
      WaitForPresence(FirstSearchCardHeader);
      return GetElementText(FirstSearchCardHeader);
    }
    public void IsFirstSearchCardDisplayed()
    {
      Assert.IsTrue(FirstSearchCardHeader.Displayed);
    }
    public bool IsFirstSearchCardHeaderDisplayed()
    {
       string HeaderText = FirstSearchCardHeader.Text;
      if (FirstSearchCardHeader != null)
      {
        Console.WriteLine("FirstSearchCardHeader--->"+ HeaderText);
      }
      else
      {
        Console.WriteLine("FirstSearchCardHeader doesn't displayed");
      }
      return DoesElementExist(FirstSearchCardHeader);
    }
    public bool IsMyworksSearchCardHeaderDisplayed()
    {
      string WriterName = MyWorksSearchCardWriterName.Text;
      if (MyWorksSearchCardWriterName != null)
      {
        Console.WriteLine("MyWorksSearchCardWriterName--->" + WriterName);
      }
      else
      {
        Console.WriteLine("MyWorksSearchCardWriterName doesn't displayed");
      }
      return DoesElementExist(FirstSearchCardHeader);
    }
    public string GetFirstSearchCardWriterName()
    {
      WaitForPresence(MyWorksSearchCardWriterName);
      return GetElementText(MyWorksSearchCardWriterName);
    }
    public string GetShareHolderCardHeaderName()
    {
      WaitForPresence(PageHeaderInShareHolderTab);
      return GetElementText(PageHeaderInShareHolderTab);
    }
    public string GetShareHolderCardWriterName()
    {
      WaitForPresence(WriterNameInShareHolderTab);
      return GetElementText(WriterNameInShareHolderTab);
    }
    public string GetSearhResultHeaderMatchesInShareholderHeader()
    {
      WaitForPresence(PageHeaderInShareHolderTab);
      return GetElementText(PageHeaderInShareHolderTab);
    }
    public string GetSearhCardWriterNameMatchesInShareHolderTab()
    {
      WaitForPresence(WriterNameInShareHolderTab);
      return GetElementText(WriterNameInShareHolderTab);
    }
   
    public void IsSearchCardWriterNameMatchesInShareHolderTab()
    {
      Thread.Sleep(4000);
      Assert.IsTrue(WriterNameInShareHolderTab.Displayed);
        
    }
    public void IsWriterNameInShareHolderTabMatchFirstSearchCardDisplayed()
    {
      Thread.Sleep(4000);
      Assert.IsTrue(PageHeaderInShareHolderTab.Displayed);

    }
    public void IsSearchCardHeaderDifferentForOtherUserDisplayed()
    {
      Assert.IsTrue(SearchCardHeaderFoorAnotherUser.Displayed);
    }
   public bool IsPageHeaderInShareHolderTabMatchFirstSearchCardHeaderDisplayed()
    {
      Thread.Sleep(2000);
      string Header1 = PageHeaderInShareHolderTab.Text;
      string Header2 = FirstSearchCardHeader.Text;
     
      if (Header1.Equals(Header2))
      {
        Console.WriteLine("PageHeaderInShareHolderTab matches with FirstSearchCardHeader");
      }
      else
      {
        Console.WriteLine("PageHeaderInShareHolderTab doesn't matches with FirstSearchCardHeader");
      }

      return DoesElementExist(PageHeaderInShareHolderTab);
    }
    public bool IsWriterNameInMyShareHolderPageMatchFirstSearchCardDisplayed()
    {
      if (WriterNameInShareHolderTab.Text.Equals(MyWorksSearchCardWriterName.Text))
      {
        Console.WriteLine("WriterNameInShareHolderTab matches with FirstSearchCardWriterName");
      }
      else
      {
        Console.WriteLine("WriterNameInShareHolderTab doesn't matches with FirstSearchCardWriterName");
      }

      return DoesElementExist(PageHeaderInShareHolderTab);
    }
    public bool IsTuneCodeDisplayed()
    {
      string TuneCodeText = TuneCode.Text;
      if(TuneCode != null)
      {
        Console.WriteLine("Tune Code is displayed---->" + TuneCodeText);
      }
      else
      {
        Console.WriteLine("Tune code doesn't displayed");
      }
      return DoesElementExist(TuneCode);
    }
    public bool IsPeformingShareDisplayed()
    {
      string PerformingSharetext = PerformingShare.Text;
      if(PerformingShare != null)
      {
        Console.WriteLine("Performing share------>" + PerformingSharetext);
      }
      else
      {
        Console.WriteLine("Performing share doesn't displayed");
      }

      return DoesElementExist(PerformingShare);
    }
    public bool IsCAENumberDisplayed()
    {
      string CAENum = CAENumber.Text;
      if (CAENumber != null)
      {
        Console.WriteLine("CAENumber number------>" + CAENum);
      }
      else
      {
        Console.WriteLine("CAENumber doesn't displayed");
      }

      return DoesElementExist(CAENumber);
    }
    public bool IsChainOfTitleDisplayed()
    {
      string ChainOfTitl = ChainOfTitle.Text;
      if (ChainOfTitle != null)
      {
        Console.WriteLine("ChainOfTitle------>" + ChainOfTitl);
      }
      else
      {
        Console.WriteLine("ChainOfTitle doesn't displayed");
      }

      return DoesElementExist(ChainOfTitle);
    }
    public bool IsCurrentUkPerformingSocietyDisplayed()
    {
      string PerformingSociety = CurrenUkPerformingSociety.Text;
      if (CurrenUkPerformingSociety != null)
      {
        Console.WriteLine("PerformingSociety------>" + PerformingSociety);
      }
      else
      {
        Console.WriteLine("PerformingSociety doesn't displayed");
      }

      return DoesElementExist(CurrenUkPerformingSociety);
    }
    public bool IsCurrentUkMechanicalSocietyDisplayed()
    {
      string MechanicalSociety = CurrentUkMechanicalSociety.Text;
      if (CurrentUkMechanicalSociety != null)
      {
        Console.WriteLine("MechanicalSociety------>" + MechanicalSociety);
      }
      else
      {
        Console.WriteLine("MechanicalSociety doesn't displayed");
      }

      return DoesElementExist(CurrentUkMechanicalSociety);
    }
    public bool IsMechanicalShareDisplayed()
    {
      string MechanicalSharetext = MechanicalShare.Text;
      if (MechanicalShare != null)
      {
        Console.WriteLine("MechanicalShare ------>" + MechanicalSharetext);
      }
      else
      {
        Console.WriteLine("MechanicalShare doesn't displayed");
      }

      return DoesElementExist(MechanicalShare);
    }
  }
}
