﻿using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.MobileApp
{
 internal class MemWorksPage : WebDriverExtensions
  {
    public MemWorksPage(IWebDriver driver) : base (driver)
    {
      PageFactory.InitElements(_driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//h1")]
    public IWebElement WriteNameOnMemberWorks { get; set; }

    [FindsBy(How = How.XPath, Using = "//strong")]
    public IWebElement MembershipNumber { get; set; }


    public string GetMemberShipNumber()
    {
      WaitForPresence(MembershipNumber);
      return GetElementText(MembershipNumber);

    }
    public string  GetWriterNameMemWorks()
    {
       WaitForPresence(WriteNameOnMemberWorks);
      return GetElementText(WriteNameOnMemberWorks);
    }
    public void IsWriterNameOnDisplayedonMemWorks()
    {
      var WriterNameOnMemWorks = WriteNameOnMemberWorks.Text;
      Assert.IsTrue(WriteNameOnMemberWorks.Displayed);
    }
    public void IsMembershipNumberDisplayed()
    {
      Assert.IsTrue(MembershipNumber.Displayed);
    }
  }
}
