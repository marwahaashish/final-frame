﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.MobileApp
{
  internal class SearchWorksPage : WebDriverExtensions
  {
    public SearchWorksPage(IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//h1[contains(text(), 'Search works')]")]
    public IWebElement PageHeaderLink { get; set; }

    [FindsBy(How = How.Id, Using = "workTitle")]
    public IWebElement WorkTitleInPutField { get; set; }

    [FindsBy(How = How.Id, Using = "lastName")]
    public IWebElement LastNameField { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Search')]")]
    public IWebElement SearchButton { get; set; }

    public string GetPageHeader()
    {
      return GetElementText(PageHeaderLink);
    }
    public void ClickSearchButton()
    {
      ExecuteTask(() =>
      {
        WaitForPresence(SearchButton);
        SafeJavaScrollToElement(SearchButton);
        SafeJavaScriptClick(SearchButton);

      });
    }

    public void EnterWorkTitle(string workTitle)
    {
      WaitForPresence(WorkTitleInPutField);
      SafeSendKeys(WorkTitleInPutField, workTitle);
    }
    public void EnterLastName(string LastName)
    {
      WaitForPresence(LastNameField);
      SafeSendKeys(LastNameField, LastName);
    }
  }
}
