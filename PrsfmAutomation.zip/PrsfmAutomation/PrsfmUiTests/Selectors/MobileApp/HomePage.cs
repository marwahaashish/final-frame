﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.MobileApp
{
  internal class HomePage : WebDriverExtensions
  {
    public HomePage(IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }
    [FindsBy(How = How.XPath, Using = "//button[contains(@class, 'main_nav__button main_nav--user m-0')]")]
    public IWebElement UserProfileMenu { get; set; }

    [FindsBy(How = How.XPath, Using = "(//ul[contains(@class, 'nav navbar-nav')]/li/button)[1]")]
    public IWebElement loggedinUserFromUserProfile { get; set; }

    [FindsBy(How = How.XPath, Using = "(//ul[contains(@class, 'nav navbar-nav')]/li/button)[1]")]
    public IWebElement SecondUserFromUserProfile { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'landing_page')]/p)[1]")]
    public IWebElement loggedinUser { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'landing_page')]/p)[2]")]
    public IWebElement MembershipNo { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'landing_page')]//span)[1]")]
    public IWebElement LandingPageHeaderTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(@class, 'dao--payment lime')]")]
    public IWebElement DistributionAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(@class, 'main_nav__button main_nav--menu m-0')]")]
    public IWebElement HamBurgerMenu { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'Sign out')]")]
    public IWebElement SignOutLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//h5[contains(text(),'Are you sure you want to log out?')]")]
    public IWebElement LogoutPageHeader { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Log out')]")]
    public IWebElement LogoutBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Cancel')]")]
    public IWebElement CancelBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(@data-toggle, 'collapse')]")]
    public IWebElement DAOBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'The last performing royalty distribution was on')]")]
    public IWebElement DAOMessage { get; set; }

    [FindsBy(How = How.XPath, Using = "(//a[contains(@href, '#/myworks')])[2]")]
    public IWebElement MyWorksLink { get; set; }

    [FindsBy(How = How.XPath, Using = "(//a[contains(@href, '#/search')])[2]")]
    public IWebElement SearchLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(@class, 'landing_page')]/a")]
    public IWebElement PaymentDatesLink { get; set; }

    public bool AssertPRSMobileApp()
    {
      TaskHelper.ExecuteTask(() =>
      {
        new WebDriverExtensions(_driver).WaitForPresence(loggedinUser);
      });
   //   WaitForPresence(loggedinUser);
      return DoesElementExist(loggedinUser);
    }

    public string GetHeaderTitle()
    {
      WaitForPresence(LandingPageHeaderTitle);
      return GetElementText(LandingPageHeaderTitle);
    }

    public void SelectUserFromUserProfileMenu()
    {
      ExecuteTask(() =>
      {
        WaitForPresence(UserProfileMenu);
        SafeJavaScrollToElement(UserProfileMenu);
        SafeJavaScriptClick(UserProfileMenu);
        SelectUser();

      });
    }
    public void SelectUser()
    {
      ExecuteTask(() =>
      {
        WaitForPresence(loggedinUserFromUserProfile);
        SafeJavaScrollToElement(loggedinUserFromUserProfile);
        SafeJavaScriptClick(loggedinUserFromUserProfile);

      });
    }
    public void SelectAnotherUser()
    {
      ExecuteTask(() =>
      {
        WaitForPresence(SecondUserFromUserProfile);
        SafeJavaScrollToElement(SecondUserFromUserProfile);
        SafeJavaScriptClick(SecondUserFromUserProfile);

      });
    }
    public void SelectAnotherUserFromUserProfileMenu()
    {
      ExecuteTask(() =>
      {
        WaitForPresence(UserProfileMenu);
        SafeJavaScrollToElement(UserProfileMenu);
        SafeJavaScriptClick(UserProfileMenu);
        SelectAnotherUser();

      });
    }
    public string GetLandingPageLoggedInUser()
    {
      Thread.Sleep(4000);
      WaitForPresence(loggedinUser);     
      return GetElementText(loggedinUser);
    }

    public string GetLandingPageHeaderTitle()
    {
      WaitForPresence(LandingPageHeaderTitle);
      return GetElementText(LandingPageHeaderTitle);
    }
    public string GetMembershipNumber()
    {
      WaitForPresence(MembershipNo);
      return GetElementText(MembershipNo);
    }

    public bool IsDistributionAmountDisplayed()
    {
      if (DistributionAmount != null)
      {
        Console.WriteLine("Distribution amount displayed");
      }
      else
      {
        Console.WriteLine("Distribution amount not displayed");
      }
      return DoesElementExist(DistributionAmount);
    }
    public void ClickHamburgerMenuAndSignout()
    {
      ExecuteTask(() =>
      {
        WaitForPresence(HamBurgerMenu);
        SafeJavaScrollToElement(HamBurgerMenu);
        SafeJavaScriptClick(HamBurgerMenu);
        ClickSignout();

      });
    }
    public void ClickSignout()
    {

      ExecuteTask(() =>
      {

        WaitForPresence(SignOutLink);
        SafeJavaScrollToElement(SignOutLink);
        SafeClick(SignOutLink);

      });
    }
    public string GetLogoutPageHeader()
    {
      WaitForPresence(LogoutPageHeader);
      return GetElementText(LogoutPageHeader);

    }

    public void ClickLogoutBtn()
    {
      ExecuteTask(() =>
      {
        WaitForPresence(LogoutBtn);
        SafeJavaScrollToElement(LogoutBtn);
        SafeJavaScriptClick(LogoutBtn);

      });
    }

    public void ClickDAOButton()
    {
      Thread.Sleep(2000);
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(DAOBtn);
        SafeJavaScriptClick(DAOBtn);
      });
    }

    public string GetDAOText()
    {
      return GetElementText(DAOMessage);
    }
    public void ClickMyWorks()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(MyWorksLink);
        SafeJavaScriptClick(MyWorksLink);

      });
    }
    public void ClickPaymentDatesLink()
    {
      Thread.Sleep(3000);
      ExecuteTask(() =>
      {
        WaitForPresence(PaymentDatesLink);
        SafeJavaScrollToElement(PaymentDatesLink);
        SafeJavaScriptClick(PaymentDatesLink);
        Thread.Sleep(2000);

      });
    }
    public void ClickAndConfirmLogout()
    {
      Thread.Sleep(4000);
      ClickHamburgerMenuAndSignout();
      ClickLogoutBtn();
    }

    public void ClickWorks()
    {
      ExecuteTask(() =>
      {
        WaitForPresence(SearchLink);
        SafeJavaScrollToElement(SearchLink);
        SafeJavaScriptClick(SearchLink);

      });
    }

  }
}
