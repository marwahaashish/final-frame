﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.MobileApp
{
  internal class TermsAndConditionsPage : WebDriverExtensions
  {
    public TermsAndConditionsPage (IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Proceed')]")]
    public IWebElement ProceedBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'Cancel')]")]
    public IWebElement CancelBtn { get; set; }

    public string GetProceddBtn()
    {
      return GetElementText(ProceedBtn);
    }

    public void ClickProceedBtn()
    {
      ExecuteTask(() =>
      {
        WaitForPresence(ProceedBtn);
        SafeJavaScrollToElement(ProceedBtn);
        SafeJavaScriptClick(ProceedBtn);

      });
    }
  }
}
