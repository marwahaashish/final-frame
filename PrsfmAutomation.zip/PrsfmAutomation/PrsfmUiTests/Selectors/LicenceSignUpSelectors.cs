﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors
{
public  class LicenceSignUpSelectors
  {
    [FindsBy(How = How.XPath, Using = "//*[@id='has-account-selection']/div[2]/label/span")]
    public IWebElement HasCompanyAccount { get; set; }

    [FindsBy(How = How.Id, Using = "PrsAccountId")]
    public IWebElement PRSAccountID { get; set; }

    [FindsBy(How = How.Name, Using = "Firstname")]
    public IWebElement FirstName { get; set; }

    [FindsBy(How = How.Name, Using = "Secondname")]
    public IWebElement LastName { get; set; }

    [FindsBy(How = How.Name, Using = "EMail")]
    public IWebElement EmailAddress { get; set; }

    [FindsBy(How = How.Id, Using = "signup-licensees-submit")]
    public IWebElement Submit { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[@id='gcaptch - error']")]
    public IWebElement CaptchaError { get; set; }

  }
}
