﻿using System;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class NewClaimOverseasMusicUsageSelectors
    {
        public string Discard = ".//input[@value='Discard']";

        [FindsBy(How = How.XPath, Using = "//input[@value='Continue']")]
        public IWebElement Continue { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[select[@id='uc_2_ctl02_OOMUWebPart_usageType']]/div")]
        public IWebElement MusicTypeDropdown { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='stepInfo']")]
        public IWebElement StepInfo { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//a[@href='/'][contains(text(),'Return')]")]
        public IWebElement ReturnButton { get; set; }
    }
}
