﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class ThirdPartyAuthorisationMandateFormSelectors
    {
        [FindsBy(How = How.Id, Using = "rblMandateOption_0")]
        public IWebElement RadioButtonAuthorisedPersonYes { get; set; }

        [FindsBy(How = How.Id, Using = "rblMandateOption_1")]
        public IWebElement RadioButtonAuthorisedPersonNo { get; set; }

    }
}
