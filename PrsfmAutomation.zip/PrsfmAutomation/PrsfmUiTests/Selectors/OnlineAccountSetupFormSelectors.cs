﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class OnlineAccountSetupFormSelectors
    {
        [FindsBy(How = How.Id, Using = "ddlHintQuestion")]
        public IWebElement SignUpQuestion { get; set; }

        [FindsBy(How = How.Id, Using = "txtSecurityAnswer")]
        public IWebElement SignUpAnswer { get; set; }
    }
}
