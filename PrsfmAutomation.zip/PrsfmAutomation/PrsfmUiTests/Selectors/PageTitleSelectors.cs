﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class PageTitleSelectors
    {
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Here for music')]")]
        public IWebElement HereForMusic { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Join')]")]
        public IWebElement Join { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Join as a writer')]")]
        public IWebElement JoinAsaWriter { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Join PRS as a writer')]")]
        public IWebElement JoinPrsAsaWriter { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Welcome back')]")]
        public IWebElement WelcomeBack { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Sign up for an online membership account')]")]
        public IWebElement MemberSignUp { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Make a claim for music usage in the UK or overseas')]")]
        public IWebElement MakeaClaimForMusicUsageInTheUkOrOverseas { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'New claim (Overseas music usage)')]")]
        public IWebElement NewClaimOverseasMusicUsage { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'New claim (Radio)')]")]
        public IWebElement NewClaimRadio { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Live Performances')]")]
        public IWebElement LivePerformances { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Forgotten password')]")]
        public IWebElement ForgottenPassword { get; set; }
    
    }
}
