﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class NavigationBarSelectors
    {
        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'visible-md')]//a[@title='Home']")]
        public IWebElement SiteLogo { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'visible-md')]//a[@href='/what-we-do']")]
        public IWebElement WhatWeDo { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'visible-md')]//a[@href='/royalties']")]
        public IWebElement Royalties { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'visible-md')]//a[@href='/works']")]
        public IWebElement Works { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'visible-md')]//a[@href='/licences']")]
        public IWebElement Licences { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'visible-md')]//a[@href='/help']")]
        public IWebElement Help { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='navbar']/div/ul[2]/li[2]/a")]
        public IWebElement Login { get; set; }

  }
}
