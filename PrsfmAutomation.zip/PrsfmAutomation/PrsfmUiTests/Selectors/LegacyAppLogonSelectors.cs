﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace IamUiTests.Selectors
{
  public class LegacyAppLogonSelectors
  {
    [FindsBy(How = How.LinkText, Using = "LOG IN")]
    public IWebElement Login { get; set; }

    [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Log in to your account')]")]
    public IWebElement LogonText { get; set; }

    [FindsBy(How = How.Id, Using = "logonIdentifier")]
    public IWebElement EmailAddress { get; set; }

    [FindsBy(How = How.Id, Using = "fdemail")]
    public IWebElement FDEmailAddress { get; set; }

    [FindsBy(How = How.Id, Using = "fdNext")]
    public IWebElement FDNext { get; set; }

    [FindsBy(How = How.Id, Using = "password")]
    public IWebElement Password { get; set; }

    [FindsBy(How = How.Id, Using = "next")]
    public IWebElement Submit { get; set; }

    [FindsBy(How = How.LinkText, Using = "REGISTER A NEW WORK")]
    public IWebElement LoadOLR { get; set; }

    [FindsBy(How = How.Id, Using = "ctl00_mainContent_btnAccept")]
    public IWebElement LoadWUR { get; set; }

    [FindsBy(How = How.XPath, Using = "//td[contains(text(),'Welcome to the Search Cue Sheets service')]")]    
    public IWebElement LoadWACS { get; set; }

    [FindsBy(How = How.Id, Using = "ctl00_WACDMainContent_works_control_btnSearch")]
    public IWebElement LoadWACD { get; set; }

    [FindsBy(How = How.LinkText, Using = "Licence Rates")]
    public IWebElement LoadMLCS { get; set; }

    [FindsBy(How = How.Id, Using = "ctl00_ContentPlaceHolder1_imbSearch")]
    public IWebElement LoadVICO { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Search')]")]
    public IWebElement LoadWACU { get; set; }

    [FindsBy(How = How.LinkText, Using = "Counterclaims Home Page")]
    public IWebElement LoadDuplicateClaims { get; set; }

    [FindsBy(How = How.Id, Using = "ctl00_ContentPlaceHolder1_btnSearch")]
    public IWebElement LoadOAS { get; set; }

    [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Search')]")]
    public IWebElement LoadCopCon { get; set; }

    [FindsBy(How = How.XPath, Using = " //img[@name='claim_history_tab']")]
    public IWebElement LoadNWR { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[@id='btAccept']")]
    public IWebElement LoadAdmissions { get; set; }

    [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Search our')]")]
    public IWebElement ClickWACDTile { get; set; }

    [FindsBy(How = How.XPath, Using = "//h3/b[contains(text(),'cue sheets')]")]
    public IWebElement ClickWACSTile { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Show More')]")]
    public IWebElement ClickShowMore { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[@href='http://apps-rt.prsformusic.com/WACS/']")]
    public IWebElement ClickSeachCueSheets { get; set; }

    [FindsBy(How = How.XPath, Using = "//b[contains(text(),'unpaid royalties')]")]
    public IWebElement ClickUnpaidRoyaltiesTile { get; set; }

    [FindsBy(How = How.XPath, Using = " //a[contains(text(),'Claim unpaid MCPS royalties')]")]
    public IWebElement ClickClaimUnpaidMCPSRoyalties { get; set; }

    [FindsBy(How = How.XPath, Using = " //a[contains(text(),'Claim unpaid PRS royalties')]")]
    public IWebElement ClickClaimUnpaidPRSRoyalties { get; set; }
    
    [FindsBy(How = How.XPath, Using = "//b[contains(text(),'concert service')]")]
    public IWebElement ClickMLCSTile { get; set; }

    [FindsBy(How = How.XPath, Using = "//b[contains(text(),'and clearances')]")]
    public IWebElement ClickVICOTile { get; set; }

    [FindsBy(How = How.XPath, Using = " //a[contains(text(),'View my invoices and clearances')]")]
    public IWebElement ClickVICO { get; set; }

    [FindsBy(How = How.XPath, Using = "//b[contains(text(),'new works')]")]
    public IWebElement ClickNWRTile { get; set; }

    [FindsBy(How = How.XPath, Using = " //a[contains(text(),'Browse new works')]")]
    public IWebElement ClickNWR { get; set; }

    [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Register or amend')]")]
    public IWebElement ClickOLRTile { get; set; }

    [FindsBy(How = How.XPath, Using = "//b[contains(text(),'overseas agencies')]")]
    public IWebElement ClickOASTile { get; set; }

    [FindsBy(How = How.XPath, Using = " //a[contains(text(),'Manage overseas agencies')]")]
    public IWebElement ClickOAS { get; set; }

    [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Log in')]")]
    public IWebElement LogonTextAssimilate { get; set; }

    [FindsBy(How = How.Id, Using = "txtUserName")]
    public IWebElement AssimilateEmailAddress { get; set; }

    [FindsBy(How = How.Id, Using = "txtPassword")]
    public IWebElement AssimilatePassword { get; set; }

    [FindsBy(How = How.XPath, Using = "//input[contains(@class,'btn btn-default btn-block')]")]
    public IWebElement AssimilateSubmit { get; set; }

    [FindsBy(How = How.Id, Using = "cae")]
    public IWebElement AssimilatCAE { get; set; }

  }
}
