﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OlsUiTests.Pages
{
  internal class HeadlinesSectionPage : WebDriverExtensions
  {
    public HeadlinesSectionPage(IWebDriver driver)
        : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    #region Identify elements locators
    [FindsBy(How = How.XPath, Using = "//h4[@data-attr='distinct-count-work']")]
    public IWebElement EarningWorksNum { get; set; }

    [FindsBy(How = How.XPath, Using = "//h4[@data-attr='distinct-count-usage-group']")]
    public IWebElement UsageTypeNum { get; set; }

    [FindsBy(How = How.XPath, Using = "//h4[@data-attr='distinct-count-territory']")]
    public IWebElement TerritoriesNum { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[2][@data-attr='top-statement-work-title']")]
    public IWebElement TopWorkTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//p/span[3][@data-attr='top-statement-work-amount']")]
    public IWebElement TopWorkAmount { get; set; }


    #endregion

    public string GetEarningWorksNum()
    {
      Thread.Sleep(3000);
      return GetElementText(EarningWorksNum);
    }

    public string GetUsageTypeNum()
    {
      Thread.Sleep(2000);
      return GetElementText(UsageTypeNum);
    }

    public string GetTerritoriesNum()
    {
      Thread.Sleep(2000);
      return GetElementText(TerritoriesNum);
    }

    public string GetTopWorkTitle()
    {
      Thread.Sleep(2000);
      return GetElementText(TopWorkTitle);
    }

    public string GetTopWorkAmount()
    {
      Thread.Sleep(2000);
      return GetElementText(TopWorkAmount);
    }
  }
}
