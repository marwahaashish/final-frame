﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OlsUiTests.Pages
{
  internal class AllWorksAndAdjustmentsPage : WebDriverExtensions
  {
    public AllWorksAndAdjustmentsPage(IWebDriver driver)
        : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//div[@class='exploration-block-row table-chart-row']")]
    public IWebElement AllWorksTable { get; set; }

    [FindsBy(How = How.XPath, Using = "//section//table[@data-attr='table-adjustments']")]
    public IWebElement AllAdjustmentsTable { get; set; }

    [FindsBy(How = How.XPath, Using = "(//dl[contains(@class,'statement-header__list')]/dd)[1]")]
    public IWebElement RoyaltyAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//h1")]
    public IWebElement Society { get; set; }

    [FindsBy(How = How.XPath, Using = "//dl/dd[2]")]
    public IWebElement Distribution { get; set; }

    [FindsBy(How = How.XPath, Using = "//dl/dd[@data-attr='statement-royalty-earner']")]
    public IWebElement RoyaltyName { get; set; }

    [FindsBy(How = How.XPath, Using = "//dl[2]/dd")]
    public IWebElement IpiNum { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='exploration-block-row table-chart-row']//div[@class='cell']//span[@role='button'][contains(text(), 'Title')]")]
    public IWebElement AllWorksSortArrow { get; set; }

    [FindsBy(How = How.XPath, Using = "//table[@data-attr='table-adjustments']//span[@role='button'][contains(text(), 'Work title')]")]
    public IWebElement AdjustmentsSortArrow { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='table-body']/div[1]//div[@class='content']")]
    public IWebElement FirstTitleAllWorks { get; set; }

    [FindsBy(How = How.XPath, Using = "//table[@data-attr='table-adjustments']//tbody/tr[1]/td[1]")]
    public IWebElement FirstTitleAdjustments { get; set; }

    [FindsBy(How = How.XPath, Using = " //div[@class='adjustment']//span[@role='button']")]
    public IWebElement AllWorksAdjustmentColumnTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='exploration-block-row table-chart-row']//div[@class='cell']//span[@role='button'][contains(text(), 'Adjustment')]")]
    public IWebElement AdjustmentColumn { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='all-works-2']/div[2]/div[1]/div[2]/div[2]")]
    public IWebElement FirstAdjustmentAllworks {get; set; }

    public bool isAllWorksTableDisplayed()
    {
      WaitForPresence(AllWorksTable);
      SafeJavaScrollToElement(AllWorksTable);
      return DoesElementExist(AllWorksTable);
    }

    public bool isAdjustmentsTableDisplayed()
    {
      return DoesElementExist(AllAdjustmentsTable);
    }

    public string GetRoyaltyAmount()
    {
      Thread.Sleep(1000);
      SafeJavaScrollToElement(RoyaltyAmount);
      return GetElementText(RoyaltyAmount);
    }

    public string GetSociety()
    {
      return GetElementText(Society);
    }

    public string GetDistribution()
    {
      return GetElementText(Distribution);
    }

    public string GetRoyaltyName()
    {
      return GetElementText(RoyaltyName);
    }

    public string GetIpiNum()
    {
      return GetElementText(IpiNum);
    }

    public void ClickAllWorkTablesSortingArrow()
    {
      WaitForPresence(AllWorksSortArrow);
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(AllWorksSortArrow);
        SafeJavaScriptClick(AllWorksSortArrow);
      });
    }

    public void ClickAdjustmentsTableSortingArrow()
    {
      SafeClick(AdjustmentsSortArrow);
    }

    public string GetAllWorksFirstWorkTitle(string WorkTitle)
    {
     return GetElementText(FirstTitleAllWorks);
    }

    public bool IsDescAllWorksFirstWorkTitleDisplayed(string WorkTitle)
    {
      Thread.Sleep(1000);
      string titleDesc = "A Different Way";
     
      if (WorkTitle.Equals(titleDesc))
      {
        string sub = titleDesc.Substring(0, 15);
        Console.WriteLine("Substring: {0}", sub);
      }
      else
      {     
        Console.WriteLine("Title not found");
      }
      return DoesElementExist(FirstTitleAllWorks);
    }

    public bool IsAsceAllWorksFirstWorkTitleDisplayed(string WorkTitle)
    {
      Thread.Sleep(1000);
      string titleAsc = "Your Song";

      if (WorkTitle.Equals(titleAsc))
      {
        string sub = titleAsc.Substring(0, 9);
        Console.WriteLine("Substring: {0}", sub);
      }
      else
      {
        Console.WriteLine("Title not found");
      }
      return DoesElementExist(FirstTitleAllWorks);
    }

    public string GetAdjustmentsFirstWorkTitle()
    {
      Thread.Sleep(9000);
      return GetElementText(FirstTitleAdjustments);
    }
    public bool isAdjustMentColumnNameExists(string ColumnName)
    {
      Thread.Sleep(1000);
      return DoesElementExist(AllWorksAdjustmentColumnTitle);

    }

    public void ClickonAdjustMentColumn()
    {
      WaitForPresence(AdjustmentColumn);
      ExecuteTask(() =>
      {

        SafeJavaScrollToElement(AdjustmentColumn);
        Thread.Sleep(1000);
        SafeJavaScriptClick(AdjustmentColumn);
      });
    }
   
    public string GetFirstAdjustment()
    {
      Thread.Sleep(1000);
      return GetElementText(FirstAdjustmentAllworks);
    }
    public bool IsAscFirstAdjustMentExists(string AdjustValue1)
    {
      
      if(AdjustValue1.Equals(FirstAdjustmentAllworks))
      {
        Console.WriteLine("All works first adjustment value for ascending order is null");
      }
      else
      {
        Console.WriteLine("All works first adjustment value for ascending order is not null");
      }
      return DoesElementExist(FirstAdjustmentAllworks);
    }

    
  }
}
