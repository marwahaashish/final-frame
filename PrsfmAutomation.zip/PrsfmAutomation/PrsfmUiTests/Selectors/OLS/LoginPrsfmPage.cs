﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;


namespace OlsUiTests.Pages
{
  internal class LoginPrsfmPage : WebDriverExtensions
  {
    public LoginPrsfmPage(IWebDriver driver)
        : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//div[@class='login-box']//h2")]
    public IWebElement LoginPageTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//nav[@id='nav']//a[@class='btn btn-default']")]
    public IWebElement LoginBtn { get; set; }

    [FindsBy(How = How.Id, Using = "logonIdentifier")]
    public IWebElement EmailField { get; set; }

    [FindsBy(How = How.Id, Using = "password")]
    public IWebElement PasswordField { get; set; }

    [FindsBy(How = How.Id, Using = "next")]
    public IWebElement SubmitBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='api']//div/p[contains(text(), 'Please enter your email')]")]
    public IWebElement EmailError { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='api']//div[2]/p[contains(text(), 'Please enter your password')]")]
    public IWebElement PasswordError { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='api']/div/div[2]/p")]
    public IWebElement EnterEmailRequest { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'OLS Test Noel Thomas Gallagher')]")]
    public IWebElement OLSPRSWriter { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'OLS Test BMG Rights Management (UK) Limited (Hal David)')]")]
    public IWebElement OLSPRSMCPSPublisher { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[@class='navigation-profile-switch']")]
    public IWebElement OLSPRSMCPSWriter { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='statement-card prs'][1]/div[@class='statement-card__content']/div[@class='statement-card__actions']/a[2]")]
    public IWebElement OLSPRSWriterView { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='statement-card prs'][1]/div[@class='statement-card__content']/div[@class='statement-card__actions']/a[2]")]
    public IWebElement OLSPRSMCPSPublisherView { get; set; }
    
    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'statement-card__actions')]/a)[1]")]
    public IWebElement McpsStateMentCardView { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[@class='dropdown-toggle_loggedin-name']")]
    public IWebElement ProfileSelector { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='logged-in__greeting dropdown-toggle']")] 
    public IWebElement PRSFMSuccessfulLoggedIn { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='introjs-tooltip introjs-bottom-left-aligned']")]
    public IWebElement LinkedAccountsDialog { get; set; }

    [FindsBy(How = How.CssSelector, Using = "div[class='introjs-tooltip introjs-bottom-left-aligned'] a[class='introjs-button introjs-prevbutton introjs-hidden']")]
    public IWebElement LinkedDialogCloseBtn { get; set; }
  
    [FindsBy(How = How.XPath, Using = "//div[@class='introjs-helperLayer']")]
    public IWebElement MembersDropDownlist { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[@href='/authorization/logout']")]
    public IWebElement SignoutLink { get; set; }

    [FindsBy(How = How.CssSelector, Using = "div[class='navbar-right'] span")]
    public IWebElement LoggedinUser { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-default']")]
    public IWebElement LoginButton { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[@class='statement-card__actions']/a)[2]")]
    public IWebElement PrsStatementCardViewLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='statement-card prs'][2]/div[@class='statement-card__content']/div[@class='statement-card__actions']/a[2]")]
    public IWebElement PrsJulyStmtCardViewLink { get; set; }

    public string GetLoginPageTitle()
    {
      return GetElementText(LoginPageTitle);
    }

    public void ClickLoginBtn()
    {
      JavaScriptClick(LoginBtn);
    }

    public void EnterUsername(string username)
    {
      SafeSendKeys(EmailField, username);
    }

    public void EnterPassword(string password)
    {
      SafeSendKeys(PasswordField, password);
    }

    public void ClickSubmitBtn()
    {
      JavaScriptClick(SubmitBtn);
    }

    public bool AssertPRSLoggedIn()
    {
      WaitForPresence(MembersDropDownlist);
      SendKeys(Keys.Escape);
      WaitForPresence(PRSFMSuccessfulLoggedIn);
      return DoesElementExist(PRSFMSuccessfulLoggedIn);

    }
    public void ClickOnMembershipDropDown()
    {
      /*_driver.SwitchTo().DefaultContent();
     WaitForPresence(PopulatedUserNameDropDownlist);
     SafeJavaScriptClick(PopulatedUserNameDropDownlist);
     _driver.SwitchTo().DefaultContent();
     MoveToElement(LinkedAccountsDialog);
     SafeJavaScriptClick(LinkedDialogCloseBtn);
     */

    }

    public string GetEmailErrorMessage()
    {
      return GetElementText(EmailError);
    }

    public string GetPasswordErrorMessage()
    {
      return GetElementText(PasswordError);
    }

    [FindsBy(How = How.Id, Using = "txtCAE")]
    public IWebElement CaeNumberField { get; set; }

    public void EnterCAE(string LoginIPINum)
    {
      SafeSendKeys(CaeNumberField, LoginIPINum);
    }

    public void GenericEnterEmail()
    {
      SafeSendKeys(EmailField, DataSource.GenericLoginCredentials.email);
    }

    public void GenericEnterPassword()
    {
      SafeSendKeys(PasswordField, DataSource.GenericLoginCredentials.password);
    }

    public void SelectPRSMCPSWriter()
    {
      WaitForPresence(MembersDropDownlist);
      SendKeys(Keys.Escape);
      WaitForPresence(ProfileSelector);
      SafeJavaScriptClick(ProfileSelector);
      WaitForPresence(OLSPRSMCPSWriter);
      SafeJavaScriptClick(OLSPRSMCPSWriter);
      WaitForPresence(McpsStateMentCardView);
     // SafeJavaScriptClick(OLSPRSMCPSWriterView);
    }

    public void SelectPRSMCPSPublisher()
    {
      WaitForPresence(ProfileSelector);
      SafeJavaScriptClick(ProfileSelector);
      WaitForPresence(OLSPRSMCPSPublisher);
      SafeJavaScriptClick(OLSPRSMCPSPublisher);
      WaitForPresence(OLSPRSMCPSPublisherView);
      SafeJavaScriptClick(OLSPRSMCPSPublisherView);
    }

    public void SelectPRSWriter()
    {
      WaitForPresence(ProfileSelector);
      SafeJavaScriptClick(ProfileSelector);
      WaitForPresence(OLSPRSWriter);
      SafeJavaScriptClick(OLSPRSWriter);
      WaitForPresence(OLSPRSWriterView);
      SafeJavaScriptClick(OLSPRSWriterView);
      
    }

    public void ClickLoginLink()
    {
      SafeClick(SubmitBtn);
    }

    public string GetEmailError()
    {
      return GetElementText(EmailError);
    }

    public string GetPasswordError()
    {
      return GetElementText(PasswordError);
    }

    public string GetEnterEmailRequest()
    {
      return GetElementText(EnterEmailRequest);
    }

    public void ClickloggedinUser()
    {
      SafeClick(LoggedinUser);
    }
    public void Clicklogout()
    {

      WaitForPresence(LoggedinUser);
      SafeClick(LoggedinUser);
      WaitForPresence(SignoutLink);
      SafeClick(SignoutLink);

    }
    public string GetLoginButtontext()
    {
       WaitForPresence(LoginButton);
       return GetElementText(LoginButton);
    }
    public void ClickMcpsStatementViewLink()
    {
      WaitForPresence(McpsStateMentCardView);
      SendKeys(Keys.Escape);
      SafeJavaScriptClick(McpsStateMentCardView);
      SendKeys(Keys.Escape);
    }
 
    public void ClickPrsStatementViewlink()
    {
      WaitForPresence(PrsStatementCardViewLink);
      SendKeys(Keys.Escape);
      SafeJavaScriptClick(PrsStatementCardViewLink);
      SendKeys(Keys.Escape);
    }
    public void ClickPrsStmyJulyViewLink()
    {
      WaitForPresence(PrsJulyStmtCardViewLink);
      SendKeys(Keys.Escape);
      SafeJavaScriptClick(PrsJulyStmtCardViewLink);
      SendKeys(Keys.Escape);
    }

  }
}
