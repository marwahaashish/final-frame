﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OlsUiTests.Pages
{
  internal class HeaderBlockNOPPage : WebDriverExtensions
  {
    public HeaderBlockNOPPage(IWebDriver driver)
        : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }
 
    [FindsBy(How = How.XPath, Using = "//a[@data-label='notice-of-payment-toggle']")]
    public IWebElement NoticeOfPaymentButton { get; set; }

    [FindsBy(How = How.CssSelector, Using = "section.nop-licensing-bodies div.nop-licensing-bodies__codes")]
    public IWebElement LicensingBodies { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//h1[@data-attr='statement-amount']")]
    public IWebElement PrsRoyaltyAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//dl[1]/dd[@data-attr='nop-earning-line-amount']")]
    public IWebElement RoyaltyTotal { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//dl[2]/dd[@data-attr='nop-earning-line-amount']")]
    public IWebElement BMIAccountVAT { get; set; }

    [FindsBy(How = How.CssSelector, Using = "section[class='royalty-section'] dd[class='nop-earnings-section__amount']")]
    public IWebElement Earnings { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//dl[3]/dd[@data-attr='nop-earning-line-amount']")]
    public IWebElement PlusVAT { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//h3[@data-earning='nop-payment-total']")]
    public IWebElement RoyaltyPlusVAT { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//h4[@data-attr='nop-earner']")]
    public IWebElement Payee { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//dt[@data-attr='nop-bacs-detail']")]
    public IWebElement BacsDetails { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//dd[@data-attr='nop-net-amount']")]
    public IWebElement AmountPaid { get; set; }

   
    public string GetPrsRoyaltyAmount()
    {
      Thread.Sleep(2000);
      return GetElementText(PrsRoyaltyAmount);
    }

    public string GetPlusVAT()
    {
      Thread.Sleep(2000);
      return GetElementText(PlusVAT);
    }
    public string GetRoyaltyPlusVAT()
    {
      Thread.Sleep(2000);
      return GetElementText(RoyaltyPlusVAT);
    }
    public string GetPayee()
    {
      Thread.Sleep(2000);
      return GetElementText(Payee);
    }
    public string GetBacsDetails()
    {
      Thread.Sleep(2000);
      return GetElementText(BacsDetails);
    }
    public string GetAmountPaid()
    {
      Thread.Sleep(2000);
      return GetElementText(AmountPaid);
    }
    public string GetLicenseBodies()
    {
      WaitForPresence(LicensingBodies);
      return GetElementText(LicensingBodies);

    }
    public void ClickonNOPButton()
    {
      ExecuteTask(() => 
      { 
      WaitForPresence(NoticeOfPaymentButton);
      SafeJavaScrollToElement(NoticeOfPaymentButton);
      });
    }
    public void ClickNOPButton()
    {
      ExecuteTask(() =>
      {
        SendKeys(Keys.Escape);
        WaitForPresence(NoticeOfPaymentButton);
        SafeJavaScriptClick(NoticeOfPaymentButton);
        SendKeys(Keys.Escape);
      });
    }
    public string GetRoyaltyTotal()
    {
      WaitForPresence(RoyaltyTotal);
      return GetElementText(RoyaltyTotal);
    }
   public string GetBMIAccountVAT()
   { 
      WaitForPresence(BMIAccountVAT);
      return GetElementText(BMIAccountVAT);
   }
   public string GetEarnings()
   {
      WaitForPresence(Earnings);
      return GetElementText(Earnings);
   }
  }
}
