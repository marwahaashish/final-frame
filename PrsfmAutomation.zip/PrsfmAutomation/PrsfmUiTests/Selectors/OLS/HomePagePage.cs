﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OlsUiTests.Pages
{
  internal class HomePagePage : WebDriverExtensions
  {
    public HomePagePage(IWebDriver driver)
        : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    #region Identify elements locators

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//h1[@class='app-heading'and text()='Statements']")]
    public IWebElement HomePageTitle { get; set; }

    [FindsBy(How = How.CssSelector, Using = "a[data-attr='selector-handle-statementgroups']")]
    public IWebElement StatementGroupLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//dt[@data-attr='disctribution-code']")]
    public IWebElement DistCode { get; set; }
 
    [FindsBy(How = How.XPath, Using = "//h2/span[@class='highlight']")]
    public IWebElement SocietyName { get; set; }

    [FindsBy(How = How.XPath, Using = "//dl[2]/h2[@data-attr='statement-date']")]
    public IWebElement StatementID { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//dt[2][@class='member-profile__primary-list-term']")]
    public IWebElement CaeIpi { get; set; }
  
    [FindsBy(How = How.XPath, Using = "//div[@id='root']//dl[1]/h3[@data-attr='statement-royalty-earner']")]
    public IWebElement MemIpiName { get; set; }

    [FindsBy(How = How.XPath, Using = "//dd[@data-attr='royalty-ipi-number']")]
    public IWebElement MemIPINum { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//div[1]/a/span[@class='text']")]
    public IWebElement OpenToggle { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//div[2]/a/span[@class='text']")]
    public IWebElement CloseToggle { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//h3[@class='nop__heading']")]
    public IWebElement NOP { get; set; }

    [FindsBy(How = How.XPath, Using = "//h1[@data-attr='statement-amount']")]
    public IWebElement RoyaltyAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//section/dl[1]/dt[@data-attr='nop-earning-line-amount']")]
    public IWebElement PerfRoyaltyTotal { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//section[1]/dl[2]/dt[@data-attr='nop-earning-line-amount']")]
    public IWebElement Vat { get; set; }

    [FindsBy(How = How.XPath, Using = "//section[2]/h3[@data-label='paidas']")]
    public IWebElement PaidAs { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//a[contains(@href,'statements')]")]
    public IWebElement AllStatementsLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//a[contains(@href,'analytics')]")]
    public IWebElement AnalyticsLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//a[contains(@href,'royalty') and ./text()='Royalty Payments']")]
    public IWebElement RoyalStatementsLink { get; set; }

    [FindsBy(How = How.CssSelector, Using = "h3")]
    public IWebElement PageHeaderTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Earning works')]")]
    public IWebElement RoyaltyText { get; set; }

    [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'All statements')]")]
    public IWebElement AllStatementsText { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='all-statements__options']/div[@class='all-statements__memberships'][1]")]
    public IWebElement MembershipDropDown { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@data-attr='Filter-toggle']")]
    public IWebElement Filterbutton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@data-attr='Sort-toggle']")]
    public IWebElement Sortbutton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@data-attr='layout-toggle-card']")]
    public IWebElement CardViewButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@data-attr='layout-toggle-list']")]
    public IWebElement ListViewButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@data-attr='Filter-toggle']")]
    public IWebElement FilterToggleButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div/div[4]//h3[@class='statement-card__date']")]
    public IWebElement StmtCardDateYear { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='content-container']/div/h3")]
    public IWebElement NoticeHeaderNoStmts { get; set; }

    [FindsBy(How = How.XPath, Using = "(//h3[@class='statement-card__date'] ) [1]")]
    public IWebElement SingleStmtCardHeader { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='statement-card__content']/div/h3[1]")]
    public IWebElement FirstStmtYear { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='accordion-title']")]
    public  IWebElement AccordianTitle { get; set; }

    #endregion

    #region Perform operations on the elements
    public string GetHomePageTitle()
    {
      SendKeys(Keys.Escape);
      return GetElementText(HomePageTitle);

    }
    public string GetDistCode()
    {
      Thread.Sleep(1000);
      return GetElementText(DistCode);
    }
    public string GetSocietyName()
    {
      Thread.Sleep(1000);
      return GetElementText(SocietyName);
    }
    public string GetStatementID()
    {
      Thread.Sleep(1000);
      return GetElementText(StatementID);
    }
    public string GetRoyaltyAmount()
    {
      Thread.Sleep(1000);
      return GetElementText(RoyaltyAmount);
    }
    public string GetCaeIpi()
    {
      Thread.Sleep(1000);
      return GetElementText(CaeIpi);
    }
    public string GetMemIpiName()
    {
      SendKeys(Keys.Escape);
      WaitForPresence(MemIpiName);
      return GetElementText(MemIpiName);
    }
    public void ClickOpenToggle()
    {
      Thread.Sleep(2000);
      SafeClick(OpenToggle);
    }
    public string GetNOP()
    {
      Thread.Sleep(1000);
      return GetElementText(NOP);
    }
    public string GetPerfRoyaltyTotal()
    {
      Thread.Sleep(1000);
      return GetElementText(PerfRoyaltyTotal);
    }
    public string GetVat()
    {
      Thread.Sleep(1000);
      return GetElementText(Vat);
    }
    public string GetPaidAs()
    {
      Thread.Sleep(1000);
      return GetElementText(PaidAs);
    }
    public void ClickCloseToggle()
    {
      SafeClick(CloseToggle);
    }
    public void ClickAllStatementsLink()
    {
      SafeClick(AllStatementsLink);
    }
    public void ClickRoyalStatementsLink()
    {
      SafeClick(RoyalStatementsLink);
    }
    public void ClickAnalyticsLink()
    {
      SafeClick(AnalyticsLink);
    }
    public string GetRoyaltyText()
    {
      Thread.Sleep(1000);
      return GetElementText(RoyaltyText);
    }

    public string GetAllStatementText()
    {
      SendKeys(Keys.Escape);
      return GetElementText(AllStatementsText);
    }

    public bool IsLoggedIn()
    {
      //Thread.Sleep(1000);
      return DoesElementExist(HomePageTitle);
    }

    public string GetMemIPINumber()
    {
      Thread.Sleep(1000);
      return GetElementText(MemIPINum);
    }
    public string GetPopulatedUserMemDropdown()
    {
      return GetElementText(MembershipDropDown);
    }
    public string GetFilterButtontext()
    {
      return GetElementText(Filterbutton);
    }

    public string GetSortButtonText()
    {
     return GetElementText(Sortbutton);
    }
    public bool IsCardViewToggleBtnDisplayed()
    {
      return DoesElementExist(CardViewButton);
    }
    public bool IsListViewToggleBtnDisplayed()
    {
      return DoesElementExist(ListViewButton);
    }
    public bool IsMembersDropDownDisplayed()
    {
      return DoesElementExist(MembershipDropDown);
    }
    public string GetStatementGroup()
    {
      return GetElementText(StatementGroupLink);
    }
    public void ClickFilterToggleBtn()
    {

      SendKeys(Keys.Escape);
      SafeJavaScrollToElement(FilterToggleButton);
      //MoveToElement(FilterToggleButton);
      SafeJavaScriptClick(FilterToggleButton);
      Thread.Sleep(3000);
      SendKeys(Keys.Escape);
    }
    public string GetStmtDateandYear()
    {
      Thread.Sleep(1000);
      SendKeys(Keys.Escape);
      return GetElementText(StmtCardDateYear);
    }

    public string GetNoticeHeader()
    {
      Thread.Sleep(1000);
      SendKeys(Keys.Escape);
      return GetElementText(NoticeHeaderNoStmts);
    }
    public string GetSignleStmtCard()
    {

      return GetElementText(SingleStmtCardHeader);
    }
    public string GetFirstStmtYear()
    {
      return GetElementText(FirstStmtYear);
    }

    public void ClickSortButton()
    {
      SafeJavaScrollToElement(Sortbutton);
      SafeJavaScriptClick(Sortbutton);
      SendKeys(Keys.Escape);
    }

    public void ClickListViewButton()
    {
      SafeJavaScrollToElement(ListViewButton);
      SafeJavaScriptClick(ListViewButton);
      SendKeys(Keys.Escape);
    }

    public string GetAccordianTitle()
    {
      return GetElementText(AccordianTitle);
    }
  }
}

#endregion