﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OlsUiTests.Pages
{
 internal class BreadCrumbPage : WebDriverExtensions
  {

    public BreadCrumbPage(IWebDriver driver) :base (driver)
    {
      PageFactory.InitElements(driver, this);
    }
    
    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Clubland TV Non-Primetime')]")]
    public IWebElement BreadCrumbAccordianlink { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Television')]")]
    public IWebElement BreadCrumbUsageLink { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@id, 'breadcrumb')]/ul/li) [3]")]
    public IWebElement BreadCrumbPRSLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'All Statements')]")]
    public IWebElement AllStmtsBreadCrumbLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//h2[contains(@class,'title-section__title')]/a")]
    public IWebElement BackButton { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[@class='flex-row'])[1]")]
    public IWebElement FirstUsageWorkRow { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Your Song')]")]
    public IWebElement BreadCrumbActiveUsageSongTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Clubland TV Non-Primetime')]")]
    public IWebElement BreadCrumbActiveAccTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Television')]")]
    public IWebElement BreadCrumbActiveUsageTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'All statements')]")]
    public IWebElement HeaderTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[contains(text(),'PRS August 2018')]")]
    public IWebElement BreadCrumbActivePRSTitle { get; set; }

    public void ClickBreadCrumbAccLink()
    {
      SafeJavaScrollToElement(BreadCrumbAccordianlink);
      Thread.Sleep(1000);
      SafeJavaScriptClick(BreadCrumbAccordianlink);
    }

    public void ClickBreadCrumbUsageLink()
    {
      SafeJavaScrollToElement(BreadCrumbUsageLink);
      SafeJavaScriptClick(BreadCrumbUsageLink);
    }

    public void ClickBreadCrumbPrsLink()
    {
      SafeJavaScrollToElement(BreadCrumbPRSLink);
      SafeJavaScriptClick(BreadCrumbPRSLink);
    }

    public void ClickBreadCrumbPRSLink()
    {
      SafeJavaScrollToElement(BreadCrumbPRSLink);
      SafeJavaScriptClick(BreadCrumbPRSLink);
    }

    public void ClickAllStmtsBreadCrumbLink()
    {
      SafeJavaScrollToElement(AllStmtsBreadCrumbLink);
      SafeJavaScriptClick(AllStmtsBreadCrumbLink);
    }

    public string GetHeaderTitle()
    {
      WaitForPresence(HeaderTitle);
      return GetElementText(HeaderTitle);
    }

    public string GetActiveAccordianTitle()
    {
      WaitForPresence(BreadCrumbActiveAccTitle);
      return GetElementText(BreadCrumbActiveAccTitle);
    }

    public string GetActiveUsageTitle()
    {
      WaitForPresence(BreadCrumbActiveUsageTitle);
      return GetElementText(BreadCrumbActiveUsageTitle);
    }
    public string GetActivePRSTitle()
    {
      Thread.Sleep(1000);
      SafeJavaScrollToElement(BreadCrumbPRSLink);
      return GetElementText(BreadCrumbPRSLink);
    }
    public string GetActiveBreadCrumbActiveUsageSongTitle()
    {
      WaitForPresence(BreadCrumbActiveUsageSongTitle);
      return GetElementText(BreadCrumbActiveUsageSongTitle);
    }

    public  string GetBackBtn()
    {
      return GetElementText(BackButton);
    }

    public void ClickBackButton()
    {
      ExecuteTask(() =>
     {
       SafeJavaScrollToElement(BackButton);
       SafeJavaScriptClick(BackButton);

     });
    }
  }
}
