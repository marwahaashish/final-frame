﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OlsUiTests.Pages
{
  internal class EarningAllWorksUsageCardPage : WebDriverExtensions
  {
    public EarningAllWorksUsageCardPage(IWebDriver driver)
        : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }
    
    [FindsBy(How = How.XPath, Using = "//div[@id='root']//div[@class='table-body']/div[1]")]
    public IWebElement SingleWork { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='overview swp-overview']/div[2]/h1")]
    public IWebElement WorksTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='code']")]
    public IWebElement WorkNum { get; set; }

    [FindsBy(How = How.XPath, Using = "//h2[@class='share']")]
    public IWebElement YourShare { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='parties']/span[1]")]
    public IWebElement IP1 { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='modal-wrapper']//div/ul/li[2]/span[2]")]
    public IWebElement IP2 { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='modal-wrapper']//div/ul/li[3]/span[2]")]
    public IWebElement IP3 { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='modal-wrapper']//div/ul/li[4]/span[2]")]
    public IWebElement IP4 { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='swp-royalty']/div/div[3]")]
    public IWebElement TotalRoyalty { get; set; }

    [FindsBy(How = How.XPath, Using = "//dd[@data-attr='work-usage-territory']")]
    public IWebElement Usage { get; set; }

    [FindsBy(How = How.XPath, Using = "//dd[@data-attr='work-usage-region']")]
    public IWebElement Region { get; set; }

    [FindsBy(How = How.XPath, Using = "//dd[@data-attr='work-usage-production']")]
    public IWebElement Production { get; set; }

    [FindsBy(How = How.XPath, Using = "//dd[@data-attr='work-usage-date']")]
    public IWebElement Period { get; set; }

    [FindsBy(How = How.XPath, Using = "//dd[@data-attr='work-usage-time']")]
    public IWebElement Duration { get; set; }

    [FindsBy(How = How.XPath, Using = "//dd[@data-attr='work-usage-performance']")]
    public IWebElement Performances { get; set; }

    [FindsBy(How = How.XPath, Using = "//dd[@data-attr='work-usage-amount']")]
    public IWebElement Subtotal { get; set; }


    public void ClickSingleWork()
    {
      Thread.Sleep(4000);
      ExecuteTask(() =>
      {
        SafeJavaScriptClick(SingleWork);
        //_driver.SwitchTo().Window(_driver.WindowHandles.Last());
      });
    }

    public string GetWorksTitle(string WorkTitle)
    {
      return GetElementText(WorksTitle);
    }

    public string GetWorkNum()
    {
        return GetElementText(WorkNum);
    }
    public bool IsWorkNumDisplayed(string WorkNumber)
    {
      string SWNum = "T9210705445";
      string sub = SWNum.Substring(0, 11);
      if (SWNum.Equals(WorkNumber))
      {
        Console.WriteLine("Substring: {0}", sub);
        
      }
      else
      {
        Console.WriteLine("Work number not found");
      }
      return DoesElementExist(WorkNum);
    }

    public bool IsShareDisplayed(string Share)
    {
      string WorkShare = "50.00%";
      string sub = WorkShare.Substring(0, 6);
      if(Share.Equals(WorkShare))
      {
        Console.WriteLine("Substring: {0}", sub);

      }
      else
      {
        Console.WriteLine("Work share not found");
      }
      return DoesElementExist(YourShare);
    }
    public bool IsInterestedPartyMemberNameDisplayed(string IP1)
    {
      string PartyMemberName = "Sheeran Edward Christopher";
      string sub = PartyMemberName.Substring(0, 25);
      if (PartyMemberName.Equals(IP1))
      {
        Console.WriteLine("Substring: {0}", sub);

      }
      else
      {
        Console.WriteLine("Interested party member name not found");
      }
      return DoesElementExist(YourShare);
    }

      public string GetYourShare()
    {
      return GetElementText(YourShare);
    }

    public string GetIP1()
    {
      return GetElementText(IP1);
    }

    public string GetIP2()
    {
      return GetElementText(IP2);
    }

    public string GetIP3()
    {
      return GetElementText(IP3);
    }

    public string GetIP4()
    {
      return GetElementText(IP4);
    }

    public string GetTotalRoyalty()
    {
      return GetElementText(TotalRoyalty);
    }

    public string GetUsage()
    {
      return GetElementText(Usage);
    }

    public string GetRegion()
    {
      return GetElementText(Region);
    }

    public string GetProduction()
    {
      SafeJavaScrollToElement(Production);
      return GetElementText(Production);
    }

    public string GetPeriod()
    {
      return GetElementText(Period);
    }

    public string GetDuration()
    {
      return GetElementText(Duration);
    }

    public string GetPerformances()
    {
      return GetElementText(Performances);
    }

    public string GetSubtotal()
    {
      return GetElementText(Subtotal);
    }

  }
}
