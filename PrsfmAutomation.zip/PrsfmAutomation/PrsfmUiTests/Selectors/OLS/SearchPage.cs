﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.OLS
{
  internal class SearchPage : WebDriverExtensions
  {
    public SearchPage(IWebDriver driver) : base (driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//*[contains(@data-attr, 'statement-search-toggle__button')]")]
    public IWebElement SearchToggleButton { get; set; }

    [FindsBy(How = How.XPath, Using = "(//section[contains(@class, 'exploration-block-section title-section')])[2]")]
    public IWebElement StatmentSearch { get; set; }

    [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'No records found')]")]
    public IWebElement NoResultsNoticeHeading { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Your Song')]")]
    public IWebElement SearchResultTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='overview swp-overview']//h1")]
    public IWebElement SWPOverViewHeader { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(@class, 'statement-search-close__button')]")]
    public IWebElement SearchCloseButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Earning countries')]")]
    public IWebElement EarningCountries { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(text(), 'Clubland TV Non-Primetime')]")]
    public IWebElement UsageFirstSearchResultTitle { get; set; }

    [FindsBy (How = How.XPath, Using = "//div[@class='content']/div/text()")]
    public IWebElement SearchResultEarningCountry { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(text(),'No territories found')]")]
    public IWebElement NoTerritoiresFound { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(text(),'No usages were found')]")]
    public IWebElement NoUsagesFound { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Only works that have earned royalties in this statement are listed')]")]
    public IWebElement NoworksValidSearchErrorNotification { get; set; }

    public void ClickSearchButton()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(SearchToggleButton);
        SafeJavaScriptClick(SearchToggleButton);
        SendKeys(Keys.Escape);

      });
    }

    public void ClickStatementSearchWithInvalidTerm(string SearchTerm)
    {
      ExecuteTask(() =>
      {
        SendKeys(Keys.Escape); 
        SafeJavaScrollToElement(SearchToggleButton);
        SafeJavaScriptClick(SearchToggleButton);
        SendKeys(Keys.Escape);
        Thread.Sleep(1000);
        SafeClick(StatmentSearch);
        Thread.Sleep(2000);
        SendKeys(Keys.Escape);
        EnterSearchTerm(SearchTerm);
        
      });
      
    }
    public void ClearSearchResultAndValidSearch(string SearchTerm)
    {
      Thread.Sleep(1000);
      ExecuteTask(() =>
      {
        SafeClick(SearchCloseButton);    
        SendKeys(Keys.Escape);
        WaitForPresence(StatmentSearch);
        SafeClick(StatmentSearch);
        EnterSearchTerm(SearchTerm);
        SendKeys(Keys.Escape);
        Thread.Sleep(2000);
      });

    }
    public void EnterSearchTerm( string SearchTerm)
    {     
      SendKeys(Keys.Escape);
      Thread.Sleep(2000);
      SendKeys(SearchTerm);
    }

    public string GetNoResultsHeader()
    {
      WaitForPresence(NoResultsNoticeHeading);
      return GetElementText(NoResultsNoticeHeading);
    }

    public string GetSearchResultTitle()
    {
      return GetElementText(SearchResultTitle);
    }

    public string GetSWPOverViewHeaderTitle()
    {
      return GetElementText(SWPOverViewHeader);
    }

    public string GetEarningCountries()
    {
      SafeJavaScrollToElement(EarningCountries);
      WaitForPresence(EarningCountries);
      return GetElementText(EarningCountries);
    }

    public string GetUsageFirstResultTitle()
    {
      return GetElementText(UsageFirstSearchResultTitle);
    }

    public string GetSearchResultEarningCountry()
    {
      return GetElementText(SearchResultEarningCountry);
    }

    public string GetTerritoriesValidSearchErrorNotification()
    {
      WaitForPresence(NoTerritoiresFound);
      SafeJavaScrollToElement(NoTerritoiresFound);     
      return GetElementText(NoTerritoiresFound);
    }

    public string GetUsagesValidSearchErrorNotification()
    {
      WaitForPresence(NoUsagesFound);
      SafeJavaScrollToElement(NoUsagesFound);
      return GetElementText(NoUsagesFound);
    }

    public string GetWorksValidSearchErrorNotification()
    {
      WaitForPresence(NoworksValidSearchErrorNotification);
      SafeJavaScrollToElement(NoworksValidSearchErrorNotification);
      return GetElementText(NoworksValidSearchErrorNotification);
    }
  }
}
