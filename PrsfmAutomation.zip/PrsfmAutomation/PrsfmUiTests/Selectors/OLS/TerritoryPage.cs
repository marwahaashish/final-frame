﻿
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.OLS
{

  internal class TerritoryPage : WebDriverExtensions
  {
    public TerritoryPage(IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//div[@class='map__container']")]
    public IWebElement MapContainer { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='map__key']")]
    public IWebElement MapKey { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Earning countries')]")]
    public IWebElement EarningCountries { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Subtotal')]")]
    public IWebElement SubTotal { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='statement-search-toggle']")]
    public IWebElement SearchButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='content']/div[1]//p")]
    public IWebElement FirstRowPercentage { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='content']")]
    public IWebElement EarningCountryFirstRow { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='total-amount']")]
    public IWebElement FirstrowSubtotal { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='table-body']/div[1]")]
    public IWebElement FirstTerritoryRow { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='overview swp-overview']//h1")]
    public IWebElement SWPOverViewHeader { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[@class='share-btn']")]
    public IWebElement ShareVarianceBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='share-variance-popup']/h3")]
    public IWebElement ShareVariancePopUpheader { get; set; }

    [FindsBy(How = How.XPath, Using = "(//table[contains(@class, 'share-variance-table')]/tbody/tr) [1]")]
    public IWebElement ShareVarinaceTableFirstRow { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(@class, 'parties')]")]
    public IWebElement IP { get; set; }

    [FindsBy(How = How.XPath, Using = "//h2[contains(@class, 'share')]")]
    public IWebElement FirstrowShare { get; set; }

    public bool IsMapDisplays()
    {
      return DoesElementExist(MapContainer);
    }

    public string GetEarningCountries()
    {
      SafeJavaScrollToElement(EarningCountries);
      WaitForPresence(EarningCountries);
      return GetElementText(EarningCountries);
    }

    public string GetSubtotal()
    {
      SafeJavaScrollToElement(SubTotal);
      WaitForPresence(SubTotal);
      return GetElementText(SubTotal);
    }

    public string GetFirstRowPercentage()
    {
      WaitForPresence(FirstRowPercentage);
      return GetElementText(FirstRowPercentage);
    }

    public string GetFirstRowSubtotal()
    {
      WaitForPresence(FirstrowSubtotal);
      return GetElementText(FirstrowSubtotal);
    }

    public void ClickEarningCountriesCol()
    {

      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(EarningCountries);
        SafeJavaScriptClick(EarningCountries);
        SendKeys(Keys.Escape);
      });
    }
   public void ClickSubtotalColumn()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(SubTotal);
        SafeJavaScriptClick(SubTotal);
        SendKeys(Keys.Escape);
      });
    }
    public void ClickFirstEarningCountryRow()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(EarningCountryFirstRow);
        SafeJavaScriptClick(EarningCountryFirstRow);
        SendKeys(Keys.Escape);
        ClickFirstTerritoryWorkRow();
      });
    }

    public void ClickFirstTerritoryWorkRow()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(FirstTerritoryRow);
        SafeJavaScriptClick(FirstTerritoryRow);
        SendKeys(Keys.Escape);

      });
    }

    public string GetSWPOverViewHeader()
    {
      WaitForPresence(SWPOverViewHeader);
      return GetElementText(SWPOverViewHeader);
    }

    public string GetShareVarianceButton()
    {
      return GetElementText(ShareVarianceBtn);
    }
    public void ClickShareVarianceBtn()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(ShareVarianceBtn);
        SafeJavaScriptClick(ShareVarianceBtn);
        SendKeys(Keys.Escape);

      });
    }

    public string GetSharevariancePopUpHeader()
    {
      WaitForPresence(ShareVariancePopUpheader);
      return GetElementText(ShareVariancePopUpheader);
    }

    public void ClickShareVarinaceFirstRow()
    {
      ExecuteTask(() =>
      {       
        SafeJavaScrollToElement(ShareVarinaceTableFirstRow);
        SafeJavaScriptClick(ShareVarinaceTableFirstRow);
        Thread.Sleep(1000);
        SendKeys(Keys.Escape);

      });
    }

    public string GetInterestedParties()
    {
      return GetElementText(IP);
    }
    public bool IsShareDisplayed(string Share)
    {
      string ShareVal = "23.75%";
      string sub = ShareVal.Substring(0, 6);
      if (ShareVal.Equals(Share))
      {
        Console.WriteLine("Substring: {0}", sub);

      }
      else
      {
        Console.WriteLine("FirstrowShare not found");
      }
      return DoesElementExist(FirstrowShare);
    }

  }
}
