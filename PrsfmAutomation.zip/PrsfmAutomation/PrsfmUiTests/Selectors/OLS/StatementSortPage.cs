﻿using OpenQA.Selenium;
using PrsfmUiTests.Helpers;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace PrsfmUiTests.Selectors.OLS
{
  internal class StatementSortPage : WebDriverExtensions
  {

    public StatementSortPage(IWebDriver driver) : base(driver)
    {

      PageFactory.InitElements(driver, this);

    }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Newest [date]')]")]
    public IWebElement SortListNewestdate { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Oldest [date]')]")]
    public IWebElement SortListOldestdate { get; set; }

    public void ClickOldestSortListBtn()
    {
      ExecuteTask(() =>
      {
        MoveToElement(SortListOldestdate);
        SafeClick(SortListOldestdate);
        Thread.Sleep(2000);
        SendKeys(Keys.Escape);

      });

    }
    public void ClickNewestSortListBtn()
    {
      ExecuteTask(() =>
      {
        MoveToElement(SortListNewestdate);
        SafeClick(SortListNewestdate);
        Thread.Sleep(2000);
        SendKeys(Keys.Escape);

      });

    }
  }
}
