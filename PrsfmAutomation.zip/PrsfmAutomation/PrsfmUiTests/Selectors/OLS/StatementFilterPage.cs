﻿using OpenQA.Selenium;
using PrsfmUiTests.Helpers;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using OpenQA.Selenium.Support.UI;


namespace PrsfmUiTests.Selectors.OLS
{
  internal class StatementFilterPage : WebDriverExtensions
  {

    public StatementFilterPage(IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }
   
    [FindsBy(How = How.XPath, Using = "//div[@class='filter-list']")]
    public IWebElement FilterList { get; set; }

    [FindsBy(How = How.XPath, Using = "//input[@data-checkbox-type='society-prs']")]
    public IWebElement PRSSocietyCheckBox { get; set; }

    [FindsBy(How = How.XPath, Using = "//input[@data-checkbox-type='society-mcps']")]
    public IWebElement MCPSSocietyCheckbox { get; set; }

    [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Statement type')]")]
    public IWebElement StatementFiltterType { get; set; }

    [FindsBy(How = How.XPath, Using = "//input[@data-checkbox-type='statement-main statement']")]
    public IWebElement MainStatementCheckbox { get; set; }

    [FindsBy(How = How.XPath, Using = "//input[@data-checkbox-type='statement-mini statement']")]
    public IWebElement MiniStatementCheckbox { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-secondary filter-list__action--clear']")]
    public IWebElement ClearAllFilters { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary filter-list__action--apply']")]
    public IWebElement DoneButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//option[contains(text(), 'All Years')]")]
    public IWebElement AllYearsDropdown { get; set; }

    [FindsBy(How = How.XPath, Using = "//select[contains(@class, 'date-filter__select')]//*[contains(text(),'2018')]")]
    public IWebElement AllYearDropDownFirstValue { get; set; }

    [FindsBy(How = How.XPath, Using = "//select[contains(@class, 'date-filter__select')]//*[contains(text(),'2016')]")]
    public IWebElement AllYearDropDownSecondValue { get; set; }

    [FindsBy(How = How.XPath, Using = "//option[contains(text(), 'All Months')]")]
    public IWebElement AllMonthsDropDown { get; set; }

    [FindsBy(How = How.XPath, Using = "//select[contains(@class, 'date-filter__select')]//*[contains(text(),'June')]")]
    public IWebElement AllMonthsDropDownFirstValue { get; set; }

    [FindsBy(How = How.XPath, Using = "//select[@data-attr='date-filter-month']/option[3]")]
    public IWebElement AllMonthsDropDownSecondValue { get; set; }

    [FindsBy(How = How.XPath, Using = "//h3[contains(@class, 'society-filter__title')]) [3]")]
    public IWebElement YearDropDownTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class,'filter-list')])[4]")]
    public IWebElement YearFilterList { get; set; }

    public void UnCheckMCPSSociety()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(MCPSSocietyCheckbox);
        SafeJavaScriptClick(MCPSSocietyCheckbox);
      });
    }

    public string GetFilterList()
    {
      return GetElementText(FilterList);
    }

    public void ClickStatementFilter()
    {
      
      SafeJavaScrollToElement(StatementFiltterType);
      SafeJavaScriptClick(StatementFiltterType);
      Thread.Sleep(3000);

    }

    public void UncheckMainStatement()
    {
       ExecuteTask (() =>
      {
        SafeJavaScrollToElement(MainStatementCheckbox);
        SafeJavaScriptClick(MainStatementCheckbox);
      });
    }

    public void UncheckMiniStatement()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(MiniStatementCheckbox);
        SafeJavaScriptClick(MiniStatementCheckbox);
      });
    }

    public void ClickDoneButton()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(DoneButton);
        SafeJavaScriptClick(DoneButton);
      });
    }

    public string SelctYearsFromDropDown(string year)
    {
      ExecuteTask(() =>
        {
         SafeJavaScrollToElement(AllYearsDropdown);
         JavaScriptSelectFromDropDownList(year);         
      });
      return GetElementText(AllYearsDropdown);
    }

    public bool IsFilterlistDisplayed()
    {
      SendKeys(Keys.Escape);
      if (FilterList != null)
      {
        Console.WriteLine("Filter list displayed");
      }
      else
      {
        Console.WriteLine("Filter list is not displayed");
      }

      return DoesElementExist(FilterList);
    }
    public bool IsPRSSocietyFilterChecked()
    {
      if (PRSSocietyCheckBox.Selected)
      {
        Console.WriteLine("PRS SocietyCheckBox Selected");
      }
      else
      {
        Console.WriteLine("PRS SocietyCheckBox not Selected");
      }

      return DoesElementExist(PRSSocietyCheckBox);
    }
    public bool IsMCPSSocietyFilterChecked()
    {
      if (MCPSSocietyCheckbox.Selected)
      {
        Console.WriteLine("MCPS SocietyCheckBox Selected");
      }
      else
      {
        Console.WriteLine("MCPS SocietyCheckBox not Selected");
      }

      return DoesElementExist(MCPSSocietyCheckbox);
    }
    public bool IsMainStatementTypeCheckboxSelected()
    {
      if (MainStatementCheckbox.Selected)
      {
        Console.WriteLine(" Main statement filter Selected");
      }
      else
      {
        Console.WriteLine("Main statement not Selected");
      }

      return DoesElementExist(MainStatementCheckbox);
    }
    public bool IsMiniStatementTypeCheckboxSelected()
    {
      if (MiniStatementCheckbox.Selected)
      {
        Console.WriteLine(" Mini statement filter Selected");
      }
      else
      {
        Console.WriteLine("Mini statement not Selected");
      }

      return DoesElementExist(MiniStatementCheckbox);
    }
    public void UncheckMainStmtFilter()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(MainStatementCheckbox);
        SafeJavaScriptClick(MainStatementCheckbox);
        ClickFilterDoneBtn();
      });

    }
     public void ClickFilterDoneBtn()
     { 
      SafeJavaScrollToElement(DoneButton);
      SafeJavaScriptClick(DoneButton);
     }
    public void UncheckMiniStmtFilter()
    {
      SafeJavaScriptClick(MiniStatementCheckbox);
      Thread.Sleep(1000);
      ClickFilterDoneBtn();
    }

    public void UncheckPRSSocietyStmts()
    {
      MoveToElement(PRSSocietyCheckBox);
      SafeJavaScriptClick(PRSSocietyCheckBox);
      Thread.Sleep(2000);
      ClickFilterDoneBtn();

    }

    public void ClickYear(string Year)
    {
      ExecuteTask(() =>
      {
     
        SendKeys(Keys.Escape);
        SafeJavaScrollToElement(AllYearsDropdown);
        SafeJavaScriptClick(AllYearsDropdown);
        SendKeys(Keys.Escape);
        Thread.Sleep(2000);
        SelectFromDropDownList(AllYearDropDownFirstValue, Year);
        Thread.Sleep(2000);
    
      });
    }
      public void ClickMonth(string Month)
      {
        ExecuteTask(() =>
        {
         
          SendKeys(Keys.Escape);
          SafeJavaScrollToElement(AllMonthsDropDown);
          SafeJavaScriptClick(AllMonthsDropDown);
          SendKeys(Keys.Escape);
          SelectFromDropDownList(AllMonthsDropDownFirstValue, Month);
          Thread.Sleep(2000);
          ClickFilterDoneBtn();
        });




      }


    }

}
