﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Threading;

namespace OlsUiTests.Pages
{
  internal class AuthorizationPage : WebDriverExtensions
  {
    public AuthorizationPage(IWebDriver driver)
        : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.Id, Using = "SecurityChallenge_Password")]
    public IWebElement PasswordTextbox { get; set; }

    [FindsBy(How = How.XPath, Using = "//label[@for='SecurityChallenge_SecurityAnswerCharacter1']")]
    public IWebElement SecurityQuestionWithUniqueNumbers { get; set; }

    [FindsBy(How = How.Id, Using = "SecurityChallenge_SecurityAnswerCharacter1")]
    public IWebElement SecurityChallengeTextOne { get; set; }

    [FindsBy(How = How.Id, Using = "SecurityChallenge_SecurityAnswerCharacter2")]
    public IWebElement SecurityChallengeTextTwo { get; set; }

    [FindsBy(How = How.Id, Using = "SecurityChallenge_SecurityAnswerCharacter3")]
    public IWebElement SecurityChallengeTextThree { get; set; }

    [FindsBy(How = How.XPath, Using = "//form/button[@class='btn btn-primary']")]
    public IWebElement Submit { get; set; }

    //[FindsBy(How = How.XPath, Using = "//form/button[@type='submit' and text()='Submit']")]
    //public IWebElement Submit { get; set; }


    public void EnterPassword(string password)
    {
      SafeSendKeys(PasswordTextbox, password);
    }

    public void EnterGenericPassword()
    {
      SafeSendKeys(PasswordTextbox, DataSource.GenericLoginCredentials.password);
    }

    private void EnterSecutityCharacters(string a, string b, string c)
    {
      var uniqueNumbers = SecurityQuestionWithUniqueNumbers.Text;

      SecurityChallengeTextOne.SendKeys(a);
      SecurityChallengeTextTwo.SendKeys(b);
      SecurityChallengeTextThree.SendKeys(c);
      Console.WriteLine("*** Unique characters: " + uniqueNumbers);
    }

    public void AnswerSecurityQiestion()
    {
      new WebDriverExtensions(_driver).ElementIsDisplayed(SecurityQuestionWithUniqueNumbers);

      var uniqueNumbers = SecurityQuestionWithUniqueNumbers.Text;

      // Beginning with 1
      if (uniqueNumbers.Contains("1, 2, 3"))
      {
        var a = "t"; var b = "h"; var c = "o";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("1, 2, 4"))
      {
        var a = "t"; var b = "h"; var c = "m";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("1, 2, 5"))
      {
        var a = "t"; var b = "h"; var c = "a";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("1, 2, 6"))
      {
        var a = "t"; var b = "h"; var c = "s";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("1, 3, 4"))
      {
        var a = "t"; var b = "o"; var c = "m";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("1, 3, 5"))
      {
        var a = "t"; var b = "o"; var c = "a";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("1, 3, 6"))
      {
        var a = "t"; var b = "o"; var c = "s";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("1, 4, 5"))
      {
        var a = "t"; var b = "m"; var c = "a";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("1, 4, 6"))
      {
        var a = "t"; var b = "m"; var c = "s";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("1, 5, 6"))
      {
        var a = "t"; var b = "a"; var c = "s";
        EnterSecutityCharacters(a, b, c);
      }

      // Beginning with 2
      else if (uniqueNumbers.Contains("2, 3, 4"))
      {
        var a = "h"; var b = "o"; var c = "m";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("2, 3, 5"))
      {
        var a = "h"; var b = "o"; var c = "a";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("2, 3, 6"))
      {
        var a = "h"; var b = "o"; var c = "s";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("2, 4, 5"))
      {
        var a = "h"; var b = "m"; var c = "a";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("2, 5, 6"))
      {
        var a = "h"; var b = "a"; var c = "s";
        EnterSecutityCharacters(a, b, c);
      }

      // Beginning with 3 or 4
      else if (uniqueNumbers.Contains("3, 4, 5"))
      {
        var a = "o"; var b = "m"; var c = "a";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("3, 4, 6"))
      {
        var a = "o"; var b = "m"; var c = "s";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("3, 5, 6"))
      {
        var a = "o"; var b = "a"; var c = "s";
        EnterSecutityCharacters(a, b, c);
      }
      else if (uniqueNumbers.Contains("4, 5, 6"))
      {
        var a = "m"; var b = "a"; var c = "s";
        EnterSecutityCharacters(a, b, c);
      }
      else
        Console.WriteLine("*** Unique characters not recognised: " + uniqueNumbers);

    }
    public void ClickSubmitBtnOnSecurity()
    {
      Thread.Sleep(2000);
      JavaScriptClick(Submit);
    }

    public void AnswerSecurityQuetionOne(string text1)
    {
      SafeSendKeys(SecurityChallengeTextOne, text1);
    }

    public void AnswerSecurityQuetionTwo(string text2)
    {
      SafeSendKeys(SecurityChallengeTextTwo, text2);
    }

    public void AnswerSecurityQuetionThree(string text3)
    {
      SafeSendKeys(SecurityChallengeTextThree, text3);
    }
  }
}
