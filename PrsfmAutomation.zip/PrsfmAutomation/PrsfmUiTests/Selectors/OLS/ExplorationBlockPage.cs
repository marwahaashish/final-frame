﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OlsUiTests.Pages
{
  internal class ExplorationBlockPage : WebDriverExtensions
  {
    public ExplorationBlockPage(IWebDriver driver)
        : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//div[@class='topworks-tabs__handle--tab']//h1[text()='Works']")]
    public IWebElement WorksTab { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//div[@class='topworks-tabs__handle--tab']//h1[text()='Usage']")]
    public IWebElement UsageTypeTab { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//div[@class='topworks-tabs__handle--tab']//h1[text()='Territory']")]
    public IWebElement TerritoryTab { get; set; }

    [FindsBy(How = How.XPath, Using = "//h2[contains(text(), 'Earning works')]")]
    public IWebElement EarningWorksPage { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//h2[text() = 'Top usage summary']")]
    public IWebElement UsageTypePage { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//h2[text() = 'Territory']")]
    public IWebElement TerritoryPage { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//tbody")]
    public IWebElement ExplorationWorksTable { get; set; }
   
    [FindsBy(How = How.XPath, Using = "//div[@id='root']//div/section[1]/div[@class='chart-container']")]
    public IWebElement ExplorationWorksGraph { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//a[@role='link' and text()='2']")]
    public IWebElement TablePageTwo { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//a[@role='link' and text()='5']")]
    public IWebElement TablePageFive { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Next page')]")]
    public IWebElement TableForwardArrow { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//a[@role='link' and text()='8']")]
    public IWebElement TablePageEight { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//tr[4]/td[1]/a/div[1]")]
    public IWebElement TableRowFourWorkTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//tr[4]/td[1]/a/div[2]/span[2]")]
    public IWebElement TableRowFourRoyaltyAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//tr[1]/td[1]/a/div[1]")]
    public IWebElement TableRowOneWorkTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//tr[1]/td[1]/a/div[2]/span[2]")]
    public IWebElement TableRowOneRoyaltyAmount { get; set; }
    
    [FindsBy(How = How.XPath, Using = "//div[@id='root']//section[1]/div/div//a[@data-attr='topworks-sort-toggle']")]
    public IWebElement SortToggle { get; set; }
   
    [FindsBy(How = How.XPath, Using = "//div[@id='root']//li[2]//a[@data-attr='sort-by-link']")]
    public IWebElement SortTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']//li[3][@data-attr-sort-by='amount']")]
    public IWebElement SortRoyalty { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']/div/div/div[2]//a[@data-attr-sort-direction='asc']")]
    public IWebElement SortAscending { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']/div/div/div[2]//a[2][@data-attr-sort-direction='desc']")]
    public IWebElement SortDescending { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@id='root']/div/div/div[2]//div[@class='table-sorter']")]
    public IWebElement TableSort { get; set; }

    [FindsBy(How = How.XPath, Using = "//div/a[@class='all-works-btn']")]
    public IWebElement AllWorksBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='stacked-bar-chart']/h4")]
    public IWebElement StackedBarchartHeader { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='usages-grid']/div[1]//h4")]
    public IWebElement UsageCardHeader { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[contains(@class,'works-chart__bars')]//*[1]")]
    public IWebElement FirstBarChartEarningAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[contains(@class,'works-chart__bars')]//*[2]")]
    public IWebElement SecondBarEarningAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[contains(@class,'works-chart__bars')]//*[3]")]
    public IWebElement ThirdBarEarningAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[contains(@class,'works-chart__bars')]//*[4]")]
    public IWebElement FourthBarEarningAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[contains(@class,'works-chart__bars')]//*[5]")]
    public IWebElement FifthBarEarningAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//section[contains(@class, 'exploration-block-section exploration-block--chart-section')]")]    
    public IWebElement WorkChartBars { get; set; }
    public void ClickWorksTab()
    {
      Thread.Sleep(1000);
      SafeJavaScriptClick(WorksTab);
      SendKeys(Keys.Escape);
    }

    public void ClickUsageTypeTab()
    {
      Thread.Sleep(1000);
      SafeJavaScriptClick(UsageTypeTab);
      SendKeys(Keys.Escape);
    }

    public void ClickTerritoryTab()
    {
      Thread.Sleep(1000);
      SafeJavaScriptClick(TerritoryTab);
      Thread.Sleep(1000);
      SendKeys(Keys.Escape);
      
    }

    public string GetEarningWorksPage()
    {
      return GetElementText(EarningWorksPage);
    }

    public string GetUsageTypePage()
    {
      Thread.Sleep(1000);
      return GetElementText(UsageTypePage);
    }

    public string GetTerritoryPage()
    {
      Thread.Sleep(1000);
      return GetElementText(TerritoryPage);
    }

    public bool isWorksTablePresent()
    {
      Thread.Sleep(1000);
      return DoesElementExist(ExplorationWorksTable);
    }

    public bool isWorksGraphPresent()
    {
      Thread.Sleep(1000);
      return DoesElementExist(ExplorationWorksGraph);

    }

    public void ClickPageTwo()
    {
      Thread.Sleep(1000);
      SafeJavaScriptClick(TablePageTwo);
      SendKeys(Keys.Escape);
    }

    public void ClickPageEight()
    {
      SafeJavaScriptClick(TablePageFive);
      SendKeys(Keys.Escape);
      JavaScriptClick(TableForwardArrow);
      SafeJavaScriptClick(TablePageEight);
      SendKeys(Keys.Escape);
    }

    public string GetRowFourWorksTitle()
    {
      return GetElementText(TableRowFourWorkTitle);
    }

    public string GetRowFourRoyaltyAmount()
    {
      return GetElementText(TableRowFourRoyaltyAmount);
    }

    public string GetRowOneWorkTitle()
    {
      Thread.Sleep(2000);
      return GetElementText(TableRowOneWorkTitle);
    }

    public string GetRowOneRoyaltyAmount()
    {
      Thread.Sleep(2000);
      return GetElementText(TableRowOneRoyaltyAmount);
    }

    public void SortByTitle()
    {
      Thread.Sleep(5000);
      SendKeys(Keys.Escape);
      MoveToElement(SortToggle);
      SafeJavaScriptClick(SortToggle);
      SendKeys(Keys.Escape);
      SafeJavaScriptClick(SortTitle);
    }

    public void SortByRoyalty()
    {
      Thread.Sleep(5000);
      SendKeys(Keys.Escape);
      MoveToElement(SortToggle);
      SafeJavaScriptClick(SortToggle);
      Thread.Sleep(5000);
      SafeJavaScriptClick(SortRoyalty);
    }

    public void ClickSortRoyaltyAscending()
    {
      //RefreshPage();
      Thread.Sleep(4000);
      SafeJavaScrollToElement(SortToggle);
      MoveToElement(SortToggle);
      SafeClick(SortToggle);
      SafeJavaScriptClick(SortToggle);
      SendKeys(Keys.Escape);
      SafeJavaScriptClick(SortAscending);
      Thread.Sleep(4000);
      
    }

    public void ClickSortTitleAscending()
    {
      Thread.Sleep(3000);
      SafeJavaScrollToElement(SortToggle);
      MoveToElement(SortToggle);
      SafeJavaScriptClick(SortToggle);
      SendKeys(Keys.Escape);
      SafeJavaScriptClick(SortAscending);
      Thread.Sleep(3000);
    }

    public void ClickSortRoyaltyDescending()
    {
      RefreshPage();
      Thread.Sleep(6000);
      SafeJavaScrollToElement(SortToggle);
      SafeClick(SortToggle);
      Thread.Sleep(8000);
      SafeJavaScriptClick(SortDescending);
    }

    public void ClickSortTitleDescending()
    {
      Thread.Sleep(3000);
      SafeJavaScrollToElement(SortToggle);
      SafeClick(SortToggle);
      SafeClick(SortDescending);
      Thread.Sleep(3000);
    }

    public void ClickAllWorksBtn()
    {
      Thread.Sleep(3000);
      SafeJavaScrollToElement(AllWorksBtn);
      SafeJavaScriptClick(AllWorksBtn);
      Thread.Sleep(1000);
      SendKeys(Keys.Escape);

    }

    public string GetStackBarHeader()
    {
      return GetElementText(StackedBarchartHeader);
    }

    public string GetUsageCardHeader()
    {
      return GetElementText(UsageCardHeader);
    }

    public void ClickUsageCard()
    {
      WaitForPresence(UsageCardHeader);
      ExecuteTask(() =>
        {
          SafeJavaScrollToElement(UsageCardHeader);
          SafeJavaScriptClick(UsageCardHeader);
          SendKeys(Keys.Escape);
        });
    }

    public void HoverOnWorksBarChart()
    {
      Thread.Sleep(1000);
      SendKeys(Keys.Escape);
      SafeJavaScrollToElement(WorkChartBars);
      MoveToElement(WorkChartBars);

    }

    public bool IsFirstbarEarningAmountDisplayed(string FirstBarEarAmount)
    {
      SendKeys(Keys.Escape);
      MoveToElement(FirstBarChartEarningAmount);
      Thread.Sleep(2000);
      String toolTipValue = FirstBarChartEarningAmount.GetAttribute("amount");
      if(toolTipValue.Equals(FirstBarEarAmount))
      {
        Console.WriteLine("Works graph firstbar amount displayed------>" + toolTipValue);
      }
      else
      {
        Console.WriteLine("FirstBar earning amount not displayed");
      }
      
      return DoesElementExist (FirstBarChartEarningAmount);
    }

    public bool IsSecondbarEarningAmountDisplayed(string SecondBarEarAmount)
    {
          
      MoveToElement(SecondBarEarningAmount);
      Thread.Sleep(2000);
      String toolTipValue = SecondBarEarningAmount.GetAttribute("amount");
      if (toolTipValue.Equals(SecondBarEarAmount))
      {
        Console.WriteLine("Works graph secondbar amount displayed---->" + toolTipValue);
      }
      else
      {
        Console.WriteLine("SecondBar earning amount not displayed");
      }

      return DoesElementExist(SecondBarEarningAmount);
    }
    public bool IsThirdbarEarningAmountDisplayed(string ThirdBarEarAmount)
    {

      MoveToElement(ThirdBarEarningAmount);
      Thread.Sleep(2000);
      String toolTipValue = ThirdBarEarningAmount.GetAttribute("amount");
      if (toolTipValue.Equals(ThirdBarEarAmount))
      {
        Console.WriteLine("Works graph thirdBar earning amount displayed---->" + toolTipValue);
      }
      else
      {
        Console.WriteLine("ThirdBar earning amount not displayed");
      }

      return DoesElementExist(ThirdBarEarningAmount);
    }

    public bool IsFourthbarEarningAmountDisplayed(string FourthBarEarAmount)
    {

      MoveToElement(FourthBarEarningAmount);
      Thread.Sleep(2000);
      String toolTipValue = FourthBarEarningAmount.GetAttribute("amount");
      if (toolTipValue.Equals(FourthBarEarAmount))
      {
        Console.WriteLine("Works graph fourthBar earning amount displayed---->" + toolTipValue);
      }
      else
      {
        Console.WriteLine("FourthBar earning amount not displayed");
      }

      return DoesElementExist(FourthBarEarningAmount);
    }

    public bool IsFifthbarEarningAmountDisplayed(string FifthBarEarAmount)
    {

      MoveToElement(FifthBarEarningAmount);
      Thread.Sleep(2000);
      String toolTipValue = FifthBarEarningAmount.GetAttribute("amount");
      if (toolTipValue.Equals(FifthBarEarAmount))
      {
        Console.WriteLine("Works graph fifthBar earning amount displayed---->" + toolTipValue);
      }
      else
      {
        Console.WriteLine("FifthBar earning amount not displayed");
      }

      return DoesElementExist(FifthBarEarningAmount);
    }

  }
}
