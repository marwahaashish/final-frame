﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.OLS
{
  internal class FileDownloadPage : WebDriverExtensions
  {
    public FileDownloadPage(IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//div[@class='ReactModal__Content ReactModal__Content--after-open modal-dialog']")]
    public IWebElement DownloadDialogModal { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='ReactModal__Content ReactModal__Content--after-open modal-dialog']//h3")]
    public IWebElement DialogModalTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "(//button[contains(text(),'Download')])[1]")]
    public IWebElement ModalDownloadButton { get; set; }

    [FindsBy(How = How.XPath, Using = "(//span[contains(text(),'Download')])[1]")]
    public IWebElement StmtFileDownload { get; set; }


    private readonly string FileDownloadPath = @"C:\\Users\\skumar\\Documents\\Downloads";
    public bool CheckFileDownloaded(string FileName)
    {
      SendKeys(Keys.Escape);
      //string folder = Environment.GetEnvironmentVariable("USERPROFILE") + "\\Documents\\Downloads";
      Thread.Sleep(4000);
      var firstFile = Directory.GetFiles(FileDownloadPath).FirstOrDefault
        (fp => fp.Contains(FileName));
      if (firstFile != null)
      {
        var fileInfo = new FileInfo(firstFile);
        var isNew = DateTime.Now - fileInfo.LastWriteTime < TimeSpan.FromMinutes(1);
        Console.WriteLine(firstFile);
        //File.Delete(firstFile);
        return isNew;
      }
        return false;
    }

    

    public string GetModalDialogTitle()
    {

      return GetElementText(DialogModalTitle);
    }

    public void ClickDownload()
    {
      ExecuteTask(() =>
      {
        SendKeys(Keys.Escape);
        SafeJavaScrollToElement(StmtFileDownload);
        Thread.Sleep(3000);
        SafeJavaScriptClick(StmtFileDownload);

      });
    }
    public void ClickModalDialogDownload()
    {
      WaitForPresence(ModalDownloadButton);
      ExecuteTask(() =>
      {                
        if (ModalDownloadButton.Enabled)
        {
          WaitForPresence(ModalDownloadButton);
          SafeJavaScrollToElement(ModalDownloadButton);
          SafeJavaScriptClick(ModalDownloadButton);
          Console.WriteLine("File Downloaded");
        }
        else
        {
          Console.WriteLine("Download doesn't work");
        }

      });
    }

  }
}

