﻿using PrsfmUiTests.Helpers;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrsfmUiTests.Selectors.OLS
{
 internal class UsageOverviewDetailsPage : WebDriverExtensions
  {
 
    public UsageOverviewDetailsPage(IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }

    [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Television')]")]
    public IWebElement UsageDetailOverviewTitle {get; set;}

    [FindsBy(How = How.XPath, Using = "//div[@class='percentage']")]
    public IWebElement TotalWorkPercentage { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='amount']")]
    public IWebElement UsageAmount { get; set; }
    
    [FindsBy(How = How.XPath, Using = "(//*[contains(text(),'Usage')])[4]")]
    public IWebElement UsageColumn { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Title')]")]
    public IWebElement TitleColumn { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Subtotal')]")]
    public IWebElement SubTotalColumn { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[@class='content']/div)[1]")]
    public IWebElement UsageFirstRowContentName { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[@class='content']/div)[3]")]
    public IWebElement UsageFirstRowContentAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[@class='content']/div)[1]")]
    public IWebElement FirstRowUsageGroupSongTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "(//*[contains(text(),'Royalty')])[3]")]
    public IWebElement RoyaltyColumn { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[@class='content']/div)[1]")]
    public IWebElement FirstUsageRowAccordianContent { get; set; }

    [FindsBy(How = How.XPath,  Using = "(//div[contains(@class, 'flex-row accordion-item__heading')]/div[1]/div)[3]")]
    public IWebElement FirstUsageRoyaltyAmount { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Clubland TV Non-Primetime')]")]
    public IWebElement AccordianRowTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'panel')]/div)[4]")]
    public IWebElement Period { get; set; }
                                       
    [FindsBy(How = How.XPath, Using = "//div[contains(text(),'265')]")]
    public IWebElement Performances { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Television')]")]
    public IWebElement UsageType { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Fixed point reconciliation adjustment')]")]
    public IWebElement Reason { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Adjustment')]")]   
    public IWebElement Adjustment { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(text(),'0013:32:40')]")]
    public IWebElement Duration { get; set; }

    [FindsBy(How = How.XPath, Using = "(//*[contains(text(),'Clubland TV')]) [4]")]
    public IWebElement BroadCastRegion { get; set; }


    public string GetUsageOverviewTitle()
    {
      return GetElementText(UsageDetailOverviewTitle);
    }

    public string GetPercentageOfTotalWork()
    {
      return GetElementText(TotalWorkPercentage);
    }

    public string GetUsageAmount()
    {
      return GetElementText(UsageAmount);
    }

    public string GetUsageColumnName()
    {

      return GetElementText(UsageColumn);
    }
    public void ClickUsageColumn()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(UsageColumn);
        SafeJavaScriptClick(UsageColumn);
        SendKeys(Keys.Escape);

      });
    }
    public string GetFirstUsageRowContent()
    {
      WaitForPresence(UsageFirstRowContentName);
      return GetElementText(UsageFirstRowContentName);
    }

    public void ClickSubtotalColumn()
    {
      ExecuteTask(() =>
     {
       SafeJavaScrollToElement(SubTotalColumn);
       SafeJavaScriptClick(SubTotalColumn);
       SendKeys(Keys.Escape);
     });
    }

    public string GetFirstUsageRowSubTotal()
    {
      return GetElementText(UsageFirstRowContentAmount);
    }

    public void ClickUsageFirstRow()
    {
      WaitForPresence(UsageFirstRowContentName);
      ExecuteTask(() =>
     {
       SafeJavaScrollToElement(UsageFirstRowContentName);
       SafeJavaScriptClick(UsageFirstRowContentName);
       SendKeys(Keys.Escape);      

     });
    }

    public string GetFirstUsageRowSongTitle()
    {
       return GetElementText(FirstRowUsageGroupSongTitle);
    }

    public void ClickFirstUsageRowSong()
    {
      ExecuteTask(() =>
      {
      WaitForPresence(UsageFirstRowContentName);
      ClickUsageFirstRow();
      SafeJavaScrollToElement(FirstRowUsageGroupSongTitle);
      SafeJavaScriptClick(FirstRowUsageGroupSongTitle);
      SendKeys(Keys.Escape);
      });
    }

    public void ClickRoyaltyColumn()
    {
      ExecuteTask(() =>
     {
       SafeJavaScrollToElement(RoyaltyColumn);
       SafeJavaScriptClick(RoyaltyColumn);
       SendKeys(Keys.Escape);

     });
    }

    public string GetFirstUsagerowAccordianContent()
    {
     return GetElementText(FirstUsageRowAccordianContent);
    }

    public string GetFirstUsageRowRoyaltyAmount()
    {
      return GetElementText(FirstUsageRoyaltyAmount);
    }
    public void ClickFirstUsageAccordianRow()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(FirstUsageRowAccordianContent);
        SafeJavaScriptClick(FirstUsageRowAccordianContent);
        SendKeys(Keys.Escape);

      });
    }

    public string GetAccordianRowTitle()
    {
      return GetElementText(AccordianRowTitle);
    }

    public string GetPeriod()
    {
      return GetElementText(Period);
    }

    public string GetAdjustment()
    {
      return GetElementText(Adjustment);
    }
     
    public string GetReason()
    {
      return GetElementText(Reason);
    }

    public string GetUsageType()
    {
      return GetElementText(UsageType);
    }

    public string GetPerformance()
    {
      return GetElementText(Performances);
    }
    public string GetDuration()
    {
      return GetElementText(Duration);
    }
    public string GetBroadCastRegion()
    {

      return GetElementText(BroadCastRegion);
    }
    public string GetTitleColumnName()
    {
      return GetElementText(TitleColumn);
    }

    public void ClickTitleColumn()
    {
      ExecuteTask(() =>
      {
        SafeJavaScrollToElement(TitleColumn);
        SafeJavaScriptClick(TitleColumn);
        SendKeys(Keys.Escape);

      });
    }
  }
}
