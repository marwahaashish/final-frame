﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class AdmissionsFormSelectors
    {
        // Name 
        [FindsBy(How = How.Id, Using = "app_title")]
        public IWebElement Title { get; set; }

        [FindsBy(How = How.Id, Using = "app_forenames")]
        public IWebElement Forename { get; set; }

        // Personal Details
        [FindsBy(How = How.Id, Using = "app_surname")]
        public IWebElement Surname { get; set; }

        [FindsBy(How = How.Id, Using = "app_dob_dd")]
        public IWebElement DobDay { get; set; }

        [FindsBy(How = How.Id, Using = "app_dob_mm")]
        public IWebElement DobMonth { get; set; }

        [FindsBy(How = How.Id, Using = "app_dob_yy")]
        public IWebElement DobYear { get; set; }

        [FindsBy(How = How.Id, Using = "app_gender")]
        public IWebElement Sex { get; set; }

        [FindsBy(How = How.Id, Using = "app_nationality_dl")]
        public IWebElement Nationality { get; set; }

        // Contact Details
        [FindsBy(How = How.Id, Using = "app_telephone")]
        public IWebElement DaytimePhoneNumber { get; set; }

        [FindsBy(How = How.Id, Using = "app_mobile")]
        public IWebElement MobileTelephoneNumber { get; set; }

        [FindsBy(How = How.Id, Using = "app_email")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "app_conf_email")]
        public IWebElement ConfirmEmailAddress { get; set; }

        
        // Address
        [FindsBy(How = How.Name, Using = "app_res_country")]
        public IWebElement AddressCountry { get; set; }

        [FindsBy(How = How.Id, Using = "app_postcode")]
        public IWebElement Postcode { get; set; }

        [FindsBy(How = How.Id, Using = "app_address1")]
        public IWebElement AddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "app_address2")]
        public IWebElement AddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "app_address3")]
        public IWebElement AddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "app_city")]
        public IWebElement City { get; set; }

        [FindsBy(How = How.Id, Using = "app_county")]
        public IWebElement County { get; set; }

        // Submit
        [FindsBy(How = How.Id, Using = "go_forward")]
        public IWebElement Next { get; set; }
    }
}
