﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace PrsfmUiTests.Selectors
{
    public class MusicProfileFormSelectors
    {
        [FindsBy(How = How.Id, Using = "app_primary_genre_3")]
        public IWebElement RadioButtonClassical { get; set; }

    }
}
