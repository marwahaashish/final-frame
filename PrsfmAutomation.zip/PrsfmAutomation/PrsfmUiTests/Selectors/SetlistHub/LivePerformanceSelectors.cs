﻿using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using PrsfmUiTests.Helpers;
using System.Collections.Generic;
using System.Threading;

namespace PrsfmUiTests.Selectors.SetlistHub
{
  public class LivePerformanceSelectors : WebDriverExtensions
  {

    public LivePerformanceSelectors(IWebDriver driver) : base(driver)
    {
      PageFactory.InitElements(driver, this);
    }
    [FindsBy(How = How.XPath, Using = "//div[@class='create-a-setlist btn btn--square btn--block btn-size-lg btn-primary vertical-align-middle']")]
    public IWebElement ReportLivePerformanceButton2 { get; set; }

    [FindsBy(How = How.Id, Using = "datepicker")]
    public IWebElement PerformanceDatePicker { get; set; }

    [FindsBy(How = How.Id, Using = "territorySearch")]
    public IWebElement CountrySearch { get; set; }

    [FindsBy(How = How.Id, Using = "name")]
    public IWebElement VenueSearch { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'LE4 5PX')]")]
    public IWebElement VenueSearchResult { get; set; }
    

    [FindsBy(How = How.Id, Using = "name")]
    public IWebElement AssimilateVenueSearch { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary btn-set-list']")]
    public IWebElement AssimilateSearch { get; set; }

    [FindsBy(How = How.XPath, Using = "//li[contains(@class,'ng-scope item-list')]")]
    public IWebElement VenueList { get; set; }

    [FindsBy(How = How.XPath, Using = "//li[contains(@class,'ng-scope item-list')]")]
    public IWebElement FestivalList { get; set; }


    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'if you’re reporting a festival performance')]")]
    public IWebElement ReportAFesival { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Report a festival performance')]")]
    public IWebElement ReportAOverseadFesival { get; set; }

    [FindsBy(How = How.Id, Using = "googleVenueSearch")]
    public IWebElement GooglevenueSearch { get; set; }

    [FindsBy(How = How.Id, Using = "newgoogleVenueSearch")]
    public IWebElement NewgoogleVenueSearch { get; set; }

    [FindsBy(How = How.Id, Using = "performerName")]
    public IWebElement PerformerName { get; set; }

    [FindsBy(How = How.Id, Using = "workSearch")]
    public IWebElement WorkSearch { get; set; }

    [FindsBy(How = How.Id, Using = "setListName")]
    public IWebElement SetListName { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'We require additional validation where members report a performance which is more than seven years old. Please')]")]
    public IWebElement Greater7YrsMsg { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'We require additional validation where members report a performance which is more than seven years old. Please')]")]
    public IWebElement Validation7YrsMsg { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'International performances must have occurred in the past two years in order to be valid')]")]
    public IWebElement Greater2YrsMsg { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Your performance at this venue must have occurred in the past year in order to be valid.')]")]
    public IWebElement Equal1YrMsg { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Please select valid country')]")]
    public IWebElement InvaldCountry { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='event-details ng-scope']")]
    public IWebElement WhiteSpace { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Amend Festival details')]")]
    public IWebElement AmendFestivalButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[input[@id='festivalName']]/span[contains(text(),'You have exceeded the maximum character limit for this field.')]")]
    public IWebElement InvalidFestivalVenueMessage { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[input[@id='venueName']]/span[contains(text(),'You have exceeded the maximum character limit for this field.')]")]
    public IWebElement InvalidVenueNameMessage { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'Headliner')]")]
    public IWebElement HeadlinerRadioButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'Yes')]")]
    public IWebElement YesRadioButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'No')]")]
    public IWebElement NoRadioButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'Support act')]")]
    public IWebElement SupportActRadioButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'Yes')]")]
    public IWebElement YesFestivalRadioButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[em[@class='radio-icon']]/span[contains(text(),'No')]")]
    public IWebElement NoFestivalRadioButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Unfortunately the event date you have entered falls outside the US societies performance period claim.')]")]
    public IWebElement LessThan1YearUSCountryValidationMsg { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(), 'This set list name already exists. Please choose a new name. This will help you find it later when adding existing set lists')]")]
    public IWebElement SetListNameAlreadyExistValidationMsg { get; set; }

    [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'You can return to your saved performance claims at any time and change the details before you submit them. You cannot change a claim once it’s been submitted.')]")]
    public IWebElement ThankYouConfirmationMsg { get; set; }

    [FindsBy(How = How.Id, Using = "postCode")]
    public IWebElement Postcode { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Ok')]")]
    public IWebElement OkBtn { get; set; }

    [FindsBy(How = How.Id, Using = "postTown")]
    public IWebElement Town { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(), 'Headliner')]")]
    public IWebElement HeadlinerRadioBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//input[contains(@id, 'workTitle')]")]
    public IWebElement WorkTitle { get; set; }

    [FindsBy(How = How.Id, Using = "writer")]
    public IWebElement WriterTxtBox { get; set; }

    [FindsBy(How = How.Id, Using = "artistName")]
    public IWebElement ArtistName { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Add Work')]")]
    public IWebElement AddWorkBtn { get; set; }

    [FindsBy(How = How.Id, Using = "duration")]
    public IWebElement Duration { get; set; }

    [FindsBy(How = How.XPath, Using = "(//li[contains(@class, 'setlist-item setlist-item--work-item setlist-item--hoverable ng-scope')])[5]")]
    public IWebElement SavedPerformanceWork { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Done')]")]
    public IWebElement DoneBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//li[contains(@class, 'item-list__item item-list__item--hover-highlight ng-scope item-list__item-icon item-list__item-icon-venue')]")]
    public IWebElement PopulatedVenueSearchList { get; set; }

    [FindsBy(How = How.XPath, Using = "//ul[contains(@class, 'item-list ng-scope')]")]
    public IWebElement PerformanceList { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'PERFORMANCE DATE')]")]
    public IWebElement PerformanceDateBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'DATE OF LAST CHANGE')]")]
    public IWebElement DateOfLastChangeBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//input[contains(@type, 'text')]")]
    public IWebElement SearchInputWithText { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'SUBMITTED DATE')]")]
    public IWebElement SumittedDate { get; set; }

    [FindsBy(How = How.XPath, Using = "//select[contains(@ng-model, 'submittedPrfmcsVm.selectFilter')]")]
    public IWebElement StatusDropdown { get; set; }

    [FindsBy(How = How.XPath, Using = "(//select[contains(@ng-model, 'submittedPrfmcsVm.selectFilter')]/option)[1]")]
    public IWebElement AllDDValue { get; set; }

    [FindsBy(How = How.XPath, Using = "(//select[contains(@ng-model, 'submittedPrfmcsVm.selectFilter')]/option)[2]")]
    public IWebElement SubmitttedDDValue { get; set; }

    [FindsBy(How = How.XPath, Using = "(//select[contains(@ng-model, 'submittedPrfmcsVm.selectFilter')]/option)[3]")]
    public IWebElement ProcessingDDValue { get; set; }

    [FindsBy(How = How.XPath, Using = "(//select[contains(@ng-model, 'submittedPrfmcsVm.selectFilter')]/option)[4]")]
    public IWebElement REJECTEDDDValue { get; set; }

    [FindsBy(How = How.XPath, Using = "//option[contains(text(), 'SENT FOR PAYMENT')]")]
    public IWebElement SENTFORPAYMENTDDValue { get; set; }

    [FindsBy(How = How.XPath, Using = "(//span[contains(@class, 'item-list__item_calendar-date')])[1]")]
    public IWebElement ItemListCalenderDate { get; set; }

    [FindsBy(How = How.XPath, Using = "//header[contains(text(), '0 saved')]")]
    public IWebElement ValidationMsgForNoResults { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(), 'Erasure')]")]
    public IWebElement PerformerNameSearchTerm { get; set; }

    [FindsBy(How = How.XPath, Using = "//ul[contains(@class, 'item-list ng-scope')]")]
    public IWebElement SearchList { get; set; }

    [FindsBy(How = How.XPath, Using = "(//ul[contains(@class, 'item-list ng-scope')]//li)[1]")]
    public IWebElement SinglePerformanceClaim { get; set; }

    [FindsBy(How = How.XPath, Using = "(//ul[contains(@class, 'item-list ng-scope')]//li)[2]")]
    public IWebElement SecondPerformanceClaim { get; set; }

    [FindsBy(How = How.XPath, Using = "(//ul[contains(@class, 'item-list ng-scope')]//li)[3]")]
    public IWebElement ThirdPerformanceClaim { get; set; }

    [FindsBy(How = How.XPath, Using = "//header[contains(text(), '0 submitted')]")]
    public IWebElement NoResultsValidationMsgforSubmitted { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(), '//span[contains(text(), 'MAYO CORY')]")]
    public IWebElement WriterNameonAddedItemList { get; set; }

    [FindsBy(How = How.Id, Using = "advancedSearch")]
    public IWebElement AdvanceSearch { get; set; }

    [FindsBy(How = How.XPath, Using = "(//span[contains(@role, 'button')])[3]")]
    public IWebElement ClearSearchButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(@class, 'mCustomScrollBox mCS-minimal-dark mCSB_vertical mCSB_outside')]//*[contains(text(), 'A FOREST')]")]
     public IWebElement TwelThResultAForest { get; set; }

    [FindsBy(How = How.XPath, Using = "//li[contains(@class, 'item-list__item ng-scope')]")]
    public IWebElement SearchResult { get; set; }

    [FindsBy(How = How.XPath, Using = "//strong[contains(@class, 'highlight')]")]
    public IWebElement PerformanceIdNum { get; set; }

    [FindsBy(How = How.Id, Using = "PerformanceId")]
    public IWebElement PerformanceId { get; set; }

    [FindsBy(How = How.XPath, Using = "//input[contains(@type,'submit')]")]
    public IWebElement AdminConsoleSearch { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(@class,'item-list__item-title ng-binding')]")]
    public IWebElement SavedSetListInsideSavedTab { get; set; }

    [FindsBy(How = How.XPath, Using = "(//li[contains(@class, 'item-list__item item-list__item--hover-highlight ng-scope item-list__item-icon item-list__item-icon-venue')]) [3]")]
    public IWebElement SelectItemListOfVenueName { get; set; }

    [FindsBy(How = How.XPath, Using = "//label[contains(text(), 'Who performed the Set List')]")]
    public IWebElement PopulatedTextInPerformerfield { get; set; }

    [FindsBy(How = How.Id, Using = "googleVenueSearch")]
    public IWebElement GoogleVenueSearchTextBox {get; set; }

    [FindsBy(How = How.XPath, Using = "(//button[contains(@ng-click, 'buttonWithStateCtl.submit()')])[2]")]
    public IWebElement GoogleDoneButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(@ng-click, 'vm.saveManualVenue(venueForm)')]")]
     public IWebElement GoogleModalDoneButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Google')]")]
     public IWebElement GoogleLink { get; set; }

    [FindsBy(How = How.Id, Using = "newgoogleVenueSearch")]
    public IWebElement NewGoogleVenueSearch { get; set; }

    //[FindsBy(How = How.XPath, Using = "(//div[contains(@class, 'work-info')])[1]")]
    [FindsBy(How = How.XPath, Using = "//button[contains(@class, 'btn item-list__button add')]")]
  
    public IWebElement YourWorkFirstSearchResult  { get; set; }

    [FindsBy(How = How.XPath, Using = "//*[@class='ng - scope ng - isolate - scope']")]
    public IWebElement GoogleAutoCompleteElement { get; set; }



    public string SavedPerformanceDetail(string item)
    {

      return $"//span[contains(text(),'{item}')]";
    }

    [FindsBy(How = How.XPath, Using = "//ul[@class='item-list works-list worklist-filterable']")]
    public IWebElement YourWorkFirstSearchResultOutput { get; set; }
    
    public string WorksList(string item)
    {

      return $"//li[1][//span[contains(text(),'{item}')]]//button[@class='btn item-list__button add']";
    }

    public string WorklistDetail(string item)
    {
      return $"//div[@class='work-info']/div[contains(text(),'{item}')]";
    }

    public string Tunecode(string item)
    {

      return $"//span[contains(@class,'setlist-item-sub-content ng-binding') and contains(text(),'{item}')]";
    }

    public string HighlightedAssimilateResult(string item)
    {

      return $"(//span[contains(text(),'{item}')])";
    }

    public string HighlightedResult(string item)
    {

      return $"//ul[contains(@class,'item-list search-results')]/span[contains(text(),'{item}')]";
    }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Find more venues')]")]
    public IWebElement FindMoreVenues { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Google')]")]
    public IWebElement FindGoogleVenues { get; set; }

    [FindsBy(How = How.XPath, Using = "//tbody")]
    public IWebElement SubmittedPerformanceRecordDetails { get; set; }

    [FindsBy(How = How.XPath, Using = "//button/span[contains(text(),'Add venue details manually')]")]
    public IWebElement AddVenueDetailsManually { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Still not found it?')]")]
    public IWebElement AddAssimilateVenueDetailsManually { get; set; }

    [FindsBy(How = How.Id, Using = "venueName")]
    public IWebElement AddVenueDetailsManuallyName { get; set; }

    [FindsBy(How = How.Id, Using = "venueCityState")]
    public IWebElement AddVenueDetailsManuallyCity { get; set; }

    [FindsBy(How = How.Id, Using = "venuePostcode")]
    public IWebElement AddVenueDetailsManuallyPostCode { get; set; }

    [FindsBy(How = How.Id, Using = "name")]
    public IWebElement SearchFestivalName { get; set; }


    [FindsBy(How = How.XPath, Using = "//input[contains(@class,'input-text')]")]
    public IWebElement SetlistPopulated { get; set; }

    [FindsBy(How = How.Id, Using = "stageSelect")]
    public IWebElement StageName { get; set; }

    [FindsBy(How = How.Id, Using = "festivalName")]
    public IWebElement FestivalName { get; set; }

    [FindsBy(How = How.Id, Using = "stageName")]
    public IWebElement FestivalStage { get; set; }

    [FindsBy(How = How.Id, Using = "festivalCity")]
    public IWebElement Festivalvenue { get; set; }

    [FindsBy(How = How.Id, Using = "festivalPostcode")]
    public IWebElement FestivalPostcode { get; set; }

    [FindsBy(How = How.Id, Using = "festivalPostcode")]
    public IWebElement reviewFestivalName { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary']")]
    public IWebElement SubmitButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Save for later')]")]
    public IWebElement SaveForLaterButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Add Festival details')]")]
    public IWebElement AddFestivalsButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Add works')]")]
    public IWebElement AddWorksButton { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Done')]")]
    public IWebElement AddWorksDoneButton { get; set; }


    [FindsBy(How = How.XPath, Using = "//div[@class='headerDiv'][contains(text(),'Register or amend my music')]")]
    public IWebElement RegisterWorksPageHeader { get; set; }


    [FindsBy(How = How.XPath, Using = "//h2[contains(text(), 'Add works')]")]
    public IWebElement AddWorksLabel { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='work-info']/div[@ng-class]")]
    public IWebElement WorklistDetails { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(), 'KASSNER ASSOCIATED PUBLISHERS LIMITED, CHERRY RED SONGS')]")]
    public IWebElement WriterNameInWorkInfo { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(text(), 'HEAVEN ON THEIR MINDS')]")]
    public IWebElement AddedWorkTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[@class='close-icon__setlist-item-remove']")]
    public IWebElement DeleteWorklistIcon { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[@href='#/modal/add-existing-setlist']")]
    public IWebElement AddExistingSetList { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Add an existing set list')]")]
    public IWebElement AddExistingSetListBtn { get; set; }

    [FindsBy(How = How.XPath, Using = "//li[1]//a[contains(@class,'checkbox')]")]
    public IWebElement SelectExistingSetList { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[@ng-click='vm.addToPerformance()']")]
    public IWebElement AddSetListbutton { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[@ng-click='vm.toggleAdvancedSearch()']")]
    public IWebElement AdvancedWorksearchLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[@ng-click='vm.registerWork()']")]
    public IWebElement CantFindItLink { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Cancel')]")]
    public IWebElement Cancel { get; set; }

    [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'find a work?')]")]
    public IWebElement CantFindItText { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[contains(@class,'register-works-content')]//a[contains(@href,'Welcome')]")]
    public IWebElement RegisterYourWorkHere { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(@href,'prsformusic.com/societies/services/Pages/querytool.aspx')]")]
    public IWebElement Uploadfiches { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[@class='headerDiv'][contains(text(),'Register or amend my music')]")]
    public IWebElement RegisterYourWorkHereTitle { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[h1[contains(text(), 'Sure you')]]//button[./text()='Submit']")]
    public IWebElement FinalSubmit { get; set; }

    [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Create a new set list')]")]
    public IWebElement CreateAnewSetList { get; set; }

    [FindsBy(How = How.XPath, Using = "//div[h1[contains(text(),'Thank you for reporting your performance.')]]")]
    public IWebElement FinalSubmitPageText { get; set; }


    [FindsBy(How = How.XPath, Using = "//img[@src='../assets/images/prs-logo.svg']")]
    public IWebElement PRSLogo { get; set; }

    [FindsBy(How = How.XPath, Using = "//img[@src='/assets/images/prs-logo.svg']")]
    public IWebElement AssimilatePRSLogo { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Contact us')]")]
    public IWebElement ContactUs { get; set; }

    public string WorkInfo = "//div[@class='work-info']/div[@ng-class]";

    [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Live Performances')]")]
    public IWebElement LivePerformances { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(), 'Saved')]")]
    public IWebElement SavedTab { get; set; }

    [FindsBy(How = How.XPath, Using = "//li[1]")]
    public IWebElement SelectPerformance { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(), 'Submitted')]")]
    public IWebElement SubmittedTab { get; set; }

    [FindsBy(How = How.XPath, Using = "//span[contains(text(), 'International performances must have occurred in the past two years in order to be valid.')]")]
    public IWebElement OverseasValidationMessage { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'SUBMITTED DATE')]")]
    public IWebElement SubmittedDate { get; set; }

    [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'Still not found it?')]")]
    public IWebElement StillNotFoundLink { get; set; }

    [FindsBy(How = How.Id, Using = "venueName")]
    public IWebElement ModalVenueName { get; set; }

    [FindsBy(How = How.Id, Using = "venueCityState")]
    public IWebElement VenueCityState { get; set; }

    [FindsBy(How = How.Id, Using = "venuePostcode")]
    public IWebElement VenuePostcode { get; set; }

    public string GetPerformanceDate()
    {
      return GetElementText(PerformanceDateBtn);
    }
    public string GetDateOfLastChange()
    {
      return GetElementText(DateOfLastChangeBtn);
    }
    public string GetSearchTextBoxtext()
    {
      return GetElementText(SearchInputWithText);
    }

    public bool IsSearchBoxPlaceHolderTextDisplayed()
    {
      if (SearchInputWithText != null)
      {
        Assert.IsTrue(SearchInputWithText.Displayed);
      }
      else
      {
        Assert.IsNull(SearchInputWithText);
      }
      return DoesElementExist(SearchInputWithText);
    }
    public string GetSubmittedDate()
    {
      return GetElementText(SubmittedDate);
    }
    public string GetAllDDvalue()
    {
      return GetElementText(AllDDValue);
    }
    public string GetSubmittedDDvalue()
    {
      return GetElementText(SubmitttedDDValue);
    }
    public string GetProcessingDDvalue()
    {
      return GetElementText(ProcessingDDValue);
    }
    public string GetRejectedDDvalue()
    {
      return GetElementText(REJECTEDDDValue);
    }
    public string GetSENTFORPAYMENTForDDvalue()
    {
      return GetElementText(SENTFORPAYMENTDDValue);
    }
    public void SelectSubmitted(string DropDownValue1)
    {
      SelectFromDropDownList(SubmitttedDDValue, DropDownValue1);
    }
    public void SelectProcessing(string DropDownValue2)
    {
      SelectFromDropDownList(ProcessingDDValue, DropDownValue2);
    }
    public void SelectRejected(string DropDownValue4)
    {
      SelectFromDropDownList(REJECTEDDDValue, DropDownValue4);
    }
    public void SelectSentForPayment(string DropDownValue4)
    {
      SelectFromDropDownList(SENTFORPAYMENTDDValue, DropDownValue4);
    }

    public void SelectAll()
    {
      SelectFromDropDownList(AllDDValue, "ALL");
    }

    public string GetPerformanceId()
    {
      return GetElementText(PerformanceId);
    }

    public void SearchAndSelectEventVenue(string VenueName) {
      NewGoogleVenueSearch.SendKeys(VenueName);
      Thread.Sleep(3000);
      NewGoogleVenueSearch.SendKeys(Keys.ArrowDown);
      NewGoogleVenueSearch.SendKeys(Keys.Enter);
   


    }
  } 
}
